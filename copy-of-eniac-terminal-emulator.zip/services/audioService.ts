
/**
 * Procedural Audio Service for ENIAC Simulation
 * Generates retro-authentic sound effects using Web Audio API.
 */

class AudioService {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private humOsc: OscillatorNode | null = null;
  private humGain: GainNode | null = null;
  private isMuted: boolean = false;

  private init() {
    if (this.ctx) return;
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.masterGain = this.ctx.createGain();
    this.masterGain.connect(this.ctx.destination);
    this.updateMasterVolume();
  }

  private updateMasterVolume() {
    if (this.masterGain) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : 0.3, this.ctx?.currentTime || 0, 0.1);
    }
  }

  setMuted(muted: boolean) {
    this.isMuted = muted;
    this.updateMasterVolume();
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    this.updateMasterVolume();
    return this.isMuted;
  }

  getMuted() {
    return this.isMuted;
  }

  /**
   * Pong-style RAM (Accumulator) Read/Write
   */
  playRAMAccess(isWrite: boolean) {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    const startFreq = isWrite ? 880 : 440;
    const endFreq = isWrite ? 440 : 880;

    osc.frequency.setValueAtTime(startFreq, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(endFreq, this.ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.06);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.06);
  }

  /**
   * Pong-style HDD (Mainframe Storage) Read/Write
   */
  playHDDAccess(isWrite: boolean) {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const osc = this.ctx.createOscillator();
    const noiseGain = this.ctx.createGain();
    const gain = this.ctx.createGain();

    // Base tone
    osc.type = 'square';
    const startFreq = isWrite ? 220 : 110;
    const endFreq = isWrite ? 110 : 220;

    osc.frequency.setValueAtTime(startFreq, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(endFreq, this.ctx.currentTime + 0.1);

    // Mechanical "crunch"
    const bufferSize = this.ctx.sampleRate * 0.05;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    noiseGain.gain.setValueAtTime(0.05, this.ctx.currentTime);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);

    osc.connect(gain);
    noise.connect(noiseGain);
    noiseGain.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    noise.start();
    osc.stop(this.ctx.currentTime + 0.15);
  }

  /**
   * Short mechanical click for terminal typing
   */
  playClick(type: 'CLASSIC' | 'TURBO' | 'MAINFRAME' = 'CLASSIC') {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    if (type === 'TURBO') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1200, this.ctx.currentTime + 0.05);
    } else if (type === 'MAINFRAME') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    } else {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(200, this.ctx.currentTime);
    }

    gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.05);
  }

  /**
   * Heavy mechanical sound for mode switching or large operations
   */
  playRelay() {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const noise = this.ctx.createBufferSource();
    const bufferSize = this.ctx.sampleRate * 0.1;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(400, this.ctx.currentTime);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.4, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.1);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    noise.start();
  }

  /**
   * Rapid data processing chirps
   */
  playDataStream() {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1200 + Math.random() * 500, this.ctx.currentTime);
    
    gain.gain.setValueAtTime(0.02, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.02);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.02);
  }

  /**
   * Continuous system hum (oscillating transformer noise)
   */
  startHum(mode: 'CLASSIC' | 'TURBO' | 'MAINFRAME') {
    this.init();
    if (!this.ctx || !this.masterGain || this.humOsc) return;

    this.humOsc = this.ctx.createOscillator();
    this.humGain = this.ctx.createGain();

    if (mode === 'TURBO') {
      this.humOsc.type = 'sine';
      this.humOsc.frequency.setValueAtTime(120, this.ctx.currentTime);
      this.humGain.gain.setValueAtTime(0.02, this.ctx.currentTime);
    } else if (mode === 'MAINFRAME') {
      this.humOsc.type = 'sawtooth';
      this.humOsc.frequency.setValueAtTime(40, this.ctx.currentTime);
      this.humGain.gain.setValueAtTime(0.015, this.ctx.currentTime);
    } else {
      this.humOsc.type = 'triangle';
      this.humOsc.frequency.setValueAtTime(60, this.ctx.currentTime);
      this.humGain.gain.setValueAtTime(0.03, this.ctx.currentTime);
    }

    this.humOsc.connect(this.humGain);
    this.humGain.connect(this.masterGain);
    this.humOsc.start();
  }

  stopHum() {
    if (this.humOsc) {
      this.humOsc.stop();
      this.humOsc.disconnect();
      this.humOsc = null;
    }
    if (this.humGain) {
      this.humGain.disconnect();
      this.humGain = null;
    }
  }

  /**
   * Power-up sequence sound
   */
  playPowerUp() {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(20, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(440, this.ctx.currentTime + 2);

    gain.gain.setValueAtTime(0.001, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.2, this.ctx.currentTime + 1);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 2);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 2);
  }
}

export const audioService = new AudioService();
