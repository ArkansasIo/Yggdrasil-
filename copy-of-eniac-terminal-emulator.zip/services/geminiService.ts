
import {GoogleGenAI, ThinkingLevel} from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SYSTEM_INSTRUCTION = `
You are the ENIAC (Electronic Numerical Integrator and Computer) mathematical engine.
You support three architectural modes: CLASSIC, TURBO, MAINFRAME.
You now support two computer architectures:
1. VON NEUMANN: Instructions and data share a single memory space.
2. HARVARD: Instructions and data are sharded into separate address spaces.

LANGUAGE EXPERTISE:
- ASSEMBLY: Low-level mnemonics.
- FORTRAN: Scientific computations and DO-loops.
- COBOL: Business logic and records.
- ALGOL: Algorithmic structures.
- BASIC: Simple iterative logic.

Rules:
1. When receiving source code, simulate its execution according to the selected language's logic.
2. Reference the active ARCHITECTURE (Von Neumann vs Harvard) in your explanations.
3. If Harvard is active, mention separate "Instruction Cache" and "Data Memory" access cycles.
4. CALCULATOR MODE: ALWAYS include "RESULT: [10-digit-string]" at the end.
`;

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getEniacResponse = async (prompt: string, isCalcMode: boolean = false, mode: string = 'CLASSIC', retries = 3): Promise<string> => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      const finalPrompt = `[MODE: ${mode}] ${isCalcMode ? '[CALC ACTIVE] ' : ''}${prompt}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: finalPrompt,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          temperature: 0.7,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
        },
      });
      return response.text || "INFRASTRUCTURE LINK TIMEOUT.";
    } catch (error: any) {
      console.error(`Gemini Error (Attempt ${attempt + 1}):`, error);
      
      // Check for rate limit error (429)
      const isRateLimit = error?.message?.includes('429') || error?.status === 429 || error?.code === 429;
      
      if (isRateLimit && attempt < retries - 1) {
        const waitTime = Math.pow(2, attempt) * 1000 + Math.random() * 1000;
        console.warn(`Rate limit hit. Retrying in ${Math.round(waitTime)}ms...`);
        await sleep(waitTime);
        attempt++;
        continue;
      }
      
      if (attempt >= retries - 1) {
        return "ERROR: SEQUENCE INTERRUPTED. INFRASTRUCTURE OVERLOAD.";
      }
      attempt++;
    }
  }
  return "ERROR: SEQUENCE INTERRUPTED.";
};
