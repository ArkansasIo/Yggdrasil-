
import React, { useState } from 'react';
import { FileSystemEntry } from '../types';
import { audioService } from '../services/audioService';

interface FileEditorProps {
  file: FileSystemEntry;
  onSave: (content: string) => void;
  onCancel: () => void;
}

export const FileEditor: React.FC<FileEditorProps> = ({ file, onSave, onCancel }) => {
  const [content, setContent] = useState(file.content || '');

  const handleKeyPress = () => {
    audioService.playClick('CLASSIC');
  };

  const handleSave = () => {
    audioService.playRelay();
    onSave(content);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] border-2 border-amber-900 rounded-lg overflow-hidden shadow-2xl font-mono crt-effect">
      <div className="bg-amber-950/30 px-3 py-2 border-b border-amber-900 flex justify-between items-center">
        <div className="flex flex-col">
          <span className="text-[10px] text-amber-500 font-bold uppercase tracking-widest flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" />
            System File Editor
          </span>
          <span className="text-[8px] text-amber-900 uppercase">File: {file.name} | Owner: {file.owner}</span>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={onCancel} 
            className="text-amber-900 hover:text-amber-500 px-2 transition-colors"
          >
            EXIT
          </button>
        </div>
      </div>

      <div className="flex-1 relative p-2">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={handleKeyPress}
          spellCheck={false}
          className="w-full h-full bg-black/60 text-amber-400 p-4 text-xs resize-none outline-none font-mono caret-amber-500 scrollbar-hide border border-amber-900/20"
          placeholder="ENTER FILE CONTENT..."
          autoFocus
        />
        <div className="absolute bottom-4 right-4 text-[8px] text-amber-900 uppercase pointer-events-none opacity-30">
          Magnetic Tape Buffer [ACTIVE]
        </div>
      </div>

      <div className="p-3 bg-black border-t border-amber-900 flex gap-2">
        <button 
          onClick={handleSave}
          className="flex-1 bg-amber-600 hover:bg-amber-500 text-black font-bold py-2 text-[10px] uppercase tracking-widest rounded shadow-[0_0_15px_rgba(217,119,6,0.2)] transition-all"
        >
          Commit Changes to Disk
        </button>
        <button 
          onClick={onCancel}
          className="px-6 border border-amber-900 text-amber-700 hover:text-amber-500 text-[10px] font-bold uppercase tracking-widest rounded transition-all"
        >
          Discard
        </button>
      </div>
    </div>
  );
};
