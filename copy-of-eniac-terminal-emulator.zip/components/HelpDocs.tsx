
import React from 'react';

export const HelpDocs: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] bg-black/90 flex items-center justify-center p-8 backdrop-blur-sm crt-effect">
      <div className="w-full max-w-2xl border-2 border-amber-600 bg-[#0a0a0a] rounded overflow-hidden flex flex-col shadow-[0_0_50px_rgba(217,119,6,0.3)]">
        <div className="bg-amber-900/20 px-4 py-3 flex justify-between items-center border-b border-amber-900/50">
          <h2 className="text-amber-500 font-bold text-sm uppercase tracking-widest">Manual: Operation & Command Set</h2>
          <button onClick={onClose} className="text-amber-700 hover:text-amber-400 text-xl font-mono">&times;</button>
        </div>
        
        <div className="p-6 overflow-y-auto max-h-[70vh] font-mono text-xs space-y-6 text-amber-800/80">
          <section>
            <h3 className="text-amber-500 font-bold border-b border-amber-900 pb-1 mb-2">SYSTEM NAVIGATION</h3>
            <ul className="space-y-2">
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">LS / DIR</span> <span>List contents of current directory.</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">CD [PATH]</span> <span>Change current directory ('..' for parent).</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">MKDIR [NAME]</span> <span>Create a new directory in the current path.</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">SEARCH [TERM]</span> <span>Find files matching TERM in current path recursively.</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">INIT CLASSIC</span> <span>Revert to original 1945 hardware spec.</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">INIT TURBO</span> <span>Initialize Mk-II 9GHz Hyper-pulse core.</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">CLEAR</span> <span>Wipe console logs and active memory traces.</span></li>
            </ul>
          </section>

          <section>
            <h3 className="text-amber-500 font-bold border-b border-amber-900 pb-1 mb-2">COMPUTATION MODES</h3>
            <ul className="space-y-2">
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">MODE CALC</span> <span>Engages direct expression evaluator (e.g. "12 * 45").</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">MODE CMD</span> <span>Switch back to terminal command interaction.</span></li>
              <li className="flex gap-4"><span className="text-amber-400 w-32 flex-shrink-0">DEBUG ON/OFF</span> <span>Toggle the micro-op trace panel.</span></li>
            </ul>
          </section>

          <section>
            <h3 className="text-amber-500 font-bold border-b border-amber-900 pb-1 mb-2">INTERFACE TIPS</h3>
            <p className="mb-2">Clicking on the 'Register Matrix' in Turbo mode toggles between different data views (Grid, Inspector, Binary Word, Bitstream).</p>
            <p>Tube integrity decreases over time. If integrity drops too low, system errors may occur. Use 'INIT' commands to recalibrate and reset integrity.</p>
          </section>

          <section className="bg-amber-950/20 p-3 rounded border border-amber-900/30">
            <h3 className="text-amber-400 font-bold mb-1">PRO TIP: PUNCH MACHINE</h3>
            <p>Access the Programming Room via the Card Reader panel to create your own custom program decks. These decks are saved along with the system state.</p>
          </section>
        </div>

        <button onClick={onClose} className="bg-amber-600 text-black font-bold py-3 text-xs uppercase tracking-[0.3em] hover:bg-amber-500 transition-colors">Return to Console</button>
      </div>
    </div>
  );
};
