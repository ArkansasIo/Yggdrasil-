
import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';

interface TerminalProps {
  messages: Message[];
  onCommand: (command: string) => void;
  isLoading: boolean;
  isCalcMode?: boolean;
}

export const Terminal: React.FC<TerminalProps> = ({ messages, onCommand, isLoading, isCalcMode = false }) => {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    onCommand(input);
    setInput('');
  };

  return (
    <div className="flex flex-col h-full bg-[#050505] border-2 border-gray-800 rounded-lg shadow-2xl relative overflow-hidden crt-effect">
      <div className="bg-gray-800 px-4 py-1 flex justify-between items-center text-[10px] uppercase tracking-widest text-gray-400">
        <span className="flex items-center gap-2">
          ENIAC Constant Transmitter Console 
          {isCalcMode && <span className="text-amber-500 font-bold bg-amber-950/30 px-1 border border-amber-900/30">[CALC MODE]</span>}
        </span>
        <span className="flex items-center gap-2">
          <span className={`w-2 h-2 ${isLoading ? 'bg-red-500 animate-pulse' : 'bg-green-500'} rounded-full`}></span>
          {isLoading ? 'BUSY' : 'READY'}
        </span>
      </div>
      
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide font-mono text-sm"
      >
        <div className="text-amber-500 glow-amber border-b border-amber-900/30 pb-2 mb-4">
          <pre className="text-[10px] leading-tight">
{`   _____ _   _ ___   _    ____ 
  | ____| \\ | |_ _| / \\  / ___|
  |  _| |  \\| || | / _ \\| |    
  | |___| |\\  || |/ ___ \\ |___ 
  |_____|_| \\_|___/_/   \\_\\____|
                                `}
          </pre>
          <p className="mt-2 text-[9px] opacity-70">UNIVERSITY OF PENNSYLVANIA - MOORE SCHOOL OF ELECTRICAL ENGINEERING</p>
          <p className="text-[9px] opacity-70">SYSTEM READY. TYPE 'MODE CALC' OR 'MODE CMD'.</p>
        </div>

        {messages.map((m) => (
          <div key={m.id} className="flex flex-col">
            <div className={`flex items-center gap-2 text-[10px] font-bold ${
              m.sender === 'USER' ? 'text-blue-400' : m.sender === 'SYSTEM' ? 'text-gray-500' : 'text-green-500'
            }`}>
              <span>[{m.timestamp.toLocaleTimeString()}]</span>
              <span>{m.sender} {'>'}</span>
            </div>
            <div className={`whitespace-pre-wrap mt-1 ${
              m.sender === 'USER' ? 'text-gray-300' : 'text-green-400 glow-green'
            }`}>
              {m.text}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="text-green-500 animate-pulse flex items-center gap-2">
            <span>PULSE TRAIN PROPAGATING...</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t border-gray-800 bg-black flex gap-2">
        <span className={`${isCalcMode ? 'text-amber-500' : 'text-green-500'} font-bold`}>
          {isCalcMode ? 'CALC >' : '$ >'}
        </span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={isLoading}
          autoFocus
          className={`flex-1 bg-transparent border-none outline-none font-mono caret-green-500 ${isCalcMode ? 'text-amber-400' : 'text-green-400'}`}
          placeholder={isCalcMode ? "ENTER EXPRESSION (e.g. 12 * 45)..." : "ENTER COMMAND..."}
        />
      </form>
    </div>
  );
};
