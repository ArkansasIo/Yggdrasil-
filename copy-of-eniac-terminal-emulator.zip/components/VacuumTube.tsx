
import React from 'react';

interface VacuumTubeProps {
  active: boolean;
  label?: string;
}

export const VacuumTube: React.FC<VacuumTubeProps> = ({ active, label }) => {
  return (
    <div className="flex flex-col items-center gap-1">
      <div 
        className={`w-4 h-8 rounded-t-full rounded-b-sm vacuum-tube ${active ? 'active' : ''}`}
      />
      {label && <span className="text-[8px] text-gray-500 uppercase">{label}</span>}
    </div>
  );
};
