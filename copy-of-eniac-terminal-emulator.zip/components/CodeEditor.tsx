
import React, { useState } from 'react';
import { audioService } from '../services/audioService';

type Language = 'ASSEMBLY' | 'FORTRAN' | 'COBOL' | 'ALGOL' | 'BASIC';

const TEMPLATES: Record<Language, string> = {
  ASSEMBLY: "; ENIAC ASM V1.0\nLOAD R1, #100\nLOOP:\n  ADD R2, R1\n  DEC R1\n  JNZ LOOP\nHALT",
  FORTRAN: "C FORTRAN II - BALLISTICS\n      PROGRAM PROJECTILE\n      DO 100 I = 1, 1000\n      Y = X * TAN(THETA) - (G*X**2)\n100   CONTINUE\n      STOP\n      END",
  COBOL: "IDENTIFICATION DIVISION.\nPROGRAM-ID. PAYROLL.\nPROCEDURE DIVISION.\n    COMPUTE NET-PAY = HOURS * RATE.\n    DISPLAY NET-PAY.\n    STOP RUN.",
  ALGOL: "begin\n  integer i, sum;\n  sum := 0;\n  for i := 1 step 1 until 100 do\n    sum := sum + i;\n  print(sum);\nend",
  BASIC: "10 PRINT \"ENIAC BASIC V1\"\n20 FOR I = 1 TO 10\n30 PRINT I * I\n40 NEXT I\n50 END"
};

interface CodeEditorProps {
  onExecute: (code: string, lang: Language) => void;
  onCancel: () => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ onExecute, onCancel }) => {
  const [lang, setLang] = useState<Language>('ASSEMBLY');
  const [code, setCode] = useState(TEMPLATES['ASSEMBLY']);

  const handleLangChange = (newLang: Language) => {
    setLang(newLang);
    setCode(TEMPLATES[newLang]);
    audioService.playRelay();
  };

  const handleKeyPress = () => {
    audioService.playClick('CLASSIC');
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] border-2 border-emerald-900 rounded-lg overflow-hidden shadow-2xl font-mono">
      <div className="bg-emerald-950/30 px-3 py-2 border-b border-emerald-900 flex justify-between items-center">
        <span className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
          Teletype Program Editor
        </span>
        <div className="flex gap-2">
          {(['ASSEMBLY', 'FORTRAN', 'COBOL', 'ALGOL', 'BASIC'] as Language[]).map(l => (
            <button 
              key={l}
              onClick={() => handleLangChange(l)}
              className={`text-[8px] px-1.5 py-0.5 border transition-colors ${lang === l ? 'bg-emerald-800 text-black border-emerald-400' : 'text-emerald-900 border-emerald-900/50 hover:border-emerald-700'}`}
            >
              {l}
            </button>
          ))}
          <button onClick={onCancel} className="text-emerald-900 hover:text-emerald-400 ml-2">&times;</button>
        </div>
      </div>

      <div className="flex-1 relative group p-2">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          onKeyDown={handleKeyPress}
          spellCheck={false}
          className="w-full h-full bg-black/40 text-emerald-500 p-4 text-xs resize-none outline-none font-mono caret-emerald-400 scrollbar-hide border border-emerald-900/20"
          placeholder="ENTER SOURCE CODE..."
        />
        <div className="absolute bottom-4 right-4 text-[8px] text-emerald-900 uppercase pointer-events-none opacity-50">
          Ready for Instruction Dispatch
        </div>
      </div>

      <div className="p-3 bg-black border-t border-emerald-900 flex gap-2">
        <button 
          onClick={() => onExecute(code, lang)}
          className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-black font-bold py-2 text-[10px] uppercase tracking-widest rounded shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all"
        >
          Dispatch to Arithmetic Unit
        </button>
      </div>
    </div>
  );
};
