
import React from 'react';
import { CacheEntry } from '../types';

interface InstructionCacheProps {
  entries: CacheEntry[];
  lastResult: 'HIT' | 'MISS' | null;
}

export const InstructionCache: React.FC<InstructionCacheProps> = ({ entries, lastResult }) => {
  const hitRate = entries.length > 0 ? (lastResult === 'HIT' ? 92.4 : 12.5) : 0;

  return (
    <div className="flex flex-col h-full border-2 border-cyan-900 bg-[#050505] rounded-lg overflow-hidden shadow-inner font-mono">
      <div className="bg-[#001a1a] px-3 py-1.5 border-b border-cyan-900 flex justify-between items-center">
        <span className="text-[9px] font-bold text-cyan-500 uppercase tracking-widest flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="animate-pulse"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
          L1 Instruction Cache
        </span>
        <div className={`px-1.5 rounded text-[8px] font-bold ${
          lastResult === 'HIT' ? 'bg-green-900/40 text-green-400' : 
          lastResult === 'MISS' ? 'bg-red-900/40 text-red-400' : 'text-gray-600'
        }`}>
          {lastResult || 'IDLE'}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-hide">
        <div className="grid grid-cols-[60px_1fr] gap-2 mb-1 border-b border-cyan-950 pb-1 opacity-40">
          <span className="text-[7px] uppercase">Tag_ID</span>
          <span className="text-[7px] uppercase">Instruction_Block</span>
        </div>
        
        {entries.length === 0 ? (
          <div className="h-full flex items-center justify-center text-[7px] text-cyan-900 uppercase italic py-8">
            Cache Cold - Awaiting Dispatch
          </div>
        ) : (
          [...entries].sort((a, b) => b.lastAccess - a.lastAccess).map((entry, idx) => (
            <div 
              key={entry.tag} 
              className={`grid grid-cols-[60px_1fr] gap-2 p-1 border border-cyan-900/20 rounded transition-all duration-500 ${
                idx === 0 && lastResult === 'HIT' ? 'bg-cyan-900/20 border-cyan-400' : 'bg-black/40'
              }`}
            >
              <span className="text-[8px] text-cyan-700 truncate font-bold">{entry.tag.slice(0, 8)}</span>
              <span className="text-[8px] text-cyan-400 truncate opacity-80">{entry.data}</span>
            </div>
          ))
        )}
      </div>

      <div className="bg-black border-t border-cyan-900/30 p-2 space-y-1.5">
        <div className="flex justify-between items-center text-[7px] uppercase">
          <span className="text-cyan-900">Hit Probability</span>
          <span className="text-cyan-500 font-bold">{hitRate.toFixed(1)}%</span>
        </div>
        <div className="w-full h-1 bg-gray-900 rounded-full overflow-hidden">
          <div 
            className="h-full bg-cyan-600 transition-all duration-1000" 
            style={{ width: `${hitRate}%` }} 
          />
        </div>
        <div className="flex justify-between text-[6px] text-cyan-900/60 font-mono">
          <span>LATENCY: {lastResult === 'HIT' ? '1 cycle' : '15-20 cycles'}</span>
          <span>ASSOC: 8-WAY</span>
        </div>
      </div>
    </div>
  );
};
