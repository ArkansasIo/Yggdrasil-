
import React, { useMemo } from 'react';
import { NodeState } from '../types';

interface InfrastructureMonitorProps {
  nodes: NodeState[];
  isProcessing: boolean;
}

export const InfrastructureMonitor: React.FC<InfrastructureMonitorProps> = ({ nodes, isProcessing }) => {
  const stats = useMemo(() => {
    const active = nodes.filter(n => n.status === 'ONLINE' || n.status === 'BUSY').length;
    const avgLoad = nodes.reduce((acc, n) => acc + n.load, 0) / nodes.length;
    const avgTemp = nodes.reduce((acc, n) => acc + n.temperature, 0) / nodes.length;
    return { active, avgLoad, avgTemp };
  }, [nodes]);

  return (
    <div className="flex flex-col h-full border-2 border-sky-900 bg-[#0a0a0a] rounded-lg p-3 relative overflow-hidden shadow-inner">
      <div className="text-[10px] text-sky-600 uppercase mb-2 border-b border-sky-900 pb-1 font-bold flex justify-between items-center">
        <span>Mainframe Cluster Monitor</span>
        <div className="flex items-center gap-2">
          <span className="text-[7px] text-sky-800">NODES: {stats.active}/{nodes.length}</span>
          {isProcessing && <div className="w-1 h-1 bg-sky-400 animate-ping rounded-full" />}
        </div>
      </div>

      <div className="flex-1 grid grid-cols-4 gap-1 pr-1 overflow-y-auto scrollbar-hide">
        {nodes.map(node => (
          <div 
            key={node.id}
            className={`aspect-square border flex flex-col items-center justify-center gap-1 transition-all ${
              node.status === 'BUSY' ? 'border-sky-400 bg-sky-900/40' : 
              node.status === 'ONLINE' ? 'border-sky-900/40 bg-black' : 
              'border-gray-900 opacity-20'
            }`}
          >
            <div className={`w-1 h-1 rounded-full ${
              node.status === 'BUSY' ? 'bg-sky-400 shadow-[0_0_4px_cyan]' : 
              node.status === 'ONLINE' ? 'bg-sky-900' : 'bg-red-900'
            }`} />
            <span className="text-[5px] text-sky-800 font-mono">{node.id}</span>
            <div className="w-3 h-0.5 bg-gray-900 overflow-hidden">
               <div className="h-full bg-sky-600" style={{ width: `${node.load}%` }} />
            </div>
          </div>
        ))}
      </div>

      <div className="mt-2 grid grid-cols-2 gap-2 pt-2 border-t border-sky-900/30">
        <div className="flex flex-col gap-0.5">
          <span className="text-[6px] text-sky-800 uppercase">Avg Cluster Load</span>
          <div className="flex items-end gap-1">
             <span className="text-[10px] font-mono text-sky-500">{stats.avgLoad.toFixed(1)}%</span>
             <div className="flex-1 h-1 bg-gray-900 mb-1">
                <div className="h-full bg-sky-500" style={{ width: `${stats.avgLoad}%` }} />
             </div>
          </div>
        </div>
        <div className="flex flex-col gap-0.5">
          <span className="text-[6px] text-sky-800 uppercase">Thermal Integrity</span>
          <div className="flex items-end gap-1">
             <span className="text-[10px] font-mono text-amber-600">{stats.avgTemp.toFixed(1)}°C</span>
             <div className="flex-1 h-1 bg-gray-900 mb-1">
                <div className="h-full bg-amber-600" style={{ width: `${(stats.avgTemp / 100) * 100}%` }} />
             </div>
          </div>
        </div>
      </div>
      
      <div className="mt-2 p-1 bg-sky-950/10 border border-sky-900/20 rounded flex justify-between text-[6px] text-sky-900 uppercase font-mono">
        <span>Bus: Fiber-Dyne</span>
        <span>Storage: SSD-Array [READY]</span>
      </div>
    </div>
  );
};
