
import React from 'react';

interface CreditsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreditsModal: React.FC<CreditsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[500] bg-black/95 backdrop-blur-md flex items-center justify-center p-4 md:p-8 crt-effect">
      <div className="w-full max-w-2xl border-2 border-amber-900 bg-[#0a0805] shadow-[0_0_100px_rgba(120,53,15,0.2)] rounded overflow-hidden flex flex-col relative">
        {/* Background "Stamp" Effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[120px] font-bold text-amber-900/5 select-none pointer-events-none rotate-12 leading-none uppercase text-center">
          Project<br/>2400
        </div>

        {/* Header */}
        <div className="bg-amber-950/20 p-4 border-b border-amber-900/30 flex justify-between items-center relative z-10">
          <div className="flex flex-col">
            <h2 className="text-amber-500 font-bold text-sm tracking-[0.2em] uppercase">Personnel Dossier</h2>
            <span className="text-[8px] text-amber-800 font-mono">ID_RECORD: 091945-ENIAC-CORE</span>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center border border-amber-900/50 text-amber-700 hover:text-amber-500 hover:border-amber-500 transition-all font-mono"
          >
            &times;
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-8 flex flex-col md:flex-row gap-8 relative z-10">
          {/* Photo Placeholder / ASCII */}
          <div className="w-full md:w-48 flex flex-col gap-4 shrink-0">
            <div className="aspect-square bg-black border-2 border-amber-900/40 p-2 relative flex items-center justify-center">
               <pre className="text-amber-800 text-[6px] leading-[1] select-none text-center">
{`
      .--------.
    /          \\
   |   ______   |
   |  /      \\  |
   | | AUTHOR | |
   |  \\______/  |
   |            |
   |   ######   |
    \\  ######  /
     '--------'
`}
               </pre>
               <div className="absolute top-2 right-2 flex gap-1">
                 <div className="w-1.5 h-1.5 rounded-full bg-red-900" />
                 <div className="w-1.5 h-1.5 rounded-full bg-amber-900 animate-pulse" />
               </div>
            </div>
            <div className="flex flex-col gap-1">
               <span className="text-[8px] text-amber-900 uppercase font-bold text-center tracking-widest">Security Clearance</span>
               <div className="h-1.5 bg-gray-950 rounded-full border border-amber-900/20 overflow-hidden">
                  <div className="h-full bg-amber-600" style={{ width: '95%' }} />
               </div>
               <span className="text-[7px] text-amber-700 text-center font-mono uppercase">Level 5: System Admin</span>
            </div>
          </div>

          {/* Details Section */}
          <div className="flex-1 space-y-6">
            <section>
              <h3 className="text-[9px] text-amber-900 font-bold uppercase mb-2 border-b border-amber-900/20 pb-1">Primary Subject</h3>
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-gray-400 tracking-tighter">Stephen Deline Jr</span>
                <span className="text-[10px] text-amber-600 font-mono uppercase tracking-widest mt-1">Lead System Architect & Core Engineer</span>
              </div>
            </section>

            <section className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="text-[8px] text-amber-900 font-bold uppercase mb-1">Affiliation</h4>
                <p className="text-[10px] text-amber-700 font-mono">University of Pennsylvania</p>
                <p className="text-[8px] text-amber-800 italic">Moore School of EE</p>
              </div>
              <div>
                <h4 className="text-[8px] text-amber-900 font-bold uppercase mb-1">Project</h4>
                <p className="text-[10px] text-amber-700 font-mono">Project 2400 (ENIAC Hub)</p>
                <p className="text-[8px] text-amber-800 italic">Core Dev Lead</p>
              </div>
            </section>

            <section>
              <h4 className="text-[8px] text-amber-900 font-bold uppercase mb-1">Technical Contributions</h4>
              <ul className="text-[9px] text-amber-800 space-y-1 font-mono list-inside">
                <li className="flex gap-2"><span>-</span> <span>Hybrid Dataflow Architecture Design</span></li>
                <li className="flex gap-2"><span>-</span> <span>Heuristic Gemini Logic Integration</span></li>
                <li className="flex gap-2"><span>-</span> <span>Real-time Register Visualization</span></li>
                <li className="flex gap-2"><span>-</span> <span>Procedural Vacuum Tube Simulation</span></li>
              </ul>
            </section>

            <div className="p-4 bg-amber-900/10 border border-amber-900/30 rounded italic">
              <p className="text-[9px] text-amber-700/80 leading-relaxed font-mono">
                "Preserving the legacy of 1945 computing through high-performance modern orchestration."
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-black border-t border-amber-900/30 flex justify-between items-center">
          <span className="text-[8px] text-amber-900 uppercase font-mono">Record Status: ARCHIVED / UNRESTRICTED</span>
          <button 
            onClick={onClose}
            className="bg-amber-600 hover:bg-amber-500 text-black font-bold py-1.5 px-6 text-[10px] uppercase tracking-widest transition-all"
          >
            Acknowledge & Return
          </button>
        </div>
      </div>
    </div>
  );
};
