
import React, { useState, useEffect } from 'react';

interface LoadingOverlayProps {
  message?: string;
}

export const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ message = "PROCESSING" }) => {
  const [dots, setDots] = useState('');
  
  const statuses = [
    "SYNCING CHRONO-PULSE",
    "PURGING ACCUMULATOR GHOSTS",
    "CALIBRATING TUBE FILAMENTS",
    "WIRING PLUGBOARD ARRAYS",
    "NORMALIZING MATRIX PARITY"
  ];
  
  const [statusIdx, setStatusIdx] = useState(0);

  useEffect(() => {
    const dTimer = setInterval(() => setDots(d => (d.length > 2 ? '' : d + '.')), 400);
    const sTimer = setInterval(() => setStatusIdx(i => (i + 1) % statuses.length), 2000);
    return () => { clearInterval(dTimer); clearInterval(sTimer); };
  }, []);

  return (
    <div className="absolute inset-0 z-[100] bg-black/60 backdrop-blur-[2px] flex items-center justify-center p-4 font-mono pointer-events-none">
      <div className="border border-amber-900 bg-black/90 p-6 flex flex-col items-center gap-4 shadow-[0_0_30px_rgba(0,0,0,1)]">
        <div className="flex gap-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="w-1.5 h-6 bg-amber-900/20 relative overflow-hidden">
               <div className="absolute bottom-0 w-full bg-amber-600 animate-[loading_1s_infinite]" style={{ height: '50%', animationDelay: `${i * 0.1}s` }} />
            </div>
          ))}
        </div>
        <div className="text-center">
          <div className="text-amber-500 font-bold text-xs uppercase tracking-widest">{message}{dots}</div>
          <div className="text-amber-900 text-[8px] mt-1 uppercase tracking-tighter">{statuses[statusIdx]}</div>
        </div>
      </div>
    </div>
  );
};
