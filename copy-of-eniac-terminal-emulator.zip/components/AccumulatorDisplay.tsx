
import React from 'react';

interface AccumulatorDisplayProps {
  id: number;
  value: string;
  active: boolean;
}

export const AccumulatorDisplay: React.FC<AccumulatorDisplayProps> = ({ id, value, active }) => {
  return (
    <div className={`p-2 border border-gray-700 bg-black rounded flex flex-col gap-1 transition-colors ${active ? 'border-red-900' : ''}`}>
      <div className="flex justify-between items-center px-1">
        <span className="text-[10px] text-gray-500">ACCUMULATOR {id.toString().padStart(2, '0')}</span>
        <div className={`w-2 h-2 rounded-full ${active ? 'bg-red-600 animate-pulse' : 'bg-gray-800'}`} />
      </div>
      <div className="flex gap-1 font-mono text-xl tracking-widest text-red-500 glow-amber">
        {value.split('').map((digit, i) => (
          <span key={i} className="w-4 text-center border-b border-gray-900">{digit}</span>
        ))}
      </div>
    </div>
  );
};
