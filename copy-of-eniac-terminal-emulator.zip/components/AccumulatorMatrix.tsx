
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { AccumulatorState } from '../types';

interface AccumulatorMatrixProps {
  accumulators: AccumulatorState[];
  isTurbo: boolean;
}

interface RAMTransaction {
  id: string;
  type: 'READ' | 'WRITE';
  accId: number;
  timestamp: number;
}

/**
 * Utility to convert decimal string to padded binary
 */
const toBinary = (decimalStr: string, bits: number = 34): string => {
  try {
    const num = BigInt(decimalStr);
    return num.toString(2).padStart(bits, '0');
  } catch {
    return '0'.repeat(bits);
  }
};

/**
 * Utility to convert decimal string to padded hex
 */
const toHex = (decimalStr: string): string => {
  try {
    const num = BigInt(decimalStr);
    return '0x' + num.toString(16).toUpperCase().padStart(9, '0');
  } catch {
    return '0x000000000';
  }
};

/**
 * Formats binary string for readability (groups of 8)
 */
const formatBinary = (bin: string): string => {
  return bin.match(/.{1,8}/g)?.join(' ') || bin;
};

type ViewMode = 'GRID' | 'INSPECTOR' | 'BITSTREAM' | 'BINARY';
type SortDirection = 'ASC' | 'DESC' | 'NONE';
type SortKey = 'ID' | 'VALUE';
type InspectorSubMode = 'BIN' | 'DEC';

export const AccumulatorMatrix: React.FC<AccumulatorMatrixProps> = ({ accumulators, isTurbo }) => {
  const [viewMode, setViewMode] = useState<ViewMode>('GRID');
  const [inspectorSubMode, setInspectorSubMode] = useState<InspectorSubMode>('BIN');
  const [sortKey, setSortKey] = useState<SortKey>('ID');
  const [sortDir, setSortDir] = useState<SortDirection>('NONE');
  const prevValuesRef = useRef<Record<number, string>>({});
  const [flippedBits, setFlippedBits] = useState<Record<number, boolean[]>>({});
  const [transactions, setTransactions] = useState<RAMTransaction[]>([]);

  // Track bit flips and RAM transactions
  useEffect(() => {
    const newFlipped: Record<number, boolean[]> = {};
    const newTransactions: Record<number, RAMTransaction> = {};

    accumulators.forEach(acc => {
      const prevVal = prevValuesRef.current[acc.id] || "0";
      const currentVal = acc.value;
      
      const prevBin = toBinary(prevVal);
      const currentBin = toBinary(currentVal);
      
      if (prevBin !== currentBin) {
        // This is a Write operation
        if (viewMode === 'BINARY' || viewMode === 'BITSTREAM') {
          const flips = currentBin.split('').map((bit, i) => bit !== prevBin[i]);
          newFlipped[acc.id] = flips;
        }
        newTransactions[acc.id] = {
          id: Math.random().toString(36).substr(2, 9),
          type: 'WRITE',
          accId: acc.id,
          timestamp: Date.now()
        };
      } else if (acc.active) {
        // This is a Read operation (active but no value change)
        newTransactions[acc.id] = {
          id: Math.random().toString(36).substr(2, 9),
          type: 'READ',
          accId: acc.id,
          timestamp: Date.now()
        };
      }
      prevValuesRef.current[acc.id] = acc.value;
    });

    const txArray = Object.values(newTransactions);
    if (txArray.length > 0) {
      setTransactions(prev => [...txArray, ...prev].slice(0, 32));
    }

    if (Object.keys(newFlipped).length > 0) {
      setFlippedBits(newFlipped);
      const timer = setTimeout(() => setFlippedBits({}), 600);
      return () => clearTimeout(timer);
    }
  }, [accumulators, viewMode]);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(prev => {
        if (prev === 'NONE') return 'ASC';
        if (prev === 'ASC') return 'DESC';
        return 'NONE';
      });
    } else {
      setSortKey(key);
      setSortDir('ASC');
    }
  };

  const content = useMemo(() => {
    if (!isTurbo || viewMode === 'GRID') {
      return (
        <div className={`grid gap-1 ${isTurbo ? 'grid-cols-8' : 'grid-cols-1'}`}>
          {accumulators.map((acc) => (
            isTurbo ? (
              <div 
                key={acc.id} 
                className={`aspect-square border flex flex-col items-center justify-center relative transition-all duration-300 group ${
                  acc.active 
                  ? 'border-cyan-400 bg-cyan-900/40' 
                  : 'border-cyan-900/30 bg-black/40'
                }`}
              >
                <span className="text-[6px] text-cyan-900 absolute top-0.5 left-0.5">{acc.id}</span>
                <div className={`w-1 h-1 rounded-full ${acc.active ? 'bg-cyan-400 shadow-[0_0_4px_cyan]' : 'bg-gray-900'}`} />
                {acc.active && (
                   <div className="absolute inset-0 bg-cyan-400/10 animate-ping pointer-events-none" />
                )}
                
                {/* Hover Tooltip for Grid Mode */}
                <div className="absolute invisible group-hover:visible z-50 bottom-full mb-2 p-2 bg-black border border-cyan-800 text-[8px] font-mono text-cyan-400 whitespace-nowrap shadow-xl">
                  <div className="text-cyan-700 mb-1 border-b border-cyan-950 pb-0.5 font-bold uppercase">Register {acc.id}</div>
                  <div>DEC: {acc.value}</div>
                  <div>HEX: {toHex(acc.value)}</div>
                  <div className="mt-1 text-[7px] text-cyan-900 leading-tight">BIN: {formatBinary(toBinary(acc.value))}</div>
                </div>
              </div>
            ) : (
              <AccumulatorDetail key={acc.id} {...acc} />
            )
          ))}
        </div>
      );
    }

    if (viewMode === 'BITSTREAM') {
      return (
        <div className="flex flex-col gap-4">
          <div className="space-y-2">
             <div className="text-[7px] text-cyan-900 uppercase font-mono tracking-widest border-b border-cyan-900/30 pb-1 flex justify-between">
              <span>RAM Buffer Traffic Monitor</span>
              <span className="text-[6px] opacity-50">Pulse History (n=32)</span>
            </div>
            <div className="flex gap-1 h-10 items-end bg-black/40 p-1 rounded border border-cyan-900/10 overflow-hidden">
              {transactions.length === 0 ? (
                <div className="w-full text-center text-[6px] text-cyan-900/30 my-auto uppercase">Awaiting transaction...</div>
              ) : (
                transactions.map((tx, idx) => (
                  <div 
                    key={tx.id}
                    className={`flex-1 rounded-t-sm animate-pulse transition-all ${
                      tx.type === 'WRITE' ? 'bg-amber-500 shadow-[0_0_4px_orange]' : 'bg-cyan-500 shadow-[0_0_4px_cyan]'
                    }`}
                    style={{ 
                      height: `${100 - (idx * 2.5)}%`,
                      opacity: 1 - (idx * 0.03)
                    }}
                  />
                ))
              )}
            </div>
          </div>

          {/* Physical RAM Buffer Map Section */}
          <div className="space-y-2">
            <div className="text-[7px] text-cyan-900 uppercase font-mono tracking-widest border-b border-cyan-900/30 pb-1 flex justify-between">
              <span>Physical RAM Buffer Map</span>
              <span className="text-[6px] opacity-50">Cell Access Topology</span>
            </div>
            <div className="grid grid-cols-[repeat(16,minmax(0,1fr))] gap-[1px] p-1 bg-black/60 border border-cyan-900/20 rounded shadow-inner">
              {Array.from({ length: isTurbo ? 128 : 20 }).map((_, i) => {
                const id = i + 1;
                const latestTx = transactions.find(t => t.accId === id);
                const timeDiff = latestTx ? Date.now() - latestTx.timestamp : Infinity;
                const isActive = timeDiff < 1000;
                const opacity = Math.max(0, 1 - timeDiff / 1000);
                
                return (
                  <div 
                    key={id}
                    className={`aspect-square rounded-[1px] transition-all duration-300 ${
                      isActive 
                        ? (latestTx?.type === 'WRITE' 
                            ? 'bg-amber-500 shadow-[0_0_8px_orange] scale-110' 
                            : 'bg-cyan-500 shadow-[0_0_8px_cyan] scale-110')
                        : 'bg-cyan-950/10'
                    }`}
                    style={{ 
                      opacity: isActive ? 1 : 0.2,
                      background: isActive 
                        ? (latestTx?.type === 'WRITE' ? `rgba(245, 158, 11, ${opacity})` : `rgba(6, 182, 212, ${opacity})`)
                        : undefined
                    }}
                    title={`Register ${id} - ${latestTx?.type || 'IDLE'}`}
                  />
                );
              })}
            </div>
            <div className="flex justify-between text-[5px] text-cyan-900/50 uppercase font-mono px-1">
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-cyan-500 rounded-sm"></div> READ PULSE</span>
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-amber-500 rounded-sm"></div> WRITE COMMIT</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-[7px] text-cyan-900 uppercase font-mono tracking-widest border-b border-cyan-900/30 pb-1">
              Raw Bit-Plane Dispatch (128x34)
            </div>
            <div className="flex flex-wrap gap-[1px] leading-[0]">
              {accumulators.map((acc) => {
                const bits = toBinary(acc.value);
                const flips = flippedBits[acc.id];
                const isRecentWrite = transactions.some(t => t.accId === acc.id && t.type === 'WRITE' && (Date.now() - t.timestamp < 300));
                
                return bits.split('').map((bit, i) => (
                  <div 
                    key={`${acc.id}-${i}`}
                    className={`w-[3px] h-[3px] rounded-[1px] transition-colors duration-300 ${
                      flips && flips[i]
                      ? 'bg-white shadow-[0_0_4px_white] z-10 scale-125'
                      : bit === '1' 
                        ? (acc.active 
                            ? (isRecentWrite ? 'bg-amber-400 shadow-[0_0_2px_orange]' : 'bg-cyan-400 shadow-[0_0_2px_cyan]') 
                            : 'bg-cyan-700') 
                        : 'bg-gray-900'
                    }`}
                  />
                ));
              })}
            </div>
          </div>
        </div>
      );
    }

    if (viewMode === 'BINARY') {
      return (
        <div className="flex flex-col gap-1 font-mono">
          <div className="sticky top-0 bg-[#0a0a0a] z-10 flex px-2 py-1 border-b border-cyan-900/50 text-[7px] text-cyan-800 uppercase font-bold">
            <span className="w-8">ID</span>
            <span>34-BIT WORD VECTOR (ALIGNED)</span>
          </div>
          <div className="space-y-0.5">
            {accumulators.map((acc) => {
              const bits = toBinary(acc.value);
              const flips = flippedBits[acc.id];
              return (
                <div 
                  key={acc.id} 
                  className={`flex px-2 py-0.5 border-b border-cyan-900/5 transition-colors ${
                    acc.active ? 'bg-cyan-950/20' : ''
                  }`}
                >
                  <span className={`w-8 text-[7px] font-bold ${acc.active ? 'text-cyan-400' : 'text-cyan-900'}`}>
                    {acc.id.toString().padStart(3, '0')}
                  </span>
                  <div className="flex gap-1">
                    {bits.match(/.{1,8}/g)?.map((chunk, chunkIdx) => (
                      <span key={chunkIdx} className="flex gap-0.5">
                        {chunk.split('').map((bit, bitIdx) => {
                          const globalIdx = chunkIdx * 8 + bitIdx;
                          const isFlipped = flips && flips[globalIdx];
                          return (
                            <span 
                              key={bitIdx} 
                              className={`text-[7px] transition-all duration-300 ${
                                isFlipped 
                                ? 'text-white font-bold scale-125 glow-cyan' 
                                : bit === '1' 
                                  ? (acc.active ? 'text-cyan-400' : 'text-cyan-700') 
                                  : 'text-gray-900'
                              }`}
                            >
                              {bit}
                            </span>
                          );
                        })}
                        {chunkIdx < 3 && <span className="text-[7px] text-cyan-950 mx-0.5">|</span>}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      );
    }

    // INSPECTOR MODE (Turbo Only)
    const sortedAccs = [...accumulators].sort((a, b) => {
      if (sortDir === 'NONE') return a.id - b.id;
      
      let valA: bigint | number;
      let valB: bigint | number;

      if (sortKey === 'ID') {
        valA = BigInt(a.id);
        valB = BigInt(b.id);
      } else {
        valA = BigInt(a.value);
        valB = BigInt(b.value);
      }

      const diff = valA < valB ? -1 : valA > valB ? 1 : 0;
      return sortDir === 'ASC' ? diff : -diff;
    });

    return (
      <div className="flex flex-col gap-1 font-mono">
        <div className={`sticky top-0 bg-[#0a0a0a] z-10 grid gap-2 px-2 py-1 border-b border-cyan-900/50 text-[7px] text-cyan-800 uppercase font-bold select-none grid-cols-[40px_1fr]`}>
          <span 
            className="cursor-pointer hover:text-cyan-400 flex items-center gap-1" 
            onClick={() => handleSort('ID')}
          >
            ID
            {sortKey === 'ID' && sortDir !== 'NONE' && (
              <span className="text-cyan-500">{sortDir === 'ASC' ? '▲' : '▼'}</span>
            )}
          </span>
          <span 
            className="cursor-pointer hover:text-cyan-400 flex items-center gap-1"
            onClick={() => handleSort('VALUE')}
          >
            {inspectorSubMode === 'BIN' ? 'RAW BINARY / HEXADECIMAL' : 'DECIMAL INTERPRETATION'}
            {sortKey === 'VALUE' && sortDir !== 'NONE' && (
              <span className="text-cyan-500">{sortDir === 'ASC' ? '▲' : '▼'}</span>
            )}
          </span>
        </div>
        <div className="space-y-0.5">
          {sortedAccs.map((acc) => (
            <div 
              key={acc.id} 
              className={`grid gap-2 px-2 py-1 border-b border-cyan-900/10 transition-colors ${
                acc.active ? 'bg-cyan-950/30 text-cyan-400' : 'text-cyan-900'
              } grid-cols-[40px_1fr]`}
            >
              <span className="text-[8px] font-bold">{acc.id.toString().padStart(3, '0')}</span>
              {inspectorSubMode === 'BIN' ? (
                <div className="flex flex-col gap-0.5">
                  <span className="text-[7px] tracking-tighter opacity-80 leading-none font-mono">
                    {formatBinary(toBinary(acc.value))}
                  </span>
                  <span className="text-[7px] font-bold text-cyan-600/60 leading-none">
                    {toHex(acc.value)}
                  </span>
                </div>
              ) : (
                <span className="text-[10px] font-bold font-mono tracking-widest flex items-center">
                  {acc.value}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }, [accumulators, isTurbo, viewMode, sortKey, sortDir, flippedBits, inspectorSubMode, transactions]);

  return (
    <div className="flex flex-col h-full">
      <div className={`text-[10px] uppercase mb-3 flex items-center justify-between font-bold ${isTurbo ? 'text-cyan-600' : 'text-gray-600'}`}>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isTurbo ? 'bg-cyan-500 shadow-[0_0_5px_cyan]' : 'bg-amber-600'}`}></div>
          {isTurbo ? (
            viewMode === 'GRID' ? 'Register Matrix' : 
            viewMode === 'INSPECTOR' ? 'Dataflow Inspector' : 
            viewMode === 'BINARY' ? 'Binary Word Vector' : 'Bit-Stream'
          ) : 'Accumulator Matrix'}
        </div>
        
        {isTurbo && (
          <div className="flex items-center gap-1">
            {viewMode === 'INSPECTOR' && (
              <div className="flex items-center gap-2 mr-2 pr-2 border-r border-cyan-900/30">
                <span className="text-[6px] text-cyan-900 uppercase">Interpretation:</span>
                <button 
                  onClick={() => setInspectorSubMode(prev => prev === 'BIN' ? 'DEC' : 'BIN')}
                  className="relative w-8 h-4 bg-black border border-cyan-900/50 rounded-full transition-all hover:border-cyan-400 group"
                  title={`Switch to ${inspectorSubMode === 'BIN' ? 'Decimal' : 'Binary'}`}
                >
                  <div className={`absolute top-0.5 w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                    inspectorSubMode === 'BIN' 
                    ? 'left-0.5 bg-cyan-900' 
                    : 'left-4.5 bg-cyan-400 shadow-[0_0_8px_cyan]'
                  }`} />
                  {/* Label overlay for the toggle */}
                  <span className={`absolute -top-3 left-1/2 -translate-x-1/2 text-[5px] transition-colors ${inspectorSubMode === 'BIN' ? 'text-cyan-900' : 'text-cyan-400'}`}>
                    {inspectorSubMode}
                  </span>
                </button>
              </div>
            )}
            <button 
              onClick={() => setViewMode('GRID')}
              className={`text-[7px] border px-1.5 py-0.5 transition-colors ${viewMode === 'GRID' ? 'bg-cyan-800 text-black border-cyan-400' : 'bg-transparent text-cyan-800 border-cyan-900 hover:border-cyan-600'}`}
            >
              GRID
            </button>
            <button 
              onClick={() => setViewMode('INSPECTOR')}
              className={`text-[7px] border px-1.5 py-0.5 transition-colors ${viewMode === 'INSPECTOR' ? 'bg-cyan-800 text-black border-cyan-400' : 'bg-transparent text-cyan-800 border-cyan-900 hover:border-cyan-600'}`}
            >
              INSPECT
            </button>
            <button 
              onClick={() => setViewMode('BINARY')}
              className={`text-[7px] border px-1.5 py-0.5 transition-colors ${viewMode === 'BINARY' ? 'bg-cyan-800 text-black border-cyan-400' : 'bg-transparent text-cyan-800 border-cyan-900 hover:border-cyan-600'}`}
            >
              BIN
            </button>
            <button 
              onClick={() => setViewMode('BITSTREAM')}
              className={`text-[7px] border px-1.5 py-0.5 transition-colors ${viewMode === 'BITSTREAM' ? 'bg-cyan-800 text-black border-cyan-400' : 'bg-transparent text-cyan-800 border-cyan-900 hover:border-cyan-600'}`}
            >
              BITS
            </button>
          </div>
        )}
      </div>
      
      <div className="flex-1 overflow-y-auto pr-2 scrollbar-hide">
        {content}
      </div>
      
      {isTurbo && (
        <div className="mt-3 p-2 bg-black border border-cyan-900/30 rounded">
          <div className="text-[7px] text-cyan-700 uppercase mb-1 flex justify-between">
            <span>Microcode Scheduler</span>
            <span className="animate-pulse">CYC: 111ps</span>
          </div>
          <div className="h-1 bg-gray-900 overflow-hidden">
            <div className="h-full bg-cyan-600 animate-[loading_2s_infinite]" style={{ width: '60%', transition: 'all 0.1s linear' }} />
          </div>
        </div>
      )}
    </div>
  );
};

const AccumulatorDetail: React.FC<AccumulatorState> = ({ id, value, active }) => (
  <div className={`p-2 border border-gray-700 bg-black rounded flex flex-col gap-1 transition-colors ${active ? 'border-red-900' : ''}`}>
    <div className="flex justify-between items-center px-1">
      <span className="text-[10px] text-gray-500 font-bold">ACCUMULATOR {id.toString().padStart(2, '0')}</span>
      <div className={`w-2 h-2 rounded-full ${active ? 'bg-red-600 animate-pulse shadow-[0_0_5px_red]' : 'bg-gray-800'}`} />
    </div>
    <div className="flex gap-1 font-mono text-xl tracking-widest text-red-500 glow-amber">
      {value.split('').map((digit, i) => (
        <span key={i} className="w-4 text-center border-b border-gray-900">{digit}</span>
      ))}
    </div>
  </div>
);
