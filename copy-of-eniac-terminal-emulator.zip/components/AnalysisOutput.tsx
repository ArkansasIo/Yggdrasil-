
import React, { useMemo, useEffect, useRef } from 'react';

interface AnalysisResult {
  id: string;
  value: string;
  timestamp: Date;
}

interface AnalysisOutputProps {
  history: AnalysisResult[];
  isTurbo: boolean;
}

export const AnalysisOutput: React.FC<AnalysisOutputProps> = ({ history, isTurbo }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const latest = history.length > 0 ? history[0] : null;

  // Numerical analysis of the latest result
  const analysis = useMemo(() => {
    if (!latest) return null;
    try {
      const num = BigInt(latest.value);
      return {
        parity: num % 2n === 0n ? 'EVEN' : 'ODD',
        binary: num.toString(2).padStart(34, '0'),
        hex: '0x' + num.toString(16).toUpperCase().padStart(9, '0'),
        sci: num.toString()[0] + '.' + num.toString().slice(1, 5) + 'e' + (num.toString().length - 1),
        isPrimeSim: num % 3n === 0n ? 'COMPOSITE' : 'UNKNOWN (PRIME PROBABLE)',
      };
    } catch {
      return null;
    }
  }, [latest]);

  // Oscilloscope Plot Drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw Grid
    ctx.strokeStyle = '#064e3b';
    ctx.lineWidth = 0.5;
    const step = 20;
    for (let x = 0; x <= canvas.width; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y <= canvas.height; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    if (history.length < 2) return;

    // Draw Plot Line
    ctx.strokeStyle = '#22c55e';
    ctx.lineWidth = 2;
    ctx.shadowBlur = 8;
    ctx.shadowColor = '#22c55e';
    ctx.beginPath();

    const points = [...history].reverse().slice(-15);
    const maxVal = points.reduce((max, p) => {
      const v = Number(p.value.slice(0, 5)); // Just take first few digits for scale
      return v > max ? v : max;
    }, 100);

    points.forEach((p, i) => {
      const x = (i / (points.length - 1)) * canvas.width;
      const v = Number(p.value.slice(0, 5));
      const y = canvas.height - (v / maxVal) * (canvas.height - 20) - 10;
      
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.shadowBlur = 0;

  }, [history]);

  return (
    <div className="flex flex-col h-full border-2 border-green-900 bg-[#020617] rounded-lg overflow-hidden shadow-2xl crt-effect">
      <div className="bg-green-950/30 px-3 py-1 flex justify-between items-center border-b border-green-900">
        <span className="text-[9px] font-bold text-green-500 uppercase tracking-widest flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
          Precision Analysis Plotter
        </span>
        <span className="text-[7px] text-green-800 font-mono">TYPE: CRT-V4</span>
      </div>

      <div className="flex-1 p-3 overflow-hidden flex flex-col gap-3">
        {/* Plot Area */}
        <div className="h-28 bg-black border border-green-900/50 rounded relative group">
          <canvas 
            ref={canvasRef} 
            width={300} 
            height={110} 
            className="w-full h-full opacity-80"
          />
          <div className="absolute top-1 left-1 text-[6px] text-green-900 uppercase font-mono">
            Trend Vector: {history.length} cycles
          </div>
          <div className="absolute bottom-1 right-1 text-[6px] text-green-900 uppercase font-mono">
            Timebase: 100ms/div
          </div>
        </div>

        {/* Breakdown Panel */}
        <div className="flex-1 grid grid-cols-2 gap-2 overflow-hidden">
          {/* Latest Stats */}
          <div className="flex flex-col gap-2">
            <div className="text-[8px] text-green-700 font-bold uppercase border-b border-green-900/30">Numeric Attributes</div>
            {analysis ? (
              <div className="space-y-1 font-mono text-[8px]">
                <div className="flex justify-between">
                  <span className="text-green-900">PARITY</span>
                  <span className="text-green-400">{analysis.parity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-900">HEX</span>
                  <span className="text-green-400">{analysis.hex}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-900">SCIENTIFIC</span>
                  <span className="text-green-400">{analysis.sci}</span>
                </div>
                <div className="flex flex-col mt-1">
                  <span className="text-green-900 text-[6px]">BINARY VECTOR</span>
                  <span className="text-green-500 text-[6px] break-all leading-tight">{analysis.binary}</span>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-[7px] text-green-950 uppercase italic">
                Awaiting Data Input...
              </div>
            )}
          </div>

          {/* Result Log */}
          <div className="flex flex-col gap-2 overflow-hidden">
             <div className="text-[8px] text-green-700 font-bold uppercase border-b border-green-900/30">Result Stack</div>
             <div className="flex-1 overflow-y-auto space-y-1 pr-1 scrollbar-hide">
                {history.length === 0 ? (
                  <div className="text-[7px] text-green-950 py-4 text-center">EMPTY</div>
                ) : (
                  history.map((h) => (
                    <div key={h.id} className="flex flex-col border-b border-green-900/10 pb-0.5">
                      <div className="flex justify-between text-[6px] text-green-900">
                        <span>{h.timestamp.toLocaleTimeString([], { hour12: false })}</span>
                        <span className="text-green-600">ID: {h.id.slice(-4)}</span>
                      </div>
                      <div className="text-[9px] text-green-400 font-mono glow-green">{h.value}</div>
                    </div>
                  ))
                )}
             </div>
          </div>
        </div>
      </div>

      <div className="p-1 px-3 bg-black border-t border-green-900/30 flex justify-between items-center">
        <span className="text-[6px] text-green-900 uppercase">Analysis Engine: Active</span>
        <div className="flex gap-1">
          <div className="w-1 h-1 bg-green-900 rounded-full animate-pulse" />
          <div className="w-1 h-1 bg-green-900 rounded-full animate-pulse delay-75" />
          <div className="w-1 h-1 bg-green-900 rounded-full animate-pulse delay-150" />
        </div>
      </div>
    </div>
  );
};
