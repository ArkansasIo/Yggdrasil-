
import React, { useState, useEffect } from 'react';
import { audioService } from '../services/audioService';

interface SplashScreenProps {
  onComplete: () => void;
}

const BOOT_SEQUENCE = [
  { msg: "KERNEL: ENIAC-OS V3.0.4-LTS (STABLE)", delay: 100 },
  { msg: "AUTHOR: STEPHEN DELINE JR [VERIFIED]", delay: 300 },
  { msg: "CORE ARCHITECT: S. DELINE JR", delay: 200 },
  { msg: "CPU: VIRTUALIZED VACUUM TUBE ARRAY [100.000 KC]", delay: 200 },
  { msg: "MEMORY: 20x10-DIGIT DECIMAL ACCUMULATORS", delay: 150 },
  { msg: "BUS: PARALLEL DIGIT TRUNK [34-BIT SERIAL]", delay: 300 },
  { msg: "CHECKING FILAMENT STABILITY...", delay: 800, post: true },
  { msg: "CALIBRATING FUNCTION TABLES 1-3...", delay: 400 },
  { msg: "LINKING CONSTANT TRANSMITTER...", delay: 500 },
  { msg: "INITIALIZING GEMINI HEURISTIC ENGINE...", delay: 600 },
  { msg: "MOUNTING /DEV/PUNCHED_CARDS...", delay: 300 },
  { msg: "PARITY CHECK: PASSING ALL BANKS", delay: 200 },
  { msg: "BOOTING INTO USERSPACE...", delay: 400 },
];

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [logs, setLogs] = useState<{ msg: string; status: 'OK' | 'WAIT' | 'FAIL' | 'NONE' }[]>([]);
  const [progress, setProgress] = useState(0);
  const [bootStage, setBootStage] = useState<'IDLE' | 'POST' | 'LOADING' | 'READY'>('IDLE');
  const [tubeWarmth, setTubeWarmth] = useState<number[]>(new Array(64).fill(0));

  useEffect(() => {
    let mounted = true;
    let timeouts: any[] = [];

    const runStep = (idx: number) => {
      if (!mounted) return;

      if (idx >= BOOT_SEQUENCE.length) {
        setBootStage('READY');
        const finalTimer = setTimeout(() => {
          if (mounted) onComplete();
        }, 3000); // Extended delay to show credits
        timeouts.push(finalTimer);
        return;
      }

      const step = BOOT_SEQUENCE[idx];
      setLogs(prev => [...prev, { msg: step.msg, status: 'WAIT' }]);
      
      if (step.post) {
        setBootStage('POST');
      }

      const timer = setTimeout(() => {
        if (!mounted) return;
        
        setLogs(prev => {
          const next = [...prev];
          const lastIdx = next.length - 1;
          if (next[lastIdx]) {
            next[lastIdx].status = 'OK';
          }
          return next;
        });

        audioService.playClick('CLASSIC');
        setProgress(((idx + 1) / BOOT_SEQUENCE.length) * 100);
        runStep(idx + 1);
      }, step.delay);
      timeouts.push(timer);
    };

    const initialTimer = setTimeout(() => {
      if (mounted) {
        audioService.playPowerUp();
        setBootStage('LOADING');
        runStep(0);
      }
    }, 500);
    timeouts.push(initialTimer);

    return () => {
      mounted = false;
      timeouts.forEach(clearTimeout);
    };
  }, [onComplete]);

  useEffect(() => {
    if (bootStage === 'POST' || bootStage === 'READY') {
      const interval = setInterval(() => {
        setTubeWarmth(prev => prev.map(v => Math.min(100, v + Math.random() * 20)));
      }, 50);
      const timer = setTimeout(() => clearInterval(interval), 2000);
      return () => {
        clearInterval(interval);
        clearTimeout(timer);
      };
    }
  }, [bootStage]);

  return (
    <div className="fixed inset-0 bg-[#020202] z-[200] flex flex-col items-center justify-center p-8 font-mono crt-effect overflow-hidden">
      <div className="max-w-3xl w-full flex flex-col gap-8 relative">
        <div className="absolute -top-20 -left-20 w-64 h-64 bg-amber-900/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-red-900/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="flex flex-col items-center">
          <pre className="text-amber-500 text-[8px] sm:text-[10px] leading-none mb-4 glow-amber select-none opacity-90 transition-all duration-1000 scale-100">
{`
    ███████╗███╗   ██╗██╗ █████╗  ██████╗ 
    ██╔════╝████╗  ██║██║██╔══██╗██╔════╝ 
    █████╗  ██╔██╗ ██║██║███████║██║      
    ██╔══╝  ██║╚██╗██║██║██╔══██║██║      
    ███████╗██║ ╚████║██║██║  ██║╚██████╗ 
    ╚══════╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═╝ ╚═════╝ 
`}
          </pre>
          <div className="h-0.5 w-full max-w-md bg-gradient-to-r from-transparent via-amber-900/50 to-transparent mb-1" />
          <p className="text-[10px] text-amber-700 tracking-[0.4em] uppercase font-bold text-center">
            Digital Computing Excellence Since 1945
          </p>
          
          {bootStage === 'READY' && (
            <div className="mt-6 flex flex-col items-center animate-in fade-in slide-in-from-bottom-4 duration-1000">
              <div className="bg-amber-900/10 border border-amber-900/30 p-4 rounded backdrop-blur-sm">
                <p className="text-[11px] text-amber-500 font-bold mb-2 uppercase tracking-widest text-center">System Credits</p>
                <div className="grid grid-cols-2 gap-x-8 gap-y-1 text-[9px] font-mono">
                  <span className="text-amber-800 text-right uppercase">Lead Architect:</span>
                  <span className="text-amber-400 font-bold uppercase">Stephen Deline Jr</span>
                  <span className="text-amber-800 text-right uppercase">Project Lead:</span>
                  <span className="text-amber-400 font-bold uppercase">Stephen Deline Jr</span>
                  <span className="text-amber-800 text-right uppercase">Infrastructure:</span>
                  <span className="text-amber-400 font-bold uppercase">Moore School Cluster</span>
                  <span className="text-amber-800 text-right uppercase">Compute Engine:</span>
                  <span className="text-amber-400 font-bold uppercase">Gemini 3 Pro</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-[1fr_200px] gap-6 bg-black/40 border border-amber-900/20 p-6 rounded shadow-inner">
          <div className="flex flex-col h-64 overflow-hidden border-r border-amber-900/10 pr-4">
            <div className="text-[9px] text-amber-900 font-bold mb-3 border-b border-amber-900/30 pb-1 flex justify-between">
              <span>SYSTEM_BOOT_TRACELOG</span>
              <span className="animate-pulse">@0x{progress.toFixed(0).padStart(2, '0').toUpperCase()}</span>
            </div>
            <div className="flex-1 space-y-1 overflow-y-auto scrollbar-hide">
              {logs.map((log, i) => (
                <div key={i} className="flex justify-between items-start group">
                  <div className="flex gap-2">
                    <span className="text-amber-900 opacity-50 text-[9px]">{i.toString().padStart(2, '0')}</span>
                    <span className={`text-[11px] ${log.status === 'WAIT' ? 'text-amber-300 animate-pulse' : 'text-amber-700'}`}>
                      {log.msg}
                    </span>
                  </div>
                  {log.status === 'OK' && <span className="text-amber-500 text-[10px] font-bold">[PASS]</span>}
                </div>
              ))}
              {bootStage === 'READY' && (
                <div className="mt-4 text-green-500 glow-green text-xs font-bold border border-green-900/50 bg-green-950/20 p-2 text-center animate-pulse">
                  *** KERNEL INITIALIZED: SYSTEM READY ***
                </div>
              )}
            </div>
          </div>

          <div className="hidden md:flex flex-col">
            <div className="text-[9px] text-amber-900 font-bold mb-3 border-b border-amber-900/30 pb-1 text-center">
              HW_TEST: FILAMENTS
            </div>
            <div className="grid grid-cols-8 gap-1 p-1 bg-black rounded border border-amber-900/10">
              {tubeWarmth.map((val, i) => (
                <div 
                  key={i} 
                  className="w-full aspect-[1/2] rounded-[1px] transition-all duration-300 border border-white/5"
                  style={{ 
                    background: val > 0 
                      ? `radial-gradient(circle at center, rgba(217, 119, 6, ${val/100}) 0%, rgba(120, 53, 15, ${val/200}) 100%)`
                      : '#050505',
                    boxShadow: val > 50 ? `0 0 ${val/10}px rgba(217, 119, 6, 0.4)` : 'none'
                  }}
                />
              ))}
            </div>
            <div className="mt-auto pt-4 flex flex-col gap-1">
               <div className="flex justify-between text-[7px] text-amber-900">
                  <span>PLATE VOLTAGE</span>
                  <span>+150V DC</span>
               </div>
               <div className="h-1 bg-gray-900 rounded-full overflow-hidden">
                  <div className="h-full bg-red-900/50" style={{ width: `${progress}%` }} />
               </div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-end">
            <div className="flex flex-col">
               <span className="text-[8px] text-amber-900 uppercase font-bold">Kernel Loading Status</span>
               <span className="text-[7px] text-amber-700 italic opacity-50">Moore School of Electrical Engineering | Project 2400</span>
            </div>
            <span className="text-xs font-bold text-amber-500 glow-amber">{Math.floor(progress)}%</span>
          </div>
          <div className="w-full h-1.5 bg-gray-900 rounded-full overflow-hidden p-[1px] border border-amber-900/20">
            <div 
              className="h-full bg-gradient-to-r from-amber-900 via-amber-600 to-amber-400 shadow-[0_0_15px_rgba(217,119,6,0.6)] transition-all duration-500 ease-out" 
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 text-center">
        <p className="text-[9px] text-amber-900/40 uppercase tracking-[0.5em]">
          University of Pennsylvania - Restricted Access Cluster
        </p>
      </div>
    </div>
  );
};
