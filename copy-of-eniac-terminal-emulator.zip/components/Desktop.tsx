
import React from 'react';
import { FileSystemEntry, UserProfile } from '../types';

interface DesktopProps {
  currentPath: string;
  entries: FileSystemEntry[];
  user: UserProfile | null;
  onNavigate: (path: string) => void;
  onOpenFile: (file: FileSystemEntry) => void;
}

export const Desktop: React.FC<DesktopProps> = ({ currentPath, entries, user, onNavigate, onOpenFile }) => {
  return (
    <div className="h-full w-full bg-[#020202] border-2 border-gray-800 rounded-lg overflow-hidden flex flex-col crt-effect shadow-2xl">
      <div className="bg-gray-900/50 px-4 py-1 flex justify-between items-center border-b border-gray-800 text-[9px] uppercase tracking-widest text-gray-400 font-mono">
        <div className="flex items-center gap-4">
          <span className="text-amber-500 font-bold">WORKSPACE: {currentPath}</span>
          <span className="opacity-40">User: {user?.username} ({user?.role})</span>
        </div>
        <div className="flex gap-2">
          <div className="w-2 h-2 rounded-full bg-red-900 shadow-[0_0_5px_red] animate-pulse"></div>
          <div className="w-2 h-2 rounded-full bg-amber-900"></div>
        </div>
      </div>

      <div className="flex-1 p-6 grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-6 overflow-y-auto scrollbar-hide">
        {currentPath !== '/' && (
          <button 
            onClick={() => onNavigate('..')}
            className="flex flex-col items-center gap-2 group"
          >
            <div className="w-12 h-12 flex items-center justify-center border border-gray-800 bg-gray-900/20 group-hover:bg-amber-900/20 group-hover:border-amber-500 transition-all rounded">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-gray-600 group-hover:text-amber-500"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </div>
            <span className="text-[8px] text-gray-600 font-bold uppercase group-hover:text-amber-500">PARENT_DIR</span>
          </button>
        )}

        {entries.map(entry => (
          <button 
            key={entry.id}
            onClick={() => entry.type === 'FOLDER' ? onNavigate(entry.name) : onOpenFile(entry)}
            className="flex flex-col items-center gap-2 group animate-in fade-in zoom-in duration-300"
          >
            <div className={`w-12 h-12 flex items-center justify-center border transition-all rounded relative ${
              entry.type === 'FOLDER' 
              ? 'border-blue-900/50 bg-blue-950/10 group-hover:bg-blue-900/30 group-hover:border-blue-400' 
              : 'border-emerald-900/50 bg-emerald-950/10 group-hover:bg-emerald-900/30 group-hover:border-emerald-400'
            }`}>
              {entry.type === 'FOLDER' ? (
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-500"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
              )}
              {/* Security Badge */}
              {entry.roleRequired !== 'USER' && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-900 rounded-full border border-red-500 flex items-center justify-center">
                  <span className="text-[6px] text-white font-bold">!</span>
                </div>
              )}
            </div>
            <span className="text-[8px] text-gray-500 font-bold uppercase group-hover:text-white truncate w-full text-center">
              {entry.name}
            </span>
            <span className="text-[6px] text-gray-700 font-mono">
              {entry.owner}
            </span>
          </button>
        ))}
      </div>

      <div className="bg-black p-2 border-t border-gray-800 flex justify-between items-center text-[7px] text-gray-700 uppercase">
        <span>Object Count: {entries.length}</span>
        <span>Storage Utilization: 12.4%</span>
        <span className="animate-pulse text-amber-900 font-bold">SYSTEM_STABLE</span>
      </div>
    </div>
  );
};
