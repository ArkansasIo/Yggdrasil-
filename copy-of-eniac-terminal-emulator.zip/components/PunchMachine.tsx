
import React, { useState, useEffect } from 'react';
import { CardDeck } from '../types';
import { audioService } from '../services/audioService';

interface PunchMachineProps {
  onPunchComplete: (deck: CardDeck) => void;
  onCancel: () => void;
}

export const PunchMachine: React.FC<PunchMachineProps> = ({ onPunchComplete, onCancel }) => {
  const [programName, setProgramName] = useState('');
  const [currentInput, setCurrentInput] = useState('');
  const [punchedCards, setPunchedCards] = useState<string[]>([]);
  const [cursorPos, setCursorPos] = useState(0);

  const handlePunchCard = () => {
    if (!currentInput.trim()) return;
    audioService.playRelay();
    setPunchedCards([...punchedCards, currentInput]);
    setCurrentInput('');
    setCursorPos(0);
  };

  const handleFinalize = () => {
    if (punchedCards.length === 0 || !programName) return;
    const newDeck: CardDeck = {
      id: `custom-${Date.now()}`,
      name: programName,
      description: `User-defined program with ${punchedCards.length} punched cards.`,
      cards: punchedCards
    };
    onPunchComplete(newDeck);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handlePunchCard();
    } else {
      audioService.playClick('CLASSIC');
    }
  };

  // 80 columns representation
  const columns = Array.from({ length: 80 });
  const rows = Array.from({ length: 12 });

  return (
    <div className="flex flex-col h-full bg-[#1a1a1a] border-2 border-amber-900/50 rounded-lg p-4 shadow-2xl overflow-hidden font-mono">
      <div className="flex justify-between items-center mb-4 border-b border-amber-900/30 pb-2">
        <h2 className="text-[10px] text-amber-500 font-bold uppercase tracking-[0.2em]">IBM Type 026 Key Punch</h2>
        <button onClick={onCancel} className="text-amber-900 hover:text-amber-500 transition-colors text-xs">&times;</button>
      </div>

      <div className="space-y-4 flex-1 overflow-y-auto pr-2 scrollbar-hide">
        {/* Header Inputs */}
        <div className="grid grid-cols-1 gap-2">
          <label className="text-[8px] text-amber-800 uppercase font-bold">Program Identity Header</label>
          <input 
            type="text" 
            placeholder="ENTER DECK NAME..."
            value={programName}
            onChange={(e) => setProgramName(e.target.value)}
            className="bg-black border border-amber-900/30 p-2 text-[10px] text-amber-500 outline-none focus:border-amber-500 transition-colors uppercase"
          />
        </div>

        {/* Current Punch Card Visualizer */}
        <div className="bg-[#f2e6d0] border border-amber-800/30 rounded p-2 relative overflow-hidden shadow-inner">
          <div className="text-[6px] text-amber-900 absolute top-0.5 left-1 font-bold">80-COLUMN PUNCH CARD [RAW_FORMAT_V1]</div>
          
          <div className="mt-4 grid grid-cols-[repeat(80,1fr)] gap-[1px]">
            {columns.map((_, col) => (
              <div key={col} className="flex flex-col gap-[1px]">
                {rows.map((_, row) => {
                  const isPunched = currentInput.length > col && (currentInput.charCodeAt(col) % 12 === row);
                  return (
                    <div 
                      key={row} 
                      className={`w-[2px] h-[3px] rounded-[1px] ${isPunched ? 'bg-black shadow-[0_0_1px_black]' : 'bg-amber-900/10'}`}
                    />
                  );
                })}
              </div>
            ))}
          </div>

          <div className="mt-2 text-[8px] text-black font-bold uppercase truncate border-t border-amber-900/10 pt-1">
            {currentInput || 'READY FOR INPUT...'}
          </div>
        </div>

        {/* Input Interface */}
        <div className="space-y-2">
          <label className="text-[8px] text-amber-800 uppercase font-bold">Punch Buffer</label>
          <div className="flex gap-2">
            <input 
              type="text" 
              maxLength={80}
              value={currentInput}
              onChange={(e) => {
                setCurrentInput(e.target.value);
                setCursorPos(e.target.value.length);
              }}
              onKeyDown={handleKeyPress}
              className="flex-1 bg-black border border-amber-900/30 p-2 text-[10px] text-green-500 outline-none focus:border-green-800 font-mono"
              placeholder="TYPE INSTRUCTION AND PRESS ENTER TO PUNCH..."
            />
            <button 
              onClick={handlePunchCard}
              className="px-4 py-2 bg-amber-900/20 border border-amber-900 text-amber-500 text-[10px] font-bold uppercase hover:bg-amber-900/40"
            >
              PUNCH
            </button>
          </div>
          <div className="flex justify-between text-[7px] text-amber-900 uppercase">
            <span>COL: {cursorPos}/80</span>
            <span>CARD STACK: {punchedCards.length}</span>
          </div>
        </div>

        {/* Card Stack Preview */}
        <div className="space-y-1">
          <label className="text-[8px] text-amber-800 uppercase font-bold">Output Stack</label>
          <div className="max-h-32 overflow-y-auto space-y-1 border border-amber-900/10 p-1 bg-black/40 rounded">
            {punchedCards.length === 0 ? (
              <div className="text-[8px] text-amber-950 py-4 text-center">STACK IS EMPTY</div>
            ) : (
              punchedCards.map((card, idx) => (
                <div key={idx} className="flex items-center gap-2 text-[8px] font-mono group">
                  <span className="text-amber-900">[{idx.toString().padStart(2, '0')}]</span>
                  <span className="text-amber-700 truncate">{card}</span>
                  <button 
                    onClick={() => setPunchedCards(prev => prev.filter((_, i) => i !== idx))}
                    className="ml-auto opacity-0 group-hover:opacity-100 text-red-900 hover:text-red-500"
                  >
                    REM
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-amber-900/30 flex gap-2">
        <button 
          onClick={handleFinalize}
          disabled={punchedCards.length === 0 || !programName}
          className="flex-1 bg-amber-600 hover:bg-amber-500 disabled:opacity-30 disabled:hover:bg-amber-600 text-black font-bold py-2 text-[10px] uppercase tracking-widest rounded transition-all"
        >
          Finalize Deck & Load Reader
        </button>
      </div>
    </div>
  );
};
