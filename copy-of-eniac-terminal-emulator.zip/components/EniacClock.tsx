
import React, { useState, useEffect } from 'react';

export const EniacClock: React.FC = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDigit = (num: number) => num.toString().padStart(2, '0');

  const hours = formatDigit(time.getHours());
  const minutes = formatDigit(time.getMinutes());
  const seconds = formatDigit(time.getSeconds());

  const DigitModule = ({ label, value }: { label: string, value: string }) => (
    <div className="flex flex-col items-center gap-1">
      <span className="text-[8px] text-gray-600 font-bold uppercase tracking-tighter">{label}</span>
      <div className="flex gap-1 bg-[#050505] p-1.5 border border-gray-800 rounded shadow-inner">
        {value.split('').map((digit, i) => (
          <div key={i} className="relative w-5 h-8 bg-black flex items-center justify-center border border-gray-900 rounded-sm">
            {/* Background "off" filaments */}
            <span className="absolute inset-0 flex items-center justify-center text-red-950/20 font-mono text-xl select-none">8</span>
            {/* Active glowing digit */}
            <span className="relative z-10 text-red-600 glow-amber font-mono text-xl flicker">{digit}</span>
            {/* Glass reflection effect */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none"></div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="border-2 border-gray-800 bg-[#0d0d0d] rounded-lg p-3 shadow-2xl flex flex-col gap-2">
      <div className="flex justify-between items-center border-b border-gray-800 pb-1 mb-1">
        <span className="text-[9px] text-amber-700 font-bold uppercase tracking-widest">Master Pulse Chronometer</span>
        <div className="flex gap-1">
          <div className="w-1.5 h-1.5 rounded-full bg-red-900 animate-pulse"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-amber-900"></div>
        </div>
      </div>
      
      <div className="flex justify-around items-end py-1">
        <DigitModule label="Hours" value={hours} />
        <span className="text-red-900 font-mono text-xl mb-1 animate-pulse">:</span>
        <DigitModule label="Minutes" value={minutes} />
        <span className="text-red-900 font-mono text-xl mb-1 animate-pulse">:</span>
        <DigitModule label="Seconds" value={seconds} />
      </div>

      <div className="mt-1 flex justify-between items-center px-1">
        <div className="flex flex-col">
          <span className="text-[7px] text-gray-600 uppercase">Oscillator Frequency</span>
          <span className="text-[8px] text-green-900 font-mono">100.000 KC</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[7px] text-gray-600 uppercase">Sync Status</span>
          <span className="text-[8px] text-green-900 font-mono">PHASE-LOCKED</span>
        </div>
      </div>
    </div>
  );
};
