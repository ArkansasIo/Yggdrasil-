
import React from 'react';
import { DataflowTask } from '../types';

interface DataflowSchedulerProps {
  tasks: DataflowTask[];
  isActive: boolean;
}

export const DataflowScheduler: React.FC<DataflowSchedulerProps> = ({ tasks, isActive }) => {
  return (
    <div className="flex flex-col h-full border-2 border-cyan-900 bg-[#0a0a0a] rounded-lg p-3 relative overflow-hidden shadow-inner">
      <div className="text-[10px] text-cyan-600 uppercase mb-2 border-b border-cyan-900 pb-1 font-bold flex justify-between items-center">
        <span>Dataflow Scheduler</span>
        {isActive && <span className="text-[8px] animate-pulse bg-cyan-900/30 px-1 border border-cyan-800">DISPATCHING</span>}
      </div>
      
      <div className="flex-1 overflow-hidden flex flex-col gap-2">
        <div className="flex-1 overflow-y-auto space-y-1 pr-1 scrollbar-hide">
          {tasks.length === 0 ? (
            <div className="h-full flex items-center justify-center opacity-20 flex-col gap-2">
              <div className="w-8 h-8 border border-cyan-900 rounded-full border-dashed animate-spin" />
              <span className="text-[8px] text-cyan-700 font-mono">IDLE_STATE</span>
            </div>
          ) : (
            tasks.map((task) => (
              <div 
                key={task.id} 
                className={`flex items-center justify-between p-1.5 border transition-all duration-300 ${
                  task.status === 'ACTIVE' 
                  ? 'bg-cyan-900/40 border-cyan-400 text-cyan-300' 
                  : task.status === 'RETIRED'
                  ? 'bg-black/40 border-cyan-900/20 text-cyan-900 opacity-50'
                  : 'bg-black/20 border-cyan-900/40 text-cyan-700'
                }`}
              >
                <div className="flex flex-col">
                  <span className="text-[9px] font-bold font-mono tracking-tighter">{task.op}</span>
                  <span className="text-[7px] opacity-60 font-mono">REGS: {task.targetRegs.join(', ')}</span>
                </div>
                <div className="flex flex-col items-end">
                  <span className={`text-[7px] font-mono px-1 ${
                    task.status === 'ACTIVE' ? 'bg-cyan-400 text-black font-bold' : ''
                  }`}>
                    {task.status}
                  </span>
                  {task.status === 'ACTIVE' && <div className="w-10 h-0.5 bg-gray-900 mt-1 overflow-hidden">
                    <div className="h-full bg-cyan-400 animate-[loading_0.5s_infinite]" />
                  </div>}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="h-12 border-t border-cyan-900/50 pt-2 grid grid-cols-4 gap-1">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="flex flex-col items-center gap-1">
              <span className="text-[6px] text-cyan-900 font-bold">FU-{i}</span>
              <div className={`w-full h-1 rounded-full ${isActive ? 'bg-cyan-800 animate-pulse' : 'bg-gray-900'}`} />
            </div>
          ))}
        </div>
      </div>

      <div className="absolute top-0 right-0 p-1 opacity-10">
        <div className="text-[40px] font-bold text-cyan-900 font-mono select-none pointer-events-none">9G</div>
      </div>
    </div>
  );
};
