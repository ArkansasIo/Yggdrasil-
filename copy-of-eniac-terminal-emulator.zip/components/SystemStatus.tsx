
import React from 'react';
import { SystemMode, ArchitectureType } from '../types';

interface SystemStatusProps {
  activeTubes: number;
  totalTubes: number;
  powerKw: number;
  uptime: string;
  isProcessing: boolean;
  mode: SystemMode;
  architecture: ArchitectureType;
  onToggleArchitecture: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  isCrtEnabled: boolean;
  onToggleCrt: () => void;
}

export const SystemStatus: React.FC<SystemStatusProps> = ({ 
  activeTubes, 
  totalTubes, 
  powerKw, 
  uptime, 
  isProcessing,
  mode,
  architecture,
  onToggleArchitecture,
  isMuted,
  onToggleMute,
  isCrtEnabled,
  onToggleCrt
}) => {
  const healthPercentage = (activeTubes / totalTubes) * 100;
  const gridLoadPercentage = (powerKw / 200) * 100; // Assuming 200kW is max load for grid

  return (
    <div className="flex-1 flex items-center justify-between px-6">
      <div className="flex items-center gap-8">
        <div className="flex flex-col">
          <h1 className="text-xl font-bold tracking-tighter text-gray-300 flex items-center gap-2">
            E N I A C <span className={`text-[10px] font-mono px-1 border transition-colors ${mode === 'TURBO' ? 'text-cyan-400 bg-cyan-950/20 border-cyan-800' : mode === 'MAINFRAME' ? 'text-sky-400 bg-sky-950/20 border-sky-800' : 'text-red-700 bg-red-950/20 border-red-900/30'}`}>
              {mode === 'TURBO' ? 'Mk II TURBO' : mode === 'MAINFRAME' ? 'MAINFRAME' : 'Mk I'}
            </span>
          </h1>
          <span className="text-[8px] text-gray-600 font-mono uppercase tracking-[0.2em]">
            {mode === 'TURBO' ? '9.0 GHz Dataflow Processor' : mode === 'MAINFRAME' ? 'Distributed Z-Architecture' : 'General Purpose Digital Computer'}
          </span>
        </div>

        {/* Tube Health Indicator */}
        <div className="flex flex-col gap-0.5 border-r border-gray-800 pr-6">
          <div className="flex justify-between items-center w-24">
            <span className="text-[8px] text-gray-500 uppercase font-bold">Tube Health</span>
            <span className={`text-[9px] font-mono ${healthPercentage < 90 ? 'text-red-500' : 'text-green-500'}`}>
              {healthPercentage.toFixed(1)}%
            </span>
          </div>
          <div className="w-24 h-1 bg-gray-900 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-1000 ${healthPercentage < 90 ? 'bg-red-600 shadow-[0_0_5px_red]' : 'bg-green-600'}`}
              style={{ width: `${healthPercentage}%` }}
            />
          </div>
          <span className="text-[6px] text-gray-700 uppercase font-mono mt-0.5">FILAMENT_STABILITY: NOMINAL</span>
        </div>

        {/* Architecture Toggle */}
        <div className="flex flex-col gap-1 pr-6 border-r border-gray-800">
           <span className="text-[8px] text-gray-500 uppercase font-bold">Architecture</span>
           <button 
            onClick={onToggleArchitecture}
            className={`flex items-center gap-2 px-2 py-0.5 border rounded transition-all group ${
              architecture === 'HARVARD' ? 'border-cyan-600 bg-cyan-950/20' : 'border-amber-900 bg-amber-950/10'
            }`}
           >
              <span className={`text-[9px] font-mono ${architecture === 'HARVARD' ? 'text-cyan-400' : 'text-amber-600'}`}>
                {architecture.replace('_', ' ')}
              </span>
              <div className="w-2 h-2 rounded-full bg-current animate-pulse shadow-[0_0_5px_currentColor]" />
           </button>
        </div>

        {/* Power Grid Load Monitor */}
        <div className="flex flex-col gap-0.5 border-r border-gray-800 pr-6">
          <div className="flex justify-between items-center w-32">
            <span className="text-[8px] text-gray-500 uppercase font-bold">Grid Load</span>
            <span className={`text-[9px] font-mono ${isProcessing ? 'text-red-500' : 'text-amber-600'}`}>
              {gridLoadPercentage.toFixed(1)}%
            </span>
          </div>
          <div className="w-32 h-1.5 bg-gray-900 rounded-full overflow-hidden border border-gray-800 p-[1px]">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${isProcessing ? 'bg-red-600 animate-pulse' : mode === 'TURBO' ? 'bg-cyan-600' : mode === 'MAINFRAME' ? 'bg-sky-600' : 'bg-amber-600'}`}
              style={{ width: `${gridLoadPercentage}%` }}
            />
          </div>
          <span className="text-[6px] text-gray-700 uppercase font-mono mt-0.5">CURRENT_DRAW: {powerKw.toFixed(1)} kW</span>
        </div>
      </div>

      <div className="flex items-center gap-6">
        {/* CRT Toggle */}
        <button 
          onClick={onToggleCrt}
          className="flex flex-col items-center gap-0.5 group"
          title={isCrtEnabled ? "Disable CRT Effect" : "Enable CRT Effect"}
        >
          <span className="text-[8px] text-gray-500 uppercase font-bold group-hover:text-gray-400">CRT</span>
          <div className={`w-5 h-5 flex items-center justify-center border transition-colors ${!isCrtEnabled ? 'border-gray-800 text-gray-700' : 'border-cyan-600 text-cyan-400 group-hover:border-cyan-400'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
          </div>
        </button>

        {/* Audio Control */}
        <button 
          onClick={onToggleMute}
          className="flex flex-col items-center gap-0.5 group"
          title={isMuted ? "Unmute Audio" : "Mute Audio"}
        >
          <span className="text-[8px] text-gray-500 uppercase font-bold group-hover:text-gray-400">Audio</span>
          <div className={`w-5 h-5 flex items-center justify-center border transition-colors ${isMuted ? 'border-gray-800 text-gray-700' : 'border-gray-600 text-gray-400 group-hover:border-cyan-600 group-hover:text-cyan-400'}`}>
            {isMuted ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"></path><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
            )}
          </div>
        </button>

        <div className="flex flex-col items-end">
          <span className="text-[8px] text-gray-500 uppercase font-bold">System Uptime</span>
          <span className={`text-[10px] font-mono tracking-wider ${mode === 'TURBO' ? 'text-cyan-400' : mode === 'MAINFRAME' ? 'text-sky-400' : 'text-gray-400 glow-amber'}`}>{uptime}</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[8px] text-gray-500 uppercase font-bold">Cycle Pulse</span>
          <div className="flex gap-1 mt-0.5">
            <div className={`w-1.5 h-1.5 rounded-full ${isProcessing ? (mode === 'TURBO' ? 'bg-cyan-400 animate-ping' : mode === 'MAINFRAME' ? 'bg-sky-400 animate-ping' : 'bg-red-600 animate-ping') : 'bg-gray-800'}`} />
            <div className={`w-1.5 h-1.5 rounded-full ${isProcessing ? (mode === 'TURBO' ? 'bg-cyan-400' : mode === 'MAINFRAME' ? 'bg-sky-400 shadow-[0_0_5px_cyan]' : 'bg-red-600 shadow-[0_0_5px_red]') : 'bg-green-600'}`} />
          </div>
        </div>
      </div>
    </div>
  );
};
