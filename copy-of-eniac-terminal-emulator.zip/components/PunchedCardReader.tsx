
import React from 'react';
import { CardDeck } from '../types';

const FACTORY_DECKS: CardDeck[] = [
  {
    id: 'babbage-diff-2',
    name: 'Babbage: Difference Engine No. 2',
    description: '1849: Mechanical polynomial tabulator logic. Computes squares using method of finite differences.',
    cards: [
      'Set Difference Register D2 to constant 0000000002.',
      'Set Difference Register D1 to initial value 0000000001.',
      'Set Result Register V to initial value 0000000000.',
      'Cycle 1: Add D2 to D1 (Result: 3). Add D1 to V (Result: 4).',
      'Cycle 2: Add D2 to D1 (Result: 5). Add D1 to V (Result: 9).',
      'Cycle 3: Add D2 to D1 (Result: 7). Add D1 to V (Result: 16).',
      'Dispatch current V to Constant Transmitter for printing.'
    ]
  },
  {
    id: 'monte-carlo-1946',
    name: 'Monte Carlo: Neutron Diff.',
    description: '1946: Ulam/Metropolis logic for tracking fission particles in nuclear shielding.',
    cards: [
      'Initialize random seed in Function Table 3.',
      'Generate pseudo-random coordinate X, Y, Z.',
      'Calculate collision vector with lead shell.',
      'If absorption occurs, increment tally in Acc 19.',
      'Iterate 10,000 cycles for statistical convergence.'
    ]
  },
  {
    id: 'charney-weather-1950',
    name: 'Charney: NWP-1 Weather',
    description: '1950: First numerical weather prediction. 24-hour forecast simulation.',
    cards: [
      'Load grid-point barotropic data from Constant Trans.',
      'Solve vorticity equation using 5-point Laplacian.',
      'Integrate geopotential height over 12 hourly steps.',
      'Apply Coriolis force adjustments from Acc 8.',
      'Output isobaric surface map coordinates.'
    ]
  },
  {
    id: 'fortran-alpha-1957',
    name: 'FORTRAN Alpha Compiler',
    description: '1957: Backus’s IBM 704 compiler logic. First optimized HLL execution.',
    cards: [
      'Tokenize source string f(x) = y + z.',
      'Construct expression tree in sharded memory.',
      'Apply sub-expression elimination (Stage 1).',
      'Generate machine-dependent opcodes for Register Bank.',
      'Verify loop invariant hoisting in target block.'
    ]
  },
  {
    id: 'lisp-eval-1958',
    name: 'LISP 1.5 Evaluator',
    description: '1958: McCarthy’s symbolic logic. List processing and recursion primitives.',
    cards: [
      'Initialize heap pointers for cons cells.',
      'Evaluate S-expression (CAR (CDR X)).',
      'Execute garbage collection on unused list heads.',
      'Apply lambda closure to local variable stack.',
      'Output atom result to constant transmitter.'
    ]
  },
  {
    id: 'collatz-analysis',
    name: 'Collatz (3n+1) Sequencer',
    description: 'Iterative parity check engine to verify the Collatz Conjecture for a target integer.',
    cards: [
      'Input target integer N to Accumulator 1.',
      'Check parity: If even, shift right (divide by 2).',
      'If odd, multiply by 3 and add constant 1.',
      'Loop until Acc 1 contains unit value 0000000001.',
      'Dispatch cycle count to constant transmitter.'
    ]
  },
  {
    id: 'riemann-calc',
    name: 'Calculus: Riemann Sum',
    description: 'Numerical integration of f(x) over a defined interval using Simpson\'s Rule.',
    cards: [
      'Define interval [a, b] in Function Table 1.',
      'Partition interval into 10,000 sub-segments.',
      'Fetch f(x) coefficients from Constant Transmitter.',
      'Compute weighted summation in Accumulators 10-15.',
      'Apply 1/3 scalar factor and output final integral.'
    ]
  },
  {
    id: 'ballistics',
    name: 'Trajectory X-15',
    description: 'Calculates the parabolic arc of a 155mm shell with air resistance.',
    cards: [
      'Set initial velocity to 800 m/s at 45 degrees.',
      'Initialize Drag Equation in Accumulator 5.',
      'Apply atmospheric pressure constants from Function Table 1.',
      'Run numerical integration loop for 30 seconds of flight.',
      'Output terminal coordinates and impact velocity.'
    ]
  }
];

interface PunchedCardReaderProps {
  onLoadDeck: (deck: CardDeck) => void;
  onOpenPunchMachine: () => void;
  isProcessing: boolean;
  customDecks?: CardDeck[];
}

export const PunchedCardReader: React.FC<PunchedCardReaderProps> = ({ onLoadDeck, onOpenPunchMachine, isProcessing, customDecks = [] }) => {
  const allDecks = [...FACTORY_DECKS, ...customDecks];

  return (
    <div className="flex flex-col h-full border-2 border-gray-800 bg-[#0d0d0d] rounded-lg p-3 overflow-hidden shadow-inner">
      <div className="text-[10px] text-blue-500 font-bold uppercase mb-2 flex items-center justify-between border-b border-gray-800 pb-1">
        <span>IBM Type 405 Card Reader</span>
        <div className={`w-2 h-2 rounded-full ${isProcessing ? 'bg-amber-500 animate-pulse' : 'bg-blue-900'}`}></div>
      </div>
      
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 scrollbar-hide">
        <button 
          onClick={onOpenPunchMachine}
          disabled={isProcessing}
          className="w-full border border-dashed border-amber-900/50 p-2 mb-2 text-[9px] text-amber-700 font-bold uppercase hover:bg-amber-900/10 transition-colors"
        >
          + Enter Card Programming Room
        </button>

        <div className="text-[7px] text-gray-700 uppercase font-bold mb-1 ml-1">Deck Library</div>

        {allDecks.map((deck) => (
          <button
            key={deck.id}
            disabled={isProcessing}
            onClick={() => onLoadDeck(deck)}
            className={`w-full text-left p-2 border border-gray-800 hover:border-blue-900 transition-all group relative overflow-hidden ${isProcessing ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-950/20'}`}
          >
            <div className="flex flex-col gap-1 relative z-10">
              <span className={`text-[10px] font-bold tracking-wider ${deck.id === 'babbage-diff-2' ? 'text-amber-500 glow-amber' : deck.id.includes('custom') ? 'text-amber-500' : deck.id.includes('19') ? 'text-emerald-400' : 'text-blue-400'}`}>
                {deck.name} {deck.id.includes('custom') && '[USER_DEF]'}
              </span>
              <span className="text-[8px] text-gray-500 leading-tight">{deck.description}</span>
              <span className="text-[7px] text-blue-900 mt-1 uppercase">{deck.cards.length} CARDS IN STACK</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
