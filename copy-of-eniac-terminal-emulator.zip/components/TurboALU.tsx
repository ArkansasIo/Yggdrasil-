
import React, { useState, useEffect } from 'react';
import { audioService } from '../services/audioService';

interface TurboALUProps {
  onExecute: (op: string, a: number, b: number, target: number) => void;
  isProcessing: boolean;
  lastOperation?: {
    op: string;
    a: number;
    b: number;
    target: number;
    result: string;
  };
}

const OPS = [
  { id: 'ADD', icon: '+', label: 'Arithmetic Addition' },
  { id: 'SUB', icon: '-', label: 'Arithmetic Subtraction' },
  { id: 'AND', icon: '&', label: 'Bitwise AND' },
  { id: 'OR', icon: '|', label: 'Bitwise OR' },
  { id: 'NOT', icon: '~', label: 'Bitwise NOT' },
];

export const TurboALU: React.FC<TurboALUProps> = ({ onExecute, isProcessing, lastOperation }) => {
  const [op, setOp] = useState('ADD');
  const [regA, setRegA] = useState(1);
  const [regB, setRegB] = useState(2);
  const [targetReg, setTargetReg] = useState(3);

  const handleExecute = () => {
    audioService.playRelay();
    onExecute(op, regA, regB, targetReg);
  };

  return (
    <div className="flex flex-col h-full border-2 border-cyan-500 bg-[#000a0a] rounded-lg overflow-hidden shadow-[0_0_20px_rgba(6,182,212,0.2)] crt-effect font-mono">
      <div className="bg-cyan-950/40 px-3 py-2 border-b border-cyan-500 flex justify-between items-center">
        <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-widest flex items-center gap-2">
          <div className={`w-1.5 h-1.5 bg-cyan-400 rounded-full ${isProcessing ? 'animate-ping' : ''}`} />
          Turbo Arithmetic Logic Unit
        </span>
        <span className="text-[7px] text-cyan-800">UNIT_ID: ALU-01</span>
      </div>

      <div className="flex-1 p-3 flex flex-col gap-4 overflow-y-auto scrollbar-hide">
        {/* Operation Selector */}
        <div className="grid grid-cols-5 gap-1">
          {OPS.map((o) => (
            <button
              key={o.id}
              onClick={() => { setOp(o.id); audioService.playClick('TURBO'); }}
              className={`flex flex-col items-center p-1 border transition-all ${
                op === o.id 
                ? 'bg-cyan-500 text-black border-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.4)]' 
                : 'bg-black text-cyan-900 border-cyan-900/50 hover:border-cyan-600'
              }`}
            >
              <span className="text-xs font-bold">{o.icon}</span>
              <span className="text-[6px] mt-0.5">{o.id}</span>
            </button>
          ))}
        </div>

        {/* Register Inputs */}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="text-[7px] text-cyan-800 uppercase font-bold">Operand A (Acc)</label>
              <input 
                type="number" min="1" max="128"
                value={regA}
                onChange={(e) => setRegA(Math.max(1, Math.min(128, parseInt(e.target.value) || 1)))}
                className="bg-black border border-cyan-900/50 p-1.5 text-[10px] text-cyan-400 outline-none focus:border-cyan-400"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[7px] text-cyan-800 uppercase font-bold">Operand B (Acc)</label>
              <input 
                type="number" min="1" max="128"
                disabled={op === 'NOT'}
                value={regB}
                onChange={(e) => setRegB(Math.max(1, Math.min(128, parseInt(e.target.value) || 1)))}
                className={`bg-black border border-cyan-900/50 p-1.5 text-[10px] outline-none focus:border-cyan-400 ${op === 'NOT' ? 'opacity-20' : 'text-cyan-400'}`}
              />
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[7px] text-cyan-800 uppercase font-bold">Target Register (Acc)</label>
            <input 
              type="number" min="1" max="128"
              value={targetReg}
              onChange={(e) => setTargetReg(Math.max(1, Math.min(128, parseInt(e.target.value) || 1)))}
              className="bg-black border border-cyan-900/50 p-1.5 text-[10px] text-cyan-400 outline-none focus:border-cyan-400"
            />
          </div>
        </div>

        {/* Execution Visualizer */}
        <div className="bg-black/60 border border-cyan-900/30 p-2 rounded flex-1 flex flex-col justify-center gap-1 min-h-[60px]">
          {isProcessing ? (
            <div className="flex flex-col items-center gap-1 animate-pulse">
              <div className="text-[8px] text-cyan-500 uppercase tracking-tighter">Computing Pulse Sequence...</div>
              <div className="flex gap-1">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="w-1 h-3 bg-cyan-900 rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-400 animate-[loading_0.3s_infinite]" style={{ animationDelay: `${i * 0.05}s` }} />
                  </div>
                ))}
              </div>
            </div>
          ) : lastOperation ? (
            <div className="flex flex-col items-center">
              <div className="text-[7px] text-cyan-900 uppercase">Last Result [COMMIT OK]</div>
              <div className="text-sm font-bold text-cyan-400 glow-cyan font-mono tracking-widest">{lastOperation.result}</div>
              <div className="text-[6px] text-cyan-800 mt-1">OP_{lastOperation.op} TARGET_ACC_{lastOperation.target}</div>
            </div>
          ) : (
            <div className="text-[7px] text-cyan-950 text-center italic uppercase">ALU Idle - Standby for Instruction</div>
          )}
        </div>
      </div>

      <div className="p-3 bg-black border-t border-cyan-900">
        <button 
          onClick={handleExecute}
          disabled={isProcessing}
          className="w-full bg-cyan-900/20 border border-cyan-500 hover:bg-cyan-500 hover:text-black text-cyan-400 font-bold py-2 text-[10px] uppercase tracking-widest transition-all disabled:opacity-20"
        >
          {isProcessing ? 'PROCESSING...' : 'Execute Logical Pulse'}
        </button>
      </div>
    </div>
  );
};
