
import React, { useState } from 'react';

const DATA = {
  LANGS: [
    { name: 'IBM Assembly', use: 'Low-Level', logic: 'Mnemonics for direct machine opcodes. Uses R1-R128 register bank.' },
    { name: 'FORTRAN II', use: 'Scientific', logic: 'Formula Translation. First HLL for numeric crunching. Supports arrays.' },
    { name: 'COBOL-60', use: 'Business', logic: 'Common Business Oriented Language. English-like syntax for record processing.' },
    { name: 'ALGOL-58', use: 'Algorithms', logic: 'Algorithmic Language. Foundation for Pascal/C block structure and recursion.' },
    { name: 'Dartmouth BASIC', use: 'Educational', logic: 'Beginner\'s All-purpose Symbolic Instruction Code. Time-sharing focus.' },
  ],
  HISTORIC: [
    { name: 'Difference Engine No. 2', use: 'Mechanical (1849)', logic: 'Charles Babbage’s mechanical polynomial tabulator using finite differences.' },
    { name: 'Analytical Engine', use: 'Concept (1837)', logic: 'The first design for a general-purpose programmable computer with ALU and memory.' },
    { name: 'Monte Carlo Method', use: 'Physics (1946)', logic: 'Ulam and Metropolis used random sampling for neutron diffusion on ENIAC.' },
    { name: 'Charney Weather', use: 'Meteorology (1950)', logic: 'First successful numerical weather prediction run using ENIAC at Aberdeen.' },
  ],
  CONSTANTS: [
    { symbol: 'π', name: 'Pi (Archimedes)', val: '3.1415926535...', year: 'Ancient' },
    { symbol: 'e', name: "Euler's Number", val: '2.7182818284...', year: '1748' },
  ],
  THEOREMS: [
    { name: "Fermat's Last", logic: "aⁿ + bⁿ = cⁿ has no solutions for n > 2.", year: '1637/1994' },
    { name: "Godel Incomplete", logic: "Systems cannot be both consistent and complete.", year: '1931' },
  ]
};

type TabId = keyof typeof DATA;

export const MathLibrary: React.FC = () => {
  const [tab, setTab] = useState<TabId>('LANGS');

  const tabs: { id: TabId; label: string; color: string }[] = [
    { id: 'LANGS', label: 'LANG', color: 'text-emerald-500' },
    { id: 'HISTORIC', label: 'HIST', color: 'text-amber-400' },
    { id: 'CONSTANTS', label: 'CONST', color: 'text-amber-500' },
    { id: 'THEOREMS', label: 'THRM', color: 'text-amber-500' },
  ];

  return (
    <div className="flex flex-col h-full border-2 border-gray-800 bg-[#0a0a0a] rounded-lg overflow-hidden shadow-2xl">
      <div className="flex overflow-x-auto border-b border-gray-800 no-scrollbar scroll-smooth">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-shrink-0 px-4 py-2 text-[7px] font-bold transition-all uppercase ${
              tab === t.id 
                ? 'bg-amber-900/20 ' + t.color + ' border-b-2 border-current' 
                : 'text-gray-600 hover:text-gray-400'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex-1 p-3 overflow-y-auto scrollbar-hide bg-[#050505]">
        <div className="space-y-3">
          {DATA[tab].map((item: any, i: number) => (
            <div key={i} className="bg-black/40 p-2 border border-gray-900 rounded hover:border-current transition-colors">
              <div className={`text-[9px] font-bold uppercase ${tabs.find(t => t.id === tab)?.color}`}>{item.name || item.symbol}</div>
              {item.use && <div className="text-[7px] text-gray-600 mt-0.5">CONTEXT: {item.use}</div>}
              <div className="text-[8px] text-gray-400 font-mono mt-1 border-t border-gray-900/50 pt-1 leading-relaxed">
                {item.logic || item.val}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
