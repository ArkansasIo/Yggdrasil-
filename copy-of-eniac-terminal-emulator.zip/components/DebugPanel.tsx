
import React, { useRef, useEffect } from 'react';
import { DebugLog } from '../types';

interface DebugPanelProps {
  logs: DebugLog[];
  isEnabled: boolean;
  onToggle: () => void;
}

export const DebugPanel: React.FC<DebugPanelProps> = ({ logs, isEnabled, onToggle }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="flex flex-col h-full border-2 border-cyan-900 bg-[#050505] rounded-lg overflow-hidden shadow-inner">
      <div className="bg-[#001212] px-3 py-1 flex justify-between items-center border-b border-cyan-900">
        <span className="text-[9px] font-bold text-cyan-600 uppercase tracking-widest flex items-center gap-2">
          <div className={`w-1.5 h-1.5 rounded-full ${isEnabled ? 'bg-cyan-400 animate-pulse' : 'bg-gray-800'}`} />
          Micro-Op Debugger
        </span>
        <button 
          onClick={onToggle}
          className={`text-[8px] px-1.5 py-0.5 border rounded transition-colors ${
            isEnabled 
            ? 'border-cyan-400 text-cyan-400 bg-cyan-950/30' 
            : 'border-gray-800 text-gray-600'
          }`}
        >
          {isEnabled ? 'DISABLE' : 'ENABLE'}
        </button>
      </div>

      <div 
        ref={scrollRef}
        className={`flex-1 overflow-y-auto p-2 font-mono text-[7px] space-y-1 scrollbar-hide ${!isEnabled && 'opacity-20 pointer-events-none'}`}
      >
        {logs.length === 0 ? (
          <div className="h-full flex items-center justify-center text-cyan-900 uppercase">No active trace</div>
        ) : (
          logs.map((log) => (
            <div key={log.id} className="border-b border-cyan-900/10 pb-1 last:border-0">
              <div className="flex justify-between text-cyan-800">
                <span>[{log.timestamp}]</span>
                <span className="font-bold text-cyan-500">{log.op}</span>
              </div>
              <div className="flex flex-col gap-0.5 mt-0.5">
                <span className="text-cyan-700">TARGETS: {log.regs.join(', ')}</span>
                <span className="text-cyan-400 truncate">{log.change}</span>
              </div>
            </div>
          ))
        )}
      </div>
      
      <div className="bg-black p-1 px-2 border-t border-cyan-900/30 text-[6px] text-cyan-900 flex justify-between uppercase">
        <span>Bus Width: 34-bit</span>
        <span>Trace Depth: {logs.length}</span>
      </div>
    </div>
  );
};
