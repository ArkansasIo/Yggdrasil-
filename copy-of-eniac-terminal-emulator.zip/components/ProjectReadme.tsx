
import React from 'react';

export const ProjectReadme: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] bg-black/90 flex items-center justify-center p-8 backdrop-blur-sm crt-effect">
      <div className="w-full max-w-2xl border-2 border-cyan-600 bg-[#000a0a] rounded overflow-hidden flex flex-col shadow-[0_0_50px_rgba(34,211,238,0.2)]">
        <div className="bg-cyan-900/20 px-4 py-3 flex justify-between items-center border-b border-cyan-900/50">
          <h2 className="text-cyan-400 font-bold text-sm uppercase tracking-widest">Dossier: Project ENIAC Terminal</h2>
          <button onClick={onClose} className="text-cyan-700 hover:text-cyan-400 text-xl font-mono">&times;</button>
        </div>
        
        <div className="p-6 overflow-y-auto max-h-[70vh] font-mono text-xs space-y-6 text-cyan-800/80">
          <section>
            <h3 className="text-cyan-400 font-bold border-b border-cyan-900 pb-1 mb-2">OVERVIEW</h3>
            <p className="leading-relaxed">
              This terminal emulator is a high-fidelity tribute to the Electronic Numerical Integrator and Computer (ENIAC). 
              It bridges historical mechanical compute with modern LLM-driven mathematical reasoning.
            </p>
          </section>

          <section>
            <h3 className="text-cyan-400 font-bold border-b border-cyan-900 pb-1 mb-2">DEVELOPMENT CREDITS</h3>
            <div className="p-3 border border-cyan-900/40 bg-cyan-950/10 rounded">
              <p className="text-cyan-300 font-bold">STEPHEN DELINE JR</p>
              <p className="text-[10px] mt-1 italic text-cyan-600">Lead System Architect & Lead Engineer</p>
              <p className="mt-2 text-[10px] text-cyan-800">
                Specializing in retro-compute paradigms, procedural audio generation, 
                and high-performance dataflow visualization.
              </p>
            </div>
          </section>

          <section className="grid grid-cols-2 gap-4">
            <div className="border border-cyan-900/30 p-2 rounded">
              <h4 className="text-cyan-600 font-bold mb-1">ENGINE</h4>
              <p>Google Gemini 3 Pro</p>
            </div>
            <div className="border border-cyan-900/30 p-2 rounded">
              <h4 className="text-cyan-600 font-bold mb-1">CLOCK SPEED</h4>
              <p>9.0 GHz (Virtual Mk-II)</p>
            </div>
          </section>

          <section>
            <h3 className="text-cyan-400 font-bold border-b border-cyan-900 pb-1 mb-2">ARCHITECTURE</h3>
            <p className="mb-2 italic">Mk-I (Classic):</p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li>Decimal-based accumulator logic.</li>
              <li>10-digit word length.</li>
              <li>Manual plugboard routing simulation.</li>
            </ul>
            <p className="mt-4 mb-2 italic">Mk-II (Turbo):</p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li>Superscalar dataflow pipeline.</li>
              <li>Out-of-Order micro-op scheduling.</li>
              <li>Real-time register renaming & state traces.</li>
            </ul>
          </section>
        </div>

        <button onClick={onClose} className="bg-cyan-600 text-black font-bold py-3 text-xs uppercase tracking-[0.3em] hover:bg-cyan-500 transition-colors">Exit Dossier</button>
      </div>
    </div>
  );
};
