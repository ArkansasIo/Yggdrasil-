
import React from 'react';
import { TurboConfig, TurboScheduler, PipelineDepth } from '../types';

interface TurboSettingsProps {
  config: TurboConfig;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (newConfig: TurboConfig) => void;
}

export const TurboSettings: React.FC<TurboSettingsProps> = ({ config, isOpen, onClose, onUpdate }) => {
  if (!isOpen) return null;

  const schedulers: { id: TurboScheduler; label: string; desc: string }[] = [
    { id: 'ORDERED', label: 'In-Order Dispatch', desc: 'Linear micro-op commitment. Safe but limited throughput.' },
    { id: 'OUT_OF_ORDER', label: 'Out-of-Order (OoO)', desc: 'Dynamic register renaming and dataflow execution.' },
    { id: 'SPECULATIVE', label: 'Speculative Branching', desc: 'Hardware-level prediction for non-deterministic jumps.' }
  ];

  const depths: { id: PipelineDepth; label: string; stages: number }[] = [
    { id: 'STANDARD', label: '4-Stage Pipeline', stages: 4 },
    { id: 'DEEP', label: '12-Stage Pipeline', stages: 12 },
    { id: 'ULTRA_WIDE', label: 'Parallel Super-scalar', stages: 32 }
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-md border-2 border-cyan-500 bg-[#001212] shadow-[0_0_50px_rgba(34,211,238,0.2)] rounded-lg overflow-hidden flex flex-col crt-effect">
        <div className="bg-cyan-950/50 px-4 py-3 flex justify-between items-center border-b border-cyan-500">
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-2">
            <div className="w-2 h-2 bg-cyan-400 animate-pulse rounded-full" />
            Architectural Core Configuration
          </span>
          <button onClick={onClose} className="text-cyan-600 hover:text-cyan-400 font-mono text-lg">&times;</button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Scheduler Selection */}
          <section>
            <h3 className="text-[10px] text-cyan-700 font-bold uppercase mb-3 tracking-tighter">Microcode Scheduler</h3>
            <div className="space-y-2">
              {schedulers.map((s) => (
                <button
                  key={s.id}
                  onClick={() => onUpdate({ ...config, scheduler: s.id })}
                  className={`w-full text-left p-3 border rounded transition-all ${
                    config.scheduler === s.id 
                    ? 'border-cyan-400 bg-cyan-950/40' 
                    : 'border-cyan-900/40 bg-black/20 hover:border-cyan-700'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className={`text-[10px] font-bold ${config.scheduler === s.id ? 'text-cyan-300' : 'text-cyan-800'}`}>{s.label}</span>
                    {config.scheduler === s.id && <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />}
                  </div>
                  <p className="text-[8px] text-cyan-900 font-mono">{s.desc}</p>
                </button>
              ))}
            </div>
          </section>

          {/* Pipeline Depth Selection */}
          <section>
            <h3 className="text-[10px] text-cyan-700 font-bold uppercase mb-3 tracking-tighter">ALU Pipeline Depth</h3>
            <div className="grid grid-cols-3 gap-2">
              {depths.map((d) => (
                <button
                  key={d.id}
                  onClick={() => onUpdate({ ...config, pipelineDepth: d.id })}
                  className={`flex flex-col items-center p-2 border rounded transition-all ${
                    config.pipelineDepth === d.id 
                    ? 'border-cyan-400 bg-cyan-950/40' 
                    : 'border-cyan-900/40 bg-black/20 hover:border-cyan-700'
                  }`}
                >
                  <span className={`text-[9px] font-bold mb-1 ${config.pipelineDepth === d.id ? 'text-cyan-300' : 'text-cyan-800'}`}>{d.label}</span>
                  <div className="flex gap-0.5 mt-1">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className={`w-1 h-2 rounded-sm ${i < (d.id === 'STANDARD' ? 1 : d.id === 'DEEP' ? 2 : 4) ? 'bg-cyan-600' : 'bg-gray-900'}`} />
                    ))}
                  </div>
                </button>
              ))}
            </div>
          </section>

          {/* Toggle Options */}
          <section className="flex gap-4">
            <button 
              onClick={() => onUpdate({ ...config, hazardMitigation: !config.hazardMitigation })}
              className="flex-1 flex items-center justify-between p-3 border border-cyan-900/40 rounded bg-black/20"
            >
              <span className="text-[9px] text-cyan-800 font-bold uppercase">Hazard Mitigation</span>
              <div className={`w-8 h-4 rounded-full relative transition-colors ${config.hazardMitigation ? 'bg-cyan-600' : 'bg-gray-800'}`}>
                <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${config.hazardMitigation ? 'left-4.5' : 'left-0.5'}`} />
              </div>
            </button>
          </section>
        </div>

        <div className="p-4 bg-black border-t border-cyan-900 text-center">
          <p className="text-[8px] text-cyan-900 font-mono italic">
            "Changes in core logic may result in clock desync. Recalibrate Master Programmer after commitment."
          </p>
          <button 
            onClick={onClose}
            className="mt-4 w-full bg-cyan-600 hover:bg-cyan-500 text-black font-bold py-2 text-[10px] uppercase tracking-widest rounded"
          >
            Commit Microcode Changes
          </button>
        </div>
      </div>
    </div>
  );
};
