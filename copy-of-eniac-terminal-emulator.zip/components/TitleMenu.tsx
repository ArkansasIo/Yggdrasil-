
import React from 'react';
import { SystemMode } from '../types';

interface TitleMenuProps {
  onSelectMode: (mode: SystemMode) => void;
  onOpenHelp: () => void;
  onOpenReadme: () => void;
  onOpenCredits: () => void;
}

export const TitleMenu: React.FC<TitleMenuProps> = ({ onSelectMode, onOpenHelp, onOpenReadme, onOpenCredits }) => {
  return (
    <div className="fixed inset-0 bg-[#050505] z-[150] flex items-center justify-center p-4 crt-effect">
      <div className="w-full max-w-5xl flex flex-col items-center">
        <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Left Column: Branding */}
          <div className="flex flex-col justify-center border-r border-gray-900 pr-8">
            <div className="mb-8">
              <h1 className="text-5xl font-bold tracking-tighter text-gray-400 glow-amber mb-2">ENIAC</h1>
              <p className="text-xs text-amber-700 font-mono tracking-[0.3em] uppercase">Control & Computation Hub</p>
            </div>
            
            <div className="space-y-4">
              <button 
                onClick={() => onSelectMode('CLASSIC')}
                className="w-full group relative p-4 border border-amber-900 bg-amber-950/10 hover:bg-amber-900/20 transition-all text-left overflow-hidden"
              >
                <div className="text-amber-500 font-bold uppercase text-sm mb-1">Initialize Mk-I (Classic)</div>
                <div className="text-[10px] text-amber-800 font-mono">Original 1945 parameters. 20 Accumulators. Vacuum tube logic.</div>
                <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-amber-400 text-xl">→</span>
                </div>
              </button>

              <button 
                onClick={() => onSelectMode('TURBO')}
                className="w-full group relative p-4 border border-cyan-900 bg-cyan-950/10 hover:bg-cyan-900/20 transition-all text-left overflow-hidden"
              >
                <div className="text-cyan-400 font-bold uppercase text-sm mb-1">Initialize Mk-II (Turbo)</div>
                <div className="text-[10px] text-cyan-800 font-mono">9.0 GHz Dataflow Architecture. 128 Registers. OoO Execution.</div>
                <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-cyan-400 text-xl">→</span>
                </div>
              </button>

              <button 
                onClick={() => onSelectMode('MAINFRAME')}
                className="w-full group relative p-4 border border-sky-900 bg-sky-950/10 hover:bg-sky-900/20 transition-all text-left overflow-hidden"
              >
                <div className="text-sky-400 font-bold uppercase text-sm mb-1">Initialize Mainframe Cluster</div>
                <div className="text-[10px] text-sky-800 font-mono">Distributed Z-Architecture. ACID Compliance. Sharded Infrastructure.</div>
                <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-sky-400 text-xl">→</span>
                </div>
              </button>
            </div>
          </div>

          {/* Right Column: Information */}
          <div className="flex flex-col justify-center space-y-6">
            <div className="bg-black/50 border border-gray-900 p-4 rounded-lg">
              <h3 className="text-[10px] text-gray-600 font-bold uppercase mb-3 border-b border-gray-900 pb-1">System Documentation</h3>
              <div className="grid grid-cols-1 gap-2">
                <button onClick={onOpenHelp} className="flex justify-between items-center text-[11px] text-gray-400 hover:text-amber-500 transition-colors font-mono py-1 border-b border-gray-900/50 last:border-0">
                  <span>[01] OPERATING INSTRUCTIONS</span>
                  <span className="text-gray-700">READ</span>
                </button>
                <button onClick={onOpenReadme} className="flex justify-between items-center text-[11px] text-gray-400 hover:text-cyan-500 transition-colors font-mono py-1 border-b border-gray-900/50 last:border-0">
                  <span>[02] TECHNICAL DOSSIER</span>
                  <span className="text-gray-700">READ</span>
                </button>
                <button onClick={onOpenCredits} className="flex justify-between items-center text-[11px] text-amber-500/80 hover:text-amber-400 transition-colors font-mono py-1 border-b border-gray-900/50 last:border-0 group">
                  <span className="group-hover:translate-x-1 transition-transform">[03] PERSONNEL IDENTIFICATION</span>
                  <span className="text-amber-900 group-hover:text-amber-700">VIEW</span>
                </button>
              </div>
            </div>

            <div className="p-4 border border-amber-900/30 bg-amber-950/5">
              <p className="text-[9px] text-amber-900 font-mono leading-relaxed italic">
                "The distributed core architecture represents the pinnacle of digital scaling, merging historical precision with petascale throughput."
              </p>
            </div>
          </div>
        </div>

        {/* Footer Author Credit */}
        <button 
          onClick={onOpenCredits}
          className="w-full border-t border-gray-900 pt-8 mt-4 flex flex-col items-center gap-2 opacity-50 hover:opacity-100 transition-opacity duration-500 group"
        >
           <p className="text-[10px] font-bold text-amber-600 uppercase tracking-[0.4em]">Designed & Engineered By</p>
           <p className="text-2xl font-bold text-gray-400 tracking-tighter group-hover:text-gray-200 transition-colors">Stephen Deline Jr</p>
           <p className="text-[8px] text-gray-600 uppercase font-mono mt-1">Project 2400 | Moore School of Electrical Engineering</p>
        </button>
      </div>
    </div>
  );
};
