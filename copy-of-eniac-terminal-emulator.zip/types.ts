
export type UserRole = 'ROOT' | 'ADMIN' | 'SUB_ADMIN' | 'USER';

export interface UserProfile {
  username: string;
  role: UserRole;
  homeDir: string;
  lastLogin: number;
}

export interface FileSystemEntry {
  id: string;
  name: string;
  type: 'FILE' | 'FOLDER';
  content?: string;
  owner: string;
  roleRequired: UserRole;
  children?: FileSystemEntry[];
  updatedAt: number;
}

export interface Message {
  id: string;
  sender: 'SYSTEM' | 'USER' | 'ENIAC';
  text: string;
  timestamp: Date;
}

export interface AccumulatorState {
  id: number;
  value: string; // 10-digit decimal
  active: boolean;
}

export interface CardDeck {
  id: string;
  name: string;
  description: string;
  cards: string[]; // Sequence of commands
}

export type ArchitectureType = 'VON_NEUMANN' | 'HARVARD';
export type SystemMode = 'CLASSIC' | 'TURBO' | 'MAINFRAME';
export type AppViewState = 'SPLASH' | 'TITLE' | 'LOGIN' | 'RUNNING' | 'DESKTOP' | 'EDITOR' | 'PUNCH_MACHINE' | 'CODE_EDITOR';

export interface DataflowTask {
  id: string;
  op: string;
  targetRegs: number[];
  status: 'QUEUED' | 'ACTIVE' | 'RETIRED';
}

export interface DebugLog {
  id: string;
  timestamp: string;
  op: string;
  regs: number[];
  change: string; 
}

export interface CacheEntry {
  tag: string;
  data: string;
  lastAccess: number;
}

export type TurboScheduler = 'ORDERED' | 'OUT_OF_ORDER' | 'SPECULATIVE';
export type PipelineDepth = 'STANDARD' | 'DEEP' | 'ULTRA_WIDE';

export interface TurboConfig {
  scheduler: TurboScheduler;
  pipelineDepth: PipelineDepth;
  clockSpeed: string;
  hazardMitigation: boolean;
}

export interface NodeState {
  id: string;
  type: 'COMPUTE' | 'STORAGE' | 'DATABASE' | 'NETWORK';
  status: 'ONLINE' | 'BUSY' | 'OFFLINE' | 'MAINTENANCE';
  load: number;
  temperature: number;
}
