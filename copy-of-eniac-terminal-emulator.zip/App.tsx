
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Terminal } from './components/Terminal';
import { SystemStatus } from './components/SystemStatus';
import { EniacClock } from './components/EniacClock';
import { AccumulatorMatrix } from './components/AccumulatorMatrix';
import { DataflowScheduler } from './components/DataflowScheduler';
import { DebugPanel } from './components/DebugPanel';
import { SplashScreen } from './components/SplashScreen';
import { HelpDocs } from './components/HelpDocs';
import { ProjectReadme } from './components/ProjectReadme';
import { AnalysisOutput } from './components/AnalysisOutput';
import { CreditsModal } from './components/CreditsModal';
import { InstructionCache } from './components/InstructionCache';
import { Desktop } from './components/Desktop';
import { FileEditor } from './components/FileEditor';
import { TurboALU } from './components/TurboALU';
import { PunchedCardReader } from './components/PunchedCardReader';
import { PunchMachine } from './components/PunchMachine';
import { CodeEditor } from './components/CodeEditor';
import { Message, AccumulatorState, SystemMode, ArchitectureType, AppViewState, CacheEntry, UserProfile, UserRole, FileSystemEntry, CardDeck } from './types';
import { getEniacResponse } from './services/geminiService';
import { audioService } from './services/audioService';

const SAVE_KEY = 'eniac_simulation_state_v14';

const INITIAL_USERS: Record<string, { role: UserRole, pass: string }> = {
  'OPERATOR': { role: 'ROOT', pass: 'ROOT' },
  'ARCHITECT': { role: 'ADMIN', pass: 'ADMIN' },
  'FACILITY': { role: 'SUB_ADMIN', pass: 'ENIAC' },
  'TECH1': { role: 'USER', pass: '1234' }
};

const INITIAL_FS: FileSystemEntry[] = [
  { id: '1', name: 'SYSTEM', type: 'FOLDER', owner: 'OPERATOR', roleRequired: 'ROOT', updatedAt: Date.now(), children: [
    { id: '2', name: 'KERNEL.BIN', type: 'FILE', owner: 'OPERATOR', roleRequired: 'ROOT', content: '01010101 binary kernel logic...', updatedAt: Date.now() },
    { id: '3', name: 'CONFIG.SYS', type: 'FILE', owner: 'OPERATOR', roleRequired: 'ROOT', content: 'CLOCK=9.0GHZ\nPIPELINE=ULTRA', updatedAt: Date.now() }
  ]},
  { id: '4', name: 'USER', type: 'FOLDER', owner: 'OPERATOR', roleRequired: 'USER', updatedAt: Date.now(), children: [
    { id: '5', name: 'TECH1', type: 'FOLDER', owner: 'OPERATOR', roleRequired: 'USER', updatedAt: Date.now(), children: [] }
  ]},
  { id: '6', name: 'PROGRAMS', type: 'FOLDER', owner: 'ARCHITECT', roleRequired: 'ADMIN', updatedAt: Date.now(), children: [] }
];

interface LoginViewProps {
  isRegisterMode: boolean;
  setIsRegisterMode: (val: boolean) => void;
  authError: string | null;
  onLogin: (u: string, p: string) => void;
  onRegister: (u: string, p: string, r: UserRole) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ isRegisterMode, setIsRegisterMode, authError, onLogin, onRegister }) => {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [r, setR] = useState<UserRole>('USER');

  const roles: UserRole[] = ['ROOT', 'ADMIN', 'SUB_ADMIN', 'USER'];

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center crt-effect z-[100]">
      <div className="w-80 border-2 border-amber-900 p-8 bg-black/80 flex flex-col gap-6 shadow-[0_0_30px_rgba(120,53,15,0.3)]">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-amber-500 tracking-widest glow-amber">
            {isRegisterMode ? 'REGISTRATION' : 'LOG-IN'}
          </h1>
          <p className="text-[8px] text-amber-900 uppercase font-mono mt-1 tracking-tighter">
            Personnel Identity Management v5.0
          </p>
        </div>
        <div className="space-y-4">
          <div className="flex flex-col gap-1">
             <label className="text-[7px] text-amber-900 font-bold uppercase">Operator Handle</label>
             <input 
              type="text" 
              value={u}
              onChange={(e) => setU(e.target.value)}
              placeholder="USERNAME"
              className="bg-black border border-amber-950 p-2 text-[10px] text-amber-500 outline-none uppercase font-mono focus:border-amber-500"
             />
             <label className="text-[7px] text-amber-900 font-bold uppercase mt-2">Security Key</label>
             <input 
              type="password" 
              value={p}
              onChange={(e) => setP(e.target.value)}
              placeholder="PASSWORD"
              className="bg-black border border-amber-950 p-2 text-[10px] text-amber-500 outline-none uppercase font-mono focus:border-amber-500"
             />

             {isRegisterMode && (
               <>
                 <label className="text-[7px] text-amber-900 font-bold uppercase mt-2">Clearance Level</label>
                 <select 
                  value={r}
                  onChange={(e) => setR(e.target.value as UserRole)}
                  className="bg-black border border-amber-950 p-2 text-[10px] text-amber-500 outline-none uppercase font-mono focus:border-amber-500 cursor-pointer"
                 >
                   {roles.map(role => (
                     <option key={role} value={role}>{role}</option>
                   ))}
                 </select>
               </>
             )}
          </div>
          {authError && (
            <p className="text-[8px] text-red-600 font-bold uppercase text-center animate-pulse">
              *** {authError} ***
            </p>
          )}
          <button 
            onClick={() => isRegisterMode ? onRegister(u, p, r) : onLogin(u, p)}
            className="w-full bg-amber-900/20 border border-amber-900 py-2 text-[10px] font-bold text-amber-500 hover:bg-amber-900 transition-colors"
          >
            {isRegisterMode ? 'CREATE RECORD' : 'ESTABLISH LINK'}
          </button>
          <button 
            onClick={() => { 
              setIsRegisterMode(!isRegisterMode);
              setU('');
              setP('');
            }}
            className="w-full text-[8px] text-amber-800 hover:text-amber-500 underline uppercase tracking-widest"
          >
            {isRegisterMode ? 'BACK TO LOG-IN' : 'REGISTER NEW OPERATOR'}
          </button>
        </div>
        <div className="text-center">
           <p className="text-[6px] text-gray-800 uppercase">Unauthorized access is logged to core memory.</p>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [viewState, setViewState] = useState<AppViewState>('SPLASH');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [systemMode, setSystemMode] = useState<SystemMode>('CLASSIC');
  const [architecture, setArchitecture] = useState<ArchitectureType>('VON_NEUMANN');
  const [startTime] = useState(Date.now() - 512532000); 
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [isCrtEnabled, setIsCrtEnabled] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isCalcMode, setIsCalcMode] = useState(false);
  const [isCreditsOpen, setIsCreditsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isReadmeOpen, setIsReadmeOpen] = useState(false);
  const [instructionCache, setInstructionCache] = useState<CacheEntry[]>([]);
  const [lastCacheStatus, setLastCacheStatus] = useState<'HIT' | 'MISS' | null>(null);

  // Management State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [users, setUsers] = useState<Record<string, { role: UserRole, pass: string }>>(INITIAL_USERS);
  const [fileSystem, setFileSystem] = useState<FileSystemEntry[]>(INITIAL_FS);
  const [currentPath, setCurrentPath] = useState<string>('/');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [editingFile, setEditingFile] = useState<FileSystemEntry | null>(null);
  const [lastALUOp, setLastALUOp] = useState<any>(null);
  const [customDecks, setCustomDecks] = useState<CardDeck[]>([]);
  const [analysisHistory, setAnalysisHistory] = useState<any[]>([]);

  const [accumulators, setAccumulators] = useState<AccumulatorState[]>(
    Array.from({ length: 20 }, (_, i) => ({ id: i + 1, value: "0000000000", active: false }))
  );

  useEffect(() => {
    if (systemMode === 'TURBO' && accumulators.length < 128) {
       setAccumulators(prev => [
         ...prev,
         ...Array.from({ length: 128 - prev.length }, (_, i) => ({ id: prev.length + i + 1, value: "0000000000", active: false }))
       ]);
    } else if (systemMode !== 'TURBO' && accumulators.length > 20) {
      setAccumulators(prev => prev.slice(0, 20));
    }
  }, [systemMode]);

  const uptimeStr = useMemo(() => {
    const diff = currentTime - startTime;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const secs = Math.floor((diff % (1000 * 60)) / 1000);
    return `${hours.toString().padStart(4, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, [startTime, currentTime]);

  const saveState = useCallback(() => {
    const state = {
      systemMode,
      architecture,
      isMuted,
      isCrtEnabled,
      currentUser,
      users,
      fileSystem,
      currentPath,
      messages: messages.slice(-50),
      customDecks,
      analysisHistory
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  }, [systemMode, architecture, isMuted, isCrtEnabled, currentUser, users, fileSystem, currentPath, messages, customDecks, analysisHistory]);

  const loadState = useCallback(() => {
    const saved = localStorage.getItem(SAVE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSystemMode(parsed.systemMode || 'CLASSIC');
        setArchitecture(parsed.architecture || 'VON_NEUMANN');
        setIsMuted(parsed.isMuted || false);
        setIsCrtEnabled(parsed.isCrtEnabled !== undefined ? parsed.isCrtEnabled : true);
        setCurrentUser(parsed.currentUser || null);
        setUsers(parsed.users || INITIAL_USERS);
        setFileSystem(parsed.fileSystem || INITIAL_FS);
        setCurrentPath(parsed.currentPath || '/');
        setMessages((parsed.messages || []).map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) })));
        setCustomDecks(parsed.customDecks || []);
        setAnalysisHistory(parsed.analysisHistory || []);
      } catch (e) { console.error("Load failed", e); }
    }
  }, []);

  useEffect(() => { loadState(); }, [loadState]);
  useEffect(() => { saveState(); }, [saveState]);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getCurrentFolderEntries = useCallback(() => {
    if (currentPath === '/') return fileSystem;
    const parts = currentPath.split('/').filter(p => p);
    let current: FileSystemEntry[] = fileSystem;
    for (const part of parts) {
      const found = current.find(e => e.name === part && e.type === 'FOLDER');
      if (found && found.children) {
        current = found.children;
      }
    }
    return current;
  }, [currentPath, fileSystem]);

  const updateFileSystemRecursive = (entries: FileSystemEntry[], targetId: string, newContent: string): FileSystemEntry[] => {
    return entries.map(entry => {
      if (entry.id === targetId) {
        return { ...entry, content: newContent, updatedAt: Date.now() };
      }
      if (entry.children) {
        return { ...entry, children: updateFileSystemRecursive(entry.children, targetId, newContent) };
      }
      return entry;
    });
  };

  const addFolderRecursive = (entries: FileSystemEntry[], pathParts: string[], newFolder: FileSystemEntry): FileSystemEntry[] => {
    if (pathParts.length === 0) {
      return [...entries, newFolder];
    }
    const [current, ...rest] = pathParts;
    return entries.map(entry => {
      if (entry.name === current && entry.type === 'FOLDER') {
        return {
          ...entry,
          children: addFolderRecursive(entry.children || [], rest, newFolder)
        };
      }
      return entry;
    });
  };

  const searchFilesRecursive = (entries: FileSystemEntry[], term: string, pathPrefix: string): string[] => {
    let results: string[] = [];
    for (const entry of entries) {
      const fullPath = `${pathPrefix === '/' ? '' : pathPrefix}/${entry.name}`;
      if (entry.type === 'FILE' && entry.name.toUpperCase().includes(term.toUpperCase())) {
        results.push(fullPath);
      }
      if (entry.type === 'FOLDER' && entry.children) {
        results = [...results, ...searchFilesRecursive(entry.children, term, fullPath)];
      }
    }
    return results;
  };

  const handleSaveFile = (newContent: string) => {
    if (!editingFile) return;
    setFileSystem(prev => updateFileSystemRecursive(prev, editingFile.id, newContent));
    setEditingFile(null);
    setViewState('RUNNING');
    setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `FILE '${editingFile.name}' COMMITTED TO DISK SUCCESSFULLY.`, timestamp: new Date() }]);
  };

  const handleRegister = (username: string, pass: string, role: UserRole) => {
    const u = username.toUpperCase();
    const p = pass.toUpperCase();
    if (!u || !p) {
      setAuthError("FIELD INPUT REQUIRED");
      return;
    }
    if (users[u]) {
      setAuthError("HANDLE ALREADY RESERVED");
      return;
    }

    const newUsers = { ...users, [u]: { role: role, pass: p } };
    setUsers(newUsers);

    const newFs = [...fileSystem];
    const userFolder = newFs.find(e => e.name === 'USER');
    if (userFolder && userFolder.children) {
      userFolder.children.push({
        id: `u-${Date.now()}`,
        name: u,
        type: 'FOLDER',
        owner: u,
        roleRequired: 'USER',
        updatedAt: Date.now(),
        children: []
      });
    }
    setFileSystem(newFs);

    setAuthError(null);
    setIsRegisterMode(false);
    setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `NEW OPERATOR REGISTERED: ${u}. CLEARANCE: ${role}.`, timestamp: new Date() }]);
    audioService.playRelay();
  };

  const performALUOperation = async (op: string, aId: number, bId: number, targetId: number) => {
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 800));

    setAccumulators(prev => {
      const next = [...prev];
      const accA = next.find(a => a.id === aId);
      const accB = next.find(a => a.id === bId);
      const accTarget = next.find(a => a.id === targetId);

      if (!accA || !accTarget || (op !== 'NOT' && !accB)) return prev;

      const valA = BigInt(accA.value);
      const valB = op !== 'NOT' ? BigInt(accB!.value) : 0n;
      let result = 0n;

      const MASK_34 = (1n << 34n) - 1n;
      const MAX_DEC = 10000000000n;

      switch(op) {
        case 'ADD': result = (valA + valB) % MAX_DEC; break;
        case 'SUB': result = (valA - valB + MAX_DEC) % MAX_DEC; break;
        case 'AND': result = (valA & valB) & MASK_34; break;
        case 'OR': result = (valA | valB) & MASK_34; break;
        case 'NOT': result = (~valA) & MASK_34; break;
      }

      const resStr = result.toString().padStart(10, '0').slice(-10);
      const updatedIdx = next.findIndex(a => a.id === targetId);
      next[updatedIdx] = { ...accTarget, value: resStr, active: true };
      
      setTimeout(() => {
        setAccumulators(curr => curr.map(a => a.id === targetId ? { ...a, active: false } : a));
      }, 500);

      setLastALUOp({ op, a: aId, b: bId, target: targetId, result: resStr });
      setAnalysisHistory(h => [{ id: `res-${Date.now()}`, value: resStr, timestamp: new Date() }, ...h].slice(0, 50));
      return next;
    });

    setIsLoading(false);
    audioService.playDataStream();
  };

  const handleCommand = async (cmd: string) => {
    const args = cmd.trim().split(/\s+/);
    const action = args[0].toUpperCase();
    audioService.playClick(systemMode);

    setMessages(prev => [...prev, { id: `u-${Date.now()}`, sender: 'USER', text: cmd, timestamp: new Date() }]);

    if (action === 'LOGIN') {
      const user = args[1]?.toUpperCase();
      const pass = args[2]?.toUpperCase();
      if (users[user] && users[user].pass === pass) {
        setCurrentUser({ username: user, role: users[user].role, homeDir: `/USER/${user}`, lastLogin: Date.now() });
        setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `AUTHENTICATION SUCCESSFUL. WELCOME, ${user}.`, timestamp: new Date() }]);
        setAuthError(null);
        setViewState('RUNNING');
      } else {
        setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `AUTHENTICATION FAILED: INVALID CREDENTIALS.`, timestamp: new Date() }]);
        setAuthError("INVALID CREDENTIALS");
      }
      return;
    }

    if (action === 'LOGOUT') {
      setCurrentUser(null);
      setViewState('LOGIN');
      return;
    }

    if (!currentUser && !['HELP', 'CLEAR'].includes(action)) {
      setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `ACCESS DENIED: USER AUTHENTICATION REQUIRED.`, timestamp: new Date() }]);
      return;
    }

    if (['ADD', 'SUB', 'AND', 'OR', 'NOT'].includes(action)) {
      const a = parseInt(args[1]);
      const b = parseInt(args[2]);
      const t = parseInt(args[3]);
      performALUOperation(action, a, b, t || b);
      return;
    }

    if (action === 'MODE') {
      const m = args[1]?.toUpperCase();
      if (m === 'CALC') setIsCalcMode(true);
      else if (m === 'CMD') setIsCalcMode(false);
      else if (['CLASSIC', 'TURBO', 'MAINFRAME'].includes(m)) setSystemMode(m as SystemMode);
      return;
    }

    if (action === 'EDIT') {
      const target = args[1];
      if (!target) return;
      const entries = getCurrentFolderEntries();
      const found = entries.find(e => e.name.toUpperCase() === target.toUpperCase() && e.type === 'FILE');
      if (found) {
        setEditingFile(found);
        setViewState('EDITOR');
      }
      return;
    }

    if (action === 'MKDIR') {
      const folderName = args[1]?.toUpperCase();
      if (!folderName) {
        setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `ERROR: SPECIFY FOLDER NAME.`, timestamp: new Date() }]);
        return;
      }
      const entries = getCurrentFolderEntries();
      if (entries.find(e => e.name.toUpperCase() === folderName && e.type === 'FOLDER')) {
        setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `ERROR: FOLDER '${folderName}' ALREADY EXISTS.`, timestamp: new Date() }]);
        return;
      }
      
      const newFolder: FileSystemEntry = {
        id: `f-${Date.now()}`,
        name: folderName,
        type: 'FOLDER',
        owner: currentUser!.username,
        roleRequired: 'USER',
        updatedAt: Date.now(),
        children: []
      };

      const pathParts = currentPath.split('/').filter(p => p);
      setFileSystem(prev => addFolderRecursive(prev, pathParts, newFolder));
      setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `FOLDER '${folderName}' CREATED SUCCESSFULLY.`, timestamp: new Date() }]);
      return;
    }

    if (action === 'SEARCH') {
      const term = args[1];
      if (!term) {
        setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `ERROR: SPECIFY SEARCH TERM.`, timestamp: new Date() }]);
        return;
      }
      
      const entries = getCurrentFolderEntries();
      const results = searchFilesRecursive(entries, term, currentPath);
      
      if (results.length > 0) {
        setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `SEARCH RESULTS FOR '${term}':\n${results.join('\n')}`, timestamp: new Date() }]);
      } else {
        setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `NO MATCHES FOUND FOR '${term}' IN ${currentPath}.`, timestamp: new Date() }]);
      }
      return;
    }

    if (action === 'CD') {
      const target = args[1];
      if (!target) return;
      if (target === '..') {
        const parts = currentPath.split('/').filter(p => p);
        parts.pop();
        setCurrentPath('/' + (parts.length > 0 ? parts.join('/') : ''));
      } else if (target === '/') {
        setCurrentPath('/');
      } else {
        const entries = getCurrentFolderEntries();
        const found = entries.find(e => e.name.toUpperCase() === target.toUpperCase() && e.type === 'FOLDER');
        if (found) setCurrentPath((currentPath === '/' ? '' : currentPath) + '/' + found.name);
      }
      return;
    }

    if (action === 'DESKTOP') { setViewState('DESKTOP'); return; }
    if (action === 'TERMINAL') { setViewState('RUNNING'); return; }
    if (action === 'WHOAMI') {
      setMessages(prev => [...prev, { id: `s-${Date.now()}`, sender: 'SYSTEM', text: `USER: ${currentUser?.username}\nROLE: ${currentUser?.role}\nPATH: ${currentPath}`, timestamp: new Date() }]);
      return;
    }

    setIsLoading(true);
    try {
      const response = await getEniacResponse(cmd, isCalcMode, systemMode);
      setMessages(prev => [...prev, { id: `e-${Date.now()}`, sender: 'ENIAC', text: response, timestamp: new Date() }]);
      if (isCalcMode && response.includes("RESULT:")) {
        const res = response.split("RESULT:")[1].trim().slice(0, 10);
        setAnalysisHistory(h => [{ id: `res-${Date.now()}`, value: res, timestamp: new Date() }, ...h].slice(0, 50));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSplashComplete = useCallback(() => {
    setViewState('LOGIN');
    setIsCreditsOpen(true);
  }, []);

  const renderContent = () => {
    if (viewState === 'SPLASH') return <SplashScreen onComplete={handleSplashComplete} />;
    if (viewState === 'LOGIN' && !currentUser) {
      return (
        <LoginView 
          isRegisterMode={isRegisterMode} 
          setIsRegisterMode={setIsRegisterMode} 
          authError={authError} 
          onLogin={(u, p) => handleCommand(`LOGIN ${u} ${p}`)} 
          onRegister={handleRegister} 
        />
      );
    }

    return (
      <div className={`flex flex-col h-screen bg-[#050505] text-gray-300 font-mono overflow-hidden ${isCrtEnabled ? 'crt-enabled' : ''}`}>
        <header className="h-16 border-b border-gray-800 bg-black flex items-center shrink-0">
          <SystemStatus 
            activeTubes={115} totalTubes={120} powerKw={150} uptime={uptimeStr} isProcessing={isLoading} mode={systemMode} 
            architecture={architecture} onToggleArchitecture={() => setArchitecture(a => a === 'HARVARD' ? 'VON_NEUMANN' : 'HARVARD')} 
            isMuted={isMuted} onToggleMute={() => setIsMuted(m => !m)} isCrtEnabled={isCrtEnabled} onToggleCrt={() => setIsCrtEnabled(c => !c)}
          />
        </header>

        <main className="flex-1 overflow-hidden grid grid-cols-[300px_1fr_320px] gap-4 p-4">
          <section className="flex flex-col gap-4 overflow-hidden">
             <EniacClock />
             <PunchedCardReader 
                onLoadDeck={(d) => d.cards.forEach((c, i) => setTimeout(() => handleCommand(c), i * 1000))}
                onOpenPunchMachine={() => setViewState('PUNCH_MACHINE')}
                isProcessing={isLoading}
                customDecks={customDecks}
             />
             <div className="flex-1">
               <DataflowScheduler tasks={[]} isActive={isLoading} />
             </div>
          </section>

          <section className="flex flex-col gap-4 overflow-hidden relative">
            {viewState === 'DESKTOP' ? (
              <Desktop 
                currentPath={currentPath} 
                entries={getCurrentFolderEntries()} 
                user={currentUser} 
                onNavigate={(p) => handleCommand(`CD ${p}`)} 
                onOpenFile={(f) => handleCommand(`EDIT ${f.name}`)}
              />
            ) : viewState === 'EDITOR' && editingFile ? (
              <FileEditor 
                file={editingFile} 
                onSave={handleSaveFile} 
                onCancel={() => { setEditingFile(null); setViewState('RUNNING'); }} 
              />
            ) : viewState === 'PUNCH_MACHINE' ? (
              <PunchMachine 
                onPunchComplete={(d) => { setCustomDecks(prev => [...prev, d]); setViewState('RUNNING'); }} 
                onCancel={() => setViewState('RUNNING')}
              />
            ) : viewState === 'CODE_EDITOR' ? (
              <CodeEditor 
                onExecute={(c, l) => { handleCommand(`[${l}] ${c}`); setViewState('RUNNING'); }} 
                onCancel={() => setViewState('RUNNING')}
              />
            ) : (
              <Terminal messages={messages} onCommand={handleCommand} isLoading={isLoading} isCalcMode={isCalcMode} />
            )}
            
            <div className="h-40">
               <AccumulatorMatrix accumulators={accumulators} isTurbo={systemMode === 'TURBO'} />
            </div>
            <div className="absolute top-4 right-4 flex gap-2">
              <button onClick={() => setViewState('CODE_EDITOR')} className="px-3 py-1 bg-emerald-950/20 border border-emerald-900 text-[8px] font-bold uppercase hover:border-emerald-400 transition-colors">Programmer</button>
              <button onClick={() => setViewState(viewState === 'DESKTOP' ? 'RUNNING' : 'DESKTOP')} className="px-3 py-1 bg-gray-900 border border-gray-700 text-[8px] font-bold uppercase hover:border-amber-500 transition-colors">{viewState === 'DESKTOP' ? 'TERMINAL' : 'DESKTOP Shell'}</button>
              <button onClick={() => handleCommand('LOGOUT')} className="px-3 py-1 bg-red-950/20 border border-red-900 text-[8px] font-bold uppercase text-red-500 hover:bg-red-900 transition-colors">Sign Out</button>
            </div>
          </section>

          <section className="flex flex-col gap-4 overflow-hidden">
             {systemMode === 'TURBO' ? (
               <TurboALU isProcessing={isLoading} onExecute={performALUOperation} lastOperation={lastALUOp} />
             ) : (
               <AnalysisOutput history={analysisHistory} isTurbo={systemMode === 'TURBO'} />
             )}
             {systemMode === 'TURBO' && <InstructionCache entries={instructionCache} lastResult={lastCacheStatus} />}
             <DebugPanel logs={[]} isEnabled={true} onToggle={() => {}} />
          </section>
        </main>

        <HelpDocs isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />
        <ProjectReadme isOpen={isReadmeOpen} onClose={() => setIsReadmeOpen(false)} />
        <CreditsModal isOpen={isCreditsOpen} onClose={() => setIsCreditsOpen(false)} />
      </div>
    );
  };

  return <div className={isCrtEnabled ? 'crt-enabled' : ''}>{renderContent()}</div>;
};

export default App;
