
import { useState, useCallback } from 'react';
import { GameState, GameChoice, GameUpdateResponse, CharacterCreationData, User, Realm, Character, Item, EquipmentSlot, Armor, Weapon, CraftingMaterial, Recipe, Consumable } from '../types';
import { gameApiService } from '../services/gameApiService';
import { saveGameService } from '../services/saveGameService';
import { authService } from '../services/authService';
import { getAbilityModifier, getProficiencyBonus } from '../data/dnd5e/rules';
import { dndSkills } from '../data/dnd5e/skills';
import { Character5e, Skill, ABILITIES } from '../dnd5e-types';
import { getItemById, allItems } from '../data/items';

const initialGameState: GameState = {
    character: null,
    narrative: 'Create your character to begin your journey in the Shattered Realms.',
    imageUrl: null,
    choices: [],
    history: [],
    worldTier: 1,
    questCount: 0,
    act: 1,
    chapter: 1,
    saveSlot: 0,
    realmName: 'Unknown',
    quests: [],
    discoveredEnemies: [],
    unlockedTalents: [],
    completedAchievements: [],
};

const calculateArmorClass = (character: Character): number => {
    const dexModifier = getAbilityModifier(character.abilityScores.dex);
    const armorDefense = (Object.values(character.equipment) as (Weapon | Armor | undefined)[])
        .filter((item): item is Armor => !!item && 'defense' in item)
        .reduce((sum, armor) => sum + (armor.defense + (armor.masterworkLevel || 0)), 0);
    return 10 + armorDefense + dexModifier;
};

const calculateCarryingCapacity = (str: number): number => str * 15;

export const useGameEngine = () => {
    const [gameState, setGameState] = useState<GameState>(initialGameState);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [currentRealm, setCurrentRealm] = useState<Realm | null>(null);

    const updateGameState = useCallback((updates: Partial<GameState>) => {
        setGameState(prev => {
            const newState = { ...prev, ...updates };
            const user = authService.getCurrentUser();
            const realm = currentRealm;
            if (user && realm) {
                saveGameService.autoSave(newState, user, realm);
            }
            return newState;
        });
    }, [currentRealm]);

    const modifyReputation = useCallback((factionId: string, amount: number) => {
        setGameState(prev => {
            if (!prev.character) return prev;
            const newRep = { ...prev.character.reputation };
            newRep[factionId] = (newRep[factionId] || 0) + amount;
            const newState = { ...prev, character: { ...prev.character, reputation: newRep } };
            const user = authService.getCurrentUser();
            const realm = currentRealm;
            if (user && realm) {
                saveGameService.autoSave(newState, user, realm);
            }
            return newState;
        });
    }, [currentRealm]);

    const useConsumable = useCallback((inventoryIndex: number) => {
        setGameState(prev => {
            if (!prev.character) return prev;
            const char = { ...prev.character };
            const item = char.inventory[inventoryIndex];

            if (item && 'type' in item && item.type === 'Consumable') {
                const consumable = item as Consumable;
                
                if (consumable.effect.hp) char.hp = Math.min(char.maxHp, char.hp + consumable.effect.hp);
                if (consumable.effect.mp) char.mp = Math.min(char.maxMp, char.mp + consumable.effect.mp);
                if (consumable.effect.sp) char.sp = Math.min(char.maxSp, char.sp + consumable.effect.sp);
                if (consumable.effect.buff) char.statusEffects = [...char.statusEffects, consumable.effect.buff];

                const newInventory = [...char.inventory];
                newInventory.splice(inventoryIndex, 1);
                char.inventory = newInventory;

                const newState = { ...prev, character: char };
                const user = authService.getCurrentUser();
                const realm = currentRealm;
                if (user && realm) {
                    saveGameService.autoSave(newState, user, realm);
                }
                return newState;
            }
            return prev;
        });
    }, [currentRealm]);

    const craftItem = useCallback((recipe: Recipe) => {
        setGameState(prev => {
            if (!prev.character) return prev;
            const char = { ...prev.character };
            
            for (const ingredient of recipe.ingredients) {
                const available = char.materials[ingredient.id] || 0;
                if (available < ingredient.quantity) {
                    alert(`Not enough ${ingredient.id}!`);
                    return prev;
                }
            }

            const newMaterials = { ...char.materials };
            for (const ingredient of recipe.ingredients) {
                newMaterials[ingredient.id]! -= ingredient.quantity;
            }

            const newItem = getItemById(recipe.resultItemId);
            if (!newItem) return prev;

            const newInventory = [...char.inventory, newItem];
            char.experience += recipe.xpReward;
            
            const updatedChar: Character = {
                ...char,
                materials: newMaterials,
                inventory: newInventory as (Weapon | Armor | CraftingMaterial | Consumable)[],
            };

            const xpThreshold = updatedChar.level * 200;
            if (updatedChar.experience >= xpThreshold) {
                updatedChar.level += 1;
                updatedChar.experience -= xpThreshold;
                updatedChar.maxHp += 10;
                updatedChar.hp = updatedChar.maxHp;
                updatedChar.talentPoints += 1;
            }

            const newState = { ...prev, character: updatedChar };
            const user = authService.getCurrentUser();
            const realm = currentRealm;
            if (user && realm) {
                saveGameService.autoSave(newState, user, realm);
            }
            return newState;
        });
    }, [currentRealm]);

    const masterworkItem = useCallback((location: { type: 'inventory', index: number } | { type: 'equipment', slot: EquipmentSlot }) => {
        setGameState(prev => {
            if (!prev.character) return prev;
            const char = { ...prev.character };
            const materials = { ...char.materials };
            
            let item: Weapon | Armor | undefined;
            if (location.type === 'inventory') {
                item = char.inventory[location.index] as Weapon | Armor;
            } else {
                item = char.equipment[location.slot];
            }

            if (!item) return prev;

            const currentLevel = item.masterworkLevel || 0;
            if (currentLevel >= 10) return prev;

            const cost = (currentLevel + 1) * 2;
            const ironAvailable = materials['mat_iron_ingot'] || 0;

            if (ironAvailable < cost) {
                alert("Not enough iron ingots!");
                return prev;
            }

            const newMaterials = { ...materials, 'mat_iron_ingot': ironAvailable - cost };
            const upgradedItem = { ...item, masterworkLevel: currentLevel + 1 };

            let newInventory = [...char.inventory];
            let newEquipment = { ...char.equipment };

            if (location.type === 'inventory') {
                newInventory[location.index] = upgradedItem as any;
            } else {
                newEquipment[location.slot] = upgradedItem;
            }

            const updatedChar: Character = {
                ...char,
                materials: newMaterials,
                inventory: newInventory as (Weapon | Armor | CraftingMaterial | Consumable)[],
                equipment: newEquipment,
            };

            updatedChar.armorClass = calculateArmorClass(updatedChar);

            const newState = { ...prev, character: updatedChar };
            const user = authService.getCurrentUser();
            const realm = currentRealm;
            if (user && realm) {
                saveGameService.autoSave(newState, user, realm);
            }
            return newState;
        });
    }, [currentRealm]);

    const manualSaveGame = useCallback(async (): Promise<boolean> => {
        const user = authService.getCurrentUser();
        const realm = currentRealm;
        if (!user || !realm || !gameState.character) return false;
        return await saveGameService.manualSave(gameState, user, realm);
    }, [gameState, currentRealm]);

    const applyUpdate = useCallback((update: GameUpdateResponse, user: User, realm: Realm) => {
        setGameState(prev => {
            if (!prev.character) return prev;
            const baseCharacter = prev.character;
            
            const newInventoryItems = (update.characterUpdate?.newItems || [])
                .map(itemData => allItems.find(i => i.id === itemData.id) || itemData)
                .filter((i): i is Weapon | Armor | CraftingMaterial | Consumable => i !== undefined);

            const newMaterials = { ...baseCharacter.materials };
            if (update.characterUpdate?.newMaterials) {
                update.characterUpdate.newMaterials.forEach(mat => {
                    newMaterials[mat.id] = (newMaterials[mat.id] || 0) + mat.quantity;
                });
            }

            const newReputation = { ...baseCharacter.reputation };
            if (update.characterUpdate?.reputationUpdate) {
                update.characterUpdate.reputationUpdate.forEach(u => {
                    newReputation[u.factionId] = (newReputation[u.factionId] || 0) + u.amount;
                });
            }

            const characterWithUpdates: Character = { 
                ...baseCharacter, 
                ...update.characterUpdate,
                gold: baseCharacter.gold + (update.characterUpdate?.gold || 0),
                reputation: newReputation,
                inventory: [...baseCharacter.inventory, ...newInventoryItems],
                materials: newMaterials,
            };
            
            if (update.location) characterWithUpdates.location = update.location.name;

            let newQuests = [...prev.quests];
            if (update.progressUpdate?.newQuest) newQuests.push(update.progressUpdate.newQuest);

            const newState: GameState = {
                ...prev,
                character: characterWithUpdates,
                narrative: update.narrative,
                choices: update.choices,
                history: [...prev.history, update.narrative],
                quests: newQuests,
            };
            
            saveGameService.autoSave(newState, user, realm);
            return newState;
        });
    }, []);

    const loadGame = useCallback(async (loadedState: GameState, realm: Realm): Promise<boolean> => {
        setIsLoading(false); // No need to show internal loading during initial load screen transition
        setCurrentRealm(realm);
        setGameState({ ...loadedState, realmName: realm.name, imageUrl: loadedState.imageUrl });
        
        // Re-generate image if it was lost or for freshness
        const imagePrompt = `A scene depicting: ${loadedState.narrative.substring(0, 150)}`;
        gameApiService.generateImage(imagePrompt).then(url => {
            if (url) setGameState(prev => ({ ...prev, imageUrl: url }));
        });
        return true;
    }, []);

    const startGame = useCallback(async (characterData: CharacterCreationData, user: User, realm: Realm, slot: number): Promise<boolean> => {
        setIsLoading(true);
        setCurrentRealm(realm);
        
        const finalAbilityScores = { ...characterData.abilityScores };
        for (const [ability, increase] of Object.entries(characterData.dndRace.abilityScoreIncreases)) {
            finalAbilityScores[ability as keyof typeof finalAbilityScores] += (increase || 0);
        }

        const skills: Skill[] = dndSkills.map(skillInfo => ({
            name: skillInfo.name,
            ability: skillInfo.ability,
            proficient: characterData.skillProficiencies.includes(skillInfo.name),
        }));

        const initialCharacter: Character = {
            abilityScores: finalAbilityScores,
            skills,
            savingThrows: {},
            proficiencyBonus: 2,
            armorClass: 10 + getAbilityModifier(finalAbilityScores.dex),
            speed: characterData.dndRace.speed,
            hitDie: characterData.dndClass.hitDie,
            name: characterData.name,
            class: characterData.dndClass.name,
            raceName: characterData.dndRace.name,
            level: 1,
            expansionLevel: 0,
            experience: 0,
            hp: characterData.dndClass.hitDie + getAbilityModifier(finalAbilityScores.con),
            maxHp: characterData.dndClass.hitDie + getAbilityModifier(finalAbilityScores.con),
            mp: 10 + getAbilityModifier(finalAbilityScores.int),
            maxMp: 10 + getAbilityModifier(finalAbilityScores.int),
            sp: 10 + getAbilityModifier(finalAbilityScores.con),
            maxSp: 10 + getAbilityModifier(finalAbilityScores.con),
            avatarUrl: '',
            statusEffects: [],
            location: 'The Awakening Glade',
            talentPoints: 0,
            knownSpells: [],
            inventory: [],
            equipment: {},
            materials: { 'mat_iron_ingot': 10 },
            carryingCapacity: calculateCarryingCapacity(finalAbilityScores.str),
            gold: 100,
            reputation: { 'ashen_circle': 0, 'glintstone_remnant': 0, 'jotun_blooded': 0 }
        };

        const tempState: GameState = {
            ...initialGameState,
            realmName: realm.name,
            saveSlot: slot,
            character: initialCharacter,
            narrative: 'Your thread of fate is being woven. You are awakening...',
        };

        // Transition to gameplay immediately to show character sheet
        setGameState(tempState);

        // Fetch initial DM narrative in background
        gameApiService.getInitialState(tempState).then(async (update) => {
            if (update) {
                const finalState: GameState = { 
                    ...tempState, 
                    narrative: update.narrative, 
                    choices: update.choices,
                    history: [update.narrative]
                };
                
                setGameState(finalState);
                
                // Immediately persist the new character to the database slot
                await saveGameService.manualSave(finalState, user, realm);
                
                // Trigger first image generation immediately for visual consistency
                gameApiService.generateImage(update.imagePrompt).then(url => {
                    if (url) setGameState(prev => ({ ...prev, imageUrl: url }));
                });
            }
            setIsLoading(false);
        }).catch(err => {
            console.error("DM failed to start:", err);
            setGameState(prev => ({ ...prev, narrative: "The DM is silent. The runes are unreadable. Please check your connection and try again." }));
            setIsLoading(false);
        });

        // Return true early so the app switches to GAMEPLAY view immediately
        return true;
    }, []);

    const handlePlayerChoice = useCallback(async (choice: GameChoice) => {
        const user = authService.getCurrentUser();
        const realm = currentRealm; 
        if(!user || !realm) return;
        setIsLoading(true);
        setGameState(prev => ({...prev, narrative: `You chose to: ${choice.text}...`, choices: [] }));
        const update = await gameApiService.getGameUpdate(gameState, choice.action);
        if (update) {
            applyUpdate(update, user, realm);
            setIsLoading(false);
            gameApiService.generateImage(update.imagePrompt).then(url => {
                if (url) setGameState(prev => ({...prev, imageUrl: url}));
            });
        } else {
             setIsLoading(false);
        }
    }, [gameState, applyUpdate, currentRealm]);

    const equipItem = useCallback((inventoryIndex: number) => {
        setGameState(prev => {
            if (!prev.character) return prev;
            const char = { ...prev.character };
            const newInventory = [...char.inventory];
            const itemToEquip = newInventory[inventoryIndex];
            if ('type' in itemToEquip && itemToEquip.type === 'Material') return prev;
            
            let slot: EquipmentSlot | null = null;
            if ('damage' in itemToEquip) slot = 'rightHand1'; 
            else if ('defense' in itemToEquip) slot = (itemToEquip as Armor).slot;
            if (!slot) return prev;
            
            const currentItem = char.equipment[slot];
            newInventory.splice(inventoryIndex, 1);
            if (currentItem) newInventory.push(currentItem);
            
            const newEquipment = { ...char.equipment, [slot]: itemToEquip as Weapon | Armor };
            const updatedChar: Character = {
                ...char,
                equipment: newEquipment,
                inventory: newInventory as (Weapon | Armor | CraftingMaterial | Consumable)[],
            };
            updatedChar.armorClass = calculateArmorClass(updatedChar);
            
            const newState = { ...prev, character: updatedChar };
            const user = authService.getCurrentUser();
            const realm = currentRealm;
            if (user && realm) {
                saveGameService.autoSave(newState, user, realm);
            }
            return newState;
        });
    }, [currentRealm]);

    return { 
        gameState, 
        isLoading, 
        handlePlayerChoice, 
        startGame, 
        loadGame, 
        equipItem, 
        craftItem, 
        useConsumable,
        modifyReputation, 
        updateGameState, 
        masterworkItem, 
        manualSaveGame 
    };
};
