import { useState, useEffect } from 'react';

// A simple hook to check the server's health status periodically.
export const useServerStatus = () => {
    const [isOnline, setIsOnline] = useState(false);

    useEffect(() => {
        const checkStatus = async () => {
            try {
                // Use a timeout to prevent long waits on a dead server
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 3000);

                // Use relative URL to leverage the proxy configuration in vite.config.ts
                const response = await fetch('/api/health', {
                    signal: controller.signal
                });
                
                clearTimeout(timeoutId);

                if (response.ok) {
                    const data = await response.json();
                    setIsOnline(data.status === 'ok');
                } else {
                    setIsOnline(false);
                }
            } catch (error) {
                setIsOnline(false);
            }
        };

        checkStatus(); // Initial check
        const intervalId = setInterval(checkStatus, 15000); // Check every 15 seconds

        return () => clearInterval(intervalId);
    }, []);

    return isOnline;
};