

import React from 'react';

// --- Core D&D 5e Enumerations and Types ---

export const ABILITIES = ['str', 'dex', 'con', 'int', 'wis', 'cha'] as const;
export type Ability = typeof ABILITIES[number];

export const SKILLS = [
    'acrobatics', 'animal_handling', 'arcana', 'athletics', 'deception', 'history',
    'insight', 'intimidation', 'investigation', 'medicine', 'nature', 'perception',
    'performance', 'persuasion', 'religion', 'sleight_of_hand', 'stealth', 'survival'
] as const;
export type SkillName = typeof SKILLS[number];

// --- Data Structures for Game Data ---

export interface Dnd5eRace {
    id: string;
    name: string;
    description: string;
    abilityScoreIncreases: Partial<Record<Ability, number>>;
    speed: number;
    traits: { name: string; description:string; }[];
}

export interface Dnd5eClass {
    id: string;
    name: string;
    description: string;
    hitDie: number; // e.g., 8 for d8, 10 for d10
    primaryAbility: Ability[];
    savingThrowProficiencies: Ability[];
    // Player can choose a certain number of skills from this list
    skillProficiencyOptions: { choose: number; from: SkillName[] };
    icon: React.FC;
}

// --- Character-Specific Data Structures ---

export interface AbilityScores {
    str: number;
    dex: number;
    con: number;
    int: number;
    wis: number;
    cha: number;
}

export interface Skill {
    name: SkillName;
    ability: Ability;
    proficient: boolean;
}

export interface Character5e {
    abilityScores: AbilityScores;
    skills: Skill[];
    savingThrows: Partial<Record<Ability, { proficient: boolean }>>;
    proficiencyBonus: number;
    armorClass: number;
    speed: number;
    hitDie: number;
    race: Dnd5eRace;
    dndClass: Dnd5eClass;
}
