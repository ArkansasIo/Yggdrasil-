
import React from 'react';
import { Ability, AbilityScores, Character5e, Dnd5eClass, Dnd5eRace, SkillName } from './dnd5e-types';

export type EquipmentSlot = 'head' | 'chest' | 'arms' | 'legs' | 'rightHand1' | 'leftHand1' | 'rightHand2' | 'leftHand2' | 'talisman1' | 'talisman2' | 'talisman3' | 'talisman4';

export interface Character extends Omit<Character5e, 'dndClass' | 'race'> {
    name: string;
    level: number;
    expansionLevel: number;
    experience: number;
    class: string; 
    raceName: string; 
    location: string;
    hp: number;
    maxHp: number;
    mp: number;
    maxMp: number;
    sp: number;
    maxSp: number;
    avatarUrl: string;
    statusEffects: string[];
    talentPoints: number;
    knownSpells: Spell[];
    inventory: (Weapon | Armor | CraftingMaterial | Consumable)[];
    equipment: Partial<Record<EquipmentSlot, Weapon | Armor>>;
    materials: Partial<Record<string, number>>;
    carryingCapacity: number;
    gold: number;
    reputation: Record<string, number>; // Faction ID -> Value
}

export interface Recipe {
    id: string;
    resultItemId: string;
    name: string;
    description: string;
    ingredients: { id: string; quantity: number }[];
    requiredLevel: number;
    xpReward: number;
}

export interface Spell {
    id: string;
    name:string;
    description: string;
    mpCost: number; 
    type: 'Sorcery' | 'Incantation' | 'Battle Art';
    iconId: string;
}

export interface GameChoice {
    text: string;
    action: string;
}

export interface Quest {
    id: string;
    title: string;
    description: string;
    type: 'Main' | 'Side' | 'Bounty' | 'Event';
    status: 'Active' | 'Completed' | 'Failed';
    objectives: {
        text: string;
        completed: boolean;
    }[];
    suggestedLevel?: number;
    rewards?: {
        experience?: number;
        items?: string[]; // item IDs
        gold?: number;
    };
}

export interface GameState {
    character: Character | null;
    narrative: string;
    imageUrl: string | null;
    choices: GameChoice[];
    history: string[];
    worldTier: number;
    questCount: number;
    act: number;
    chapter: number;
    lastSaved?: number;
    realmName: string;
    saveSlot: number;
    quests: Quest[];
    discoveredEnemies: string[];
    unlockedTalents: string[]; 
    completedAchievements: string[]; 
}

export interface CharacterUpdate {
    name?: string;
    level?: number;
    expansionLevel?: number;
    hp?: number;
    maxHp?: number;
    mp?: number;
    maxMp?: number;
    sp?: number;
    maxSp?: number;
    gold?: number;
    statusEffects?: string[];
    talentPoints?: number;
    newSpell?: Spell;
    newItems?: (Weapon | Armor | CraftingMaterial | Consumable)[];
    newMaterials?: { id: string, quantity: number }[];
    reputationUpdate?: { factionId: string, amount: number }[];
}

export interface GameUpdateResponse {
    narrative: string;
    location: {
        name: string;
        description: string;
    };
    characterUpdate: CharacterUpdate;
    progressUpdate?: {
        act?: number;
        chapter?: number;
        questCount?: number;
        newQuest?: Quest;
        updateQuest?: { id: string; status?: Quest['status']; objectiveCompletedIndex?: number; };
        newlyDiscoveredEnemy?: string;
    };
    imagePrompt: string;
    choices: GameChoice[];
}


export interface CharacterCreationData {
    name: string;
    dndClass: Dnd5eClass;
    dndRace: Dnd5eRace;
    abilityScores: AbilityScores;
    skillProficiencies: SkillName[];
}

export interface User {
    id: string;
    email: string;
}

export interface Realm {
    id: string;
    name: string;
    type: 'PvE' | 'PvP';
    population: 'Low' | 'Medium' | 'High' | 'Full';
}

export type ItemRarity = 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic';

export interface Item {
    id: string;
    name: string;
    description: string;
    iconId: string;
    rarity: ItemRarity;
    masterworkLevel?: number;
    temperedAffixes?: Affix[];
    weight?: number;
}

export interface Weapon extends Item {
    type: 'Sword' | 'Axe' | 'Dagger' | 'Bow' | 'Staff' | 'Greatsword' | 'Katana' | 'Spear';
    damage: number;
    scaling: Partial<Record<Ability, string>>;
}

export interface Armor extends Item {
    slot: 'head' | 'chest' | 'arms' | 'legs';
    defense: number;
    resistance: Partial<Record<string, number>>; 
}

export interface CraftingMaterial extends Item {
    type: 'Material';
}

export interface Consumable extends Item {
    type: 'Consumable';
    effect: {
        hp?: number;
        mp?: number;
        sp?: number;
        buff?: string;
    };
}

export interface Affix {
    id: string;
    description: string;
}

export interface SaveFile {
    slot: number;
    characterName: string;
    level: number;
    class: string;
    location: string;
    lastSaved: string;
    avatarUrl: string;
    gameState: GameState;
}

export interface PlayerProfile {
    id: string;
    email: string;
    saveFiles: SaveFile[];
}

export interface Achievement {
    id: string;
    name: string;
    description: string;
    icon: React.FC;
}

export enum EnemyType {
    Undead = 'Undead',
    Humanoid = 'Humanoid',
    Beast = 'Beast',
    Plant = 'Plant',
    Construct = 'Construct',
    Dragon = 'Dragon',
    Elemental = 'Elemental',
    Monstrosity = 'Monstrosity',
    Fiend = 'Fiend',
    Aberration = 'Aberration',
    Celestial = 'Celestial',
    Giant = 'Giant'
}

export interface EnemyEntry {
    id: string;
    name: string;
    rank: 'Minion' | 'Elite' | 'Boss' | 'Great Boss';
    type: EnemyType;
    description: string;
    locations: string[];
    stats: {
        ac: number;
        hp: string; 
        speed: string;
        str: number;
        dex: number;
        con: number;
        int: number;
        wis: number;
        cha: number;
    };
    resistances?: string;
    vulnerabilities?: string;
    immunities?: string;
    behaviors: string[]; // NEW: MMORPG behaviors like "Leashes at distance", "Aggroes on sight", "Call for help"
    actions: {
        name: string;
        description: string;
    }[];
    legendaryActions?: {
        name: string;
        description: string;
    }[];
}
