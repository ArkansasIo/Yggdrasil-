import Cookies from 'js-cookie';
import { User } from '../types';

const USER_COOKIE_KEY = 'yggdrasil_user_session';

class AuthService {
    private currentUser: User | null = null;

    constructor() {
        // Hydrate user from cookie on initial load
        const userCookie = Cookies.get(USER_COOKIE_KEY);
        if (userCookie) {
            try {
                this.currentUser = JSON.parse(userCookie);
            } catch (e) {
                console.error("Failed to parse user cookie", e);
                this.logout();
            }
        }
    }

    async login(email: string, password: string): Promise<User | null> {
        console.debug(`Attempting login for ${email}`);
        // In the future, this will make an API call to a real auth endpoint.
        // For now, we simulate a successful login for any valid email.
        if (email && password === 'password') {
            const user: User = { id: `user-${Date.now()}`, email };
            this.currentUser = user;
            // Set a cookie that expires in 1 day
            Cookies.set(USER_COOKIE_KEY, JSON.stringify(user), { expires: 1 });
            return user;
        }
        return null;
    }

    logout(): void {
        console.debug('Logging out');
        this.currentUser = null;
        Cookies.remove(USER_COOKIE_KEY);
    }

    isAuthenticated(): boolean {
        return this.currentUser !== null;
    }

    getCurrentUser(): User | null {
        return this.currentUser;
    }
}

export const authService = new AuthService();