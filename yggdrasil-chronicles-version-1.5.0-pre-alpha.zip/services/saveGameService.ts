
import { GameState, User, Realm } from '../types';
import { gameApiService } from './gameApiService';

let saveTimeout: ReturnType<typeof setTimeout> | null = null;

const notifySaveStatus = (success: boolean, message: string, isAuto: boolean) => {
    const event = new CustomEvent('yc-save-status', {
        detail: { success, message, isAuto }
    });
    window.dispatchEvent(event);
};

const performSave = async (gameState: GameState, user: User, realm: Realm, isAuto: boolean) => {
    if(!gameState || !gameState.character){
        console.warn("Save skipped: game state or character is null.");
        return;
    }
    
    try {
        const success = await gameApiService.saveGame(gameState, user, realm);
        const message = success 
            ? (isAuto ? "Fate auto-saved." : "Chronicle recorded successfully.")
            : "The ink has run dry: Realm connection failed.";
        notifySaveStatus(success, message, isAuto);
    } catch (e: any) {
        notifySaveStatus(false, `Save failed: ${e.message || 'Unknown error'}`, isAuto);
    }
};

export const saveGameService = {
  /**
   * Triggers a debounced auto-save.
   */
  autoSave(gameState: GameState, user: User, realm: Realm) {
    if (saveTimeout !== null) {
      clearTimeout(saveTimeout);
    }
    saveTimeout = setTimeout(() => {
        performSave(gameState, user, realm, true);
        saveTimeout = null;
    }, 3000);
  },

  /**
   * Immediately saves the game.
   */
  async manualSave(gameState: GameState, user: User, realm: Realm): Promise<boolean> {
     if (saveTimeout !== null) {
         clearTimeout(saveTimeout);
         saveTimeout = null;
     }
     
     try {
         const success = await gameApiService.saveGame(gameState, user, realm);
         const message = success 
            ? "Chronicle recorded successfully."
            : "The ink has run dry: Manual save rejected.";
         notifySaveStatus(success, message, false);
         return success;
     } catch (e: any) {
         notifySaveStatus(false, `Manual save failed: ${e.message || 'Network error'}`, false);
         return false;
     }
  }
};
