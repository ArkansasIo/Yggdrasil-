
import { GameState, CharacterCreationData, GameUpdateResponse, SaveFile, User, Realm } from '../types';

const API_BASE_URL = '/api';

async function fetchApi<T>(url: string, options: RequestInit = {}): Promise<T> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // Increased to 30 seconds for AI stability

    try {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            ...options,
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            const errorText = await response.text();
            console.error(`API Error: ${response.status} ${errorText}`);
            try {
              const errorJson = JSON.parse(errorText);
              throw new Error(errorJson.error || `Request failed with status ${response.status}`);
            } catch (e: any) {
               if (e.message && !e.message.includes('JSON')) throw e;
               throw new Error(errorText || `Request failed with status ${response.status}`);
            }
        }

        return await response.json();
    } catch (e: any) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') {
             throw new Error("Request timed out. The runes are slow to manifest.");
        }
        throw e;
    }
}

async function post<T>(url: string, body: object): Promise<T> {
    return fetchApi<T>(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });
}

export const gameApiService = {
    async getInitialState(gameState: GameState): Promise<GameUpdateResponse | null> {
        try {
            return await post<GameUpdateResponse>('/game/start', { gameState });
        } catch (e) {
            console.error("Error getting initial state:", e);
            return null;
        }
    },

    async getGameUpdate(gameState: GameState, playerAction: string): Promise<GameUpdateResponse | null> {
        try {
            const { history, imageUrl, ...restOfState } = gameState;
            const smallerGameState = {
                ...restOfState,
                history: history.slice(-5) 
            };
            return await post<GameUpdateResponse>('/game/update', { gameState: smallerGameState, playerAction });
        } catch (e) {
            console.error("Error getting game update:", e);
            return null;
        }
    },

    async generateImage(prompt: string): Promise<string | null> {
        try {
            if (!prompt) return null;
            const response = await post<{ imageUrl: string }>('/image/generate', { prompt });
            return response.imageUrl;
        } catch (e) {
            console.error("Error generating image:", e);
            return null;
        }
    },

    async getSaveFiles(user: User, realm: Realm): Promise<SaveFile[]> {
        try {
            return await post<SaveFile[]>('/game/saves', { email: user.email, realmName: realm.name });
        } catch (e) {
            console.error("Error fetching save files:", e);
            return [];
        }
    },

    async saveGame(gameState: GameState, user: User, realm: Realm): Promise<boolean> {
        try {
            await post('/game/save', { gameState, email: user.email, realmName: realm.name });
            return true;
        } catch(e) {
            console.error(`Error saving game to slot ${gameState.saveSlot}:`, e);
            return false;
        }
    }
};
