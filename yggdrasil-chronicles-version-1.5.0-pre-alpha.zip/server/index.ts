import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import { geminiService } from './geminiService.js';
import { db } from './db.js';

const app = express();
const port = process.env.PORT || 3001;

// Middlewares
app.use(cors());
// Increased limit to 10MB to accommodate large base64 images during character creation
app.use(express.json({ limit: '10mb' }));

// Root route
app.get('/', (req: express.Request, res: express.Response) => {
    res.send('Yggdrasil Chronicles Server is running...');
});

const apiRouter = express.Router();

// --- API Routes ---

apiRouter.get('/health', (req: express.Request, res: express.Response) => {
    res.status(200).json({ status: 'ok' });
});

apiRouter.post('/game/start', async (req: express.Request, res: express.Response) => {
    try {
        const { gameState } = req.body;
        if (!gameState || !gameState.character) {
            return res.status(400).json({ error: 'Initial gameState with character is required' });
        }
        const initialState = await geminiService.getInitialState(gameState);
        if (initialState) {
            res.json(initialState);
        } else {
            res.status(500).json({ error: 'Failed to generate initial state.' });
        }
    } catch (error) {
        console.error("Error in /api/game/start:", error);
        res.status(500).json({ error: 'An unexpected error occurred while starting the game.' });
    }
});

apiRouter.post('/game/update', async (req: express.Request, res: express.Response) => {
    try {
        const { gameState, playerAction } = req.body;
        if (!gameState || !playerAction) {
            return res.status(400).json({ error: 'gameState and playerAction are required' });
        }
        const update = await geminiService.getGameUpdate(gameState, playerAction);
        if (update) {
            res.json(update);
        } else {
            res.status(500).json({ error: 'Failed to generate game update.' });
        }
    } catch (error) {
        console.error("Error in /api/game/update:", error);
        res.status(500).json({ error: 'An unexpected error occurred while updating the game state.' });
    }
});

apiRouter.post('/image/generate', async (req: express.Request, res: express.Response) => {
    try {
        const { prompt } = req.body;
        if (!prompt) {
            return res.status(400).json({ error: 'A prompt is required for image generation.' });
        }
        const imageUrl = await geminiService.generateImage(prompt);
        if (imageUrl) {
            res.json({ imageUrl });
        } else {
            // Return a placeholder if generation fails, to avoid breaking the client UI
            res.json({ imageUrl: `https://picsum.photos/seed/${encodeURIComponent(String(prompt))}/800/400` });
        }
    } catch (error) {
        console.error("Error in /api/image/generate:", error);
        res.status(500).json({ error: 'An unexpected error occurred while generating the image.' });
    }
});

apiRouter.post('/game/saves', async(req: express.Request, res: express.Response) => {
    try {
        const { email, realmName } = req.body;
        if (!email || !realmName) {
            return res.status(400).json({ error: 'email and realmName are required.' });
        }
        const saves = await db.getAllSaves(email, realmName);
        res.json(saves);
    } catch (error) {
        console.error("Error fetching saves:", error);
        res.status(500).json({ error: 'Failed to retrieve save files.' });
    }
});

apiRouter.post('/game/save', async (req: express.Request, res: express.Response) => {
    try {
        const { gameState, email, realmName } = req.body;
        if (!gameState || !email || !realmName) {
            return res.status(400).json({ error: 'gameState, email, and realmName are required.' });
        }
        await db.saveGame(gameState, email, realmName);
        res.status(200).json({ message: 'Game saved successfully.' });
    } catch(error) {
        console.error("Error saving game:", error);
        res.status(500).json({ error: 'Failed to save game.' });
    }
});

// Mount the router
app.use('/api', apiRouter);

app.listen(port, () => {
    console.log(`Server listening on http://localhost:${port}`);
});