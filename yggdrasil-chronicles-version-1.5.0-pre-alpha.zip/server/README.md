# Yggdrasil Chronicles - Server

This directory contains the Node.js backend server for the Yggdrasil Chronicles game. It handles all communication with the Google Gemini and Imagen APIs, processes game logic, and manages game state persistence.

## Setup

1.  **Install Dependencies**: From the root directory, run `npm install`. This will install dependencies for both the client and the server thanks to npm workspaces.

2.  **Environment Variables**: Create a `.env` file in this `/server` directory by copying the example:
    ```bash
    cp .env.example .env
    ```

3.  **Add API Key**: Open the newly created `.env` file and add your Google AI API key:
    ```
    API_KEY="YOUR_GOOGLE_API_KEY_HERE"
    ```

## Running the Server

To run the server in development mode with auto-reloading (thanks to `tsx`), run the following command from the **root** project directory:

```bash
npm run dev:server
```

The server will start on the port defined in your `.env` file, or `3001` by default.

## API Endpoints

-   `POST /api/game/start`: Initializes a new game.
    -   Body: `{ characterData: CharacterCreationData }`
-   `POST /api/game/update`: Processes a player's action and returns the new game state.
    -   Body: `{ gameState: GameState, playerAction: string }`
-   `POST /api/image/generate`: Generates an image based on a prompt.
    -   Body: `{ prompt: string }`
-   `POST /api/game/save`: Saves the current game state to a slot.
    -   Body: `{ gameState: GameState, slot: number }`
-   `GET /api/game/saves`: Retrieves a list of all saved games.
