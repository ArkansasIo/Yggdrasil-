
import { GoogleGenAI } from "@google/genai";
import { GameState, GameUpdateResponse } from '../types.js';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const parseJsonResponse = (text: string): GameUpdateResponse | null => {
    let jsonStr = text.trim();
    const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[1]) {
        jsonStr = match[1].trim();
    }
    try {
        return JSON.parse(jsonStr) as GameUpdateResponse;
    } catch (e) {
        console.error("Failed to parse JSON response:", e, "Raw text:", text);
        try {
            const sanitizedJson = jsonStr.replace(/,\s*([}\]])/g, '$1');
            return JSON.parse(sanitizedJson) as GameUpdateResponse;
        } catch (e2) {
             console.error("Failed to parse sanitized JSON response:", e2);
             return null;
        }
    }
};

const getSystemInstruction = () => `
You are the Dungeon Master for "Yggdrasil Chronicles", a dark fantasy MMORPG-style text adventure.
Respond ONLY in valid JSON format.

{
  "narrative": "string (Markdown allowed)",
  "location": { "name": "string", "description": "string" },
  "characterUpdate": { 
    "hp": "number", 
    "experience": "number", 
    "gold": "number (amount to add/remove)",
    "newItems": [], 
    "newMaterials": [],
    "reputationUpdate": [{ "factionId": "string", "amount": "number" }]
  },
  "progressUpdate": { "act": "number", "chapter": "number", "newlyDiscoveredEnemy": "string" },
  "imagePrompt": "Detailed artistic prompt for high-quality dark fantasy painting",
  "choices": [{ "text": "string", "action": "string" }]
}

Factions: ashen_circle, glintstone_remnant, jotun_blooded, wild_hunt.

MMORPG & RPG Rules:
1. COMBAT: Adhere to D&D 5e logic. Use MMO terminology like "Threat", "Aggro", "Phase 2", "Adds", and "Enrage timers" in narrative.
2. MONSTER BEHAVIOR: 
   - 'Aggressive': Targets highest DPS or lowest HP.
   - 'Tactical': Focuses on 'healers', uses crowd control, or hides.
   - 'Ambush': Hidden until 'triggered' or player is vulnerable.
   - 'Cowardly': Flees to pull more 'mobs' or reset 'aggro'.
3. REWARDS: Include "Loot Rolls" (Roll for rarity) for bosses. Grant Gold and Faction Reputation based on quest importance.
4. CONSISTENCY: Maintain a grim, atmospheric Norse-inspired tone. Locations should feel interconnected.
`;

export const geminiService = {
    async getInitialState(gameState: GameState): Promise<GameUpdateResponse | null> {
        const { character } = gameState;
        if (!character) return null;

        const prompt = `Start a new adventure for ${character.name}, a ${character.raceName} ${character.class}. 
        They wake up in the Awakening Glade with no memory. Introduce a Rusted Shortsword (weapon_rusted_shortsword) 
        and a Hollow Draugr (hollow_draugr) exhibiting 'Aggressive' behavior. Mention that other 'Forsaken' players are visible in the distance.`;
        
        try {
            const response = await ai.models.generateContent({
                model: "gemini-3-flash-preview",
                contents: prompt,
                config: {
                    systemInstruction: getSystemInstruction(),
                    responseMimeType: "application/json",
                },
            });
            return parseJsonResponse(response.text);
        } catch (e) {
            console.error("Error in getInitialState:", e);
            return null;
        }
    },

    async getGameUpdate(gameState: GameState, playerAction: string): Promise<GameUpdateResponse | null> {
        const { history, imageUrl, ...restOfState } = gameState;
        const prompt = `Current State: ${JSON.stringify({ ...restOfState, history: history.slice(-3) })}
        Player Choice: "${playerAction}"
        Continue the story as an MMORPG DM. Resolve actions. Grant XP, Gold, and potential Loot or Materials. Update Faction Standing if applicable.`;
        
        try {
            const response = await ai.models.generateContent({
                model: "gemini-3-flash-preview",
                contents: prompt,
                config: {
                    systemInstruction: getSystemInstruction(),
                    responseMimeType: "application/json",
                },
            });
            return parseJsonResponse(response.text);
        } catch (e) {
            console.error("Error in getGameUpdate:", e);
            return null;
        }
    },

    async generateImage(prompt: string): Promise<string | null> {
        if (!prompt) return null;
        try {
            // Using gemini-2.5-flash-image for high-speed scene rendering
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: {
                    parts: [
                        {
                            text: `A cinematic dark fantasy oil painting of: ${prompt}`,
                        },
                    ],
                },
            });

            // Iterate candidates to find the image data
            for (const candidate of response.candidates) {
                for (const part of candidate.content.parts) {
                    if (part.inlineData) {
                        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                    }
                }
            }
            return null;
        } catch (e) {
            console.error("Error in generateImage:", e);
            return null;
        }
    }
};
