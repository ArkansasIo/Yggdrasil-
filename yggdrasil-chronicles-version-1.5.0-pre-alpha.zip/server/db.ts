
import { GameState, SaveFile } from '../types.js';
import fs from 'fs';
import path from 'path';

// Define the data directory and save file path.
// Using process.cwd() assumes the server is running from the 'server' directory 
// (via npm run dev:server) or root with correct context.
const DATA_DIR = path.resolve('data');
const DB_FILE = path.join(DATA_DIR, 'saves.json');

// Ensure the data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-memory cache of the database
let userRealmsStore: { [userAndRealmKey: string]: { [slot: number]: GameState } } = {};

// Load initial data from disk if it exists
if (fs.existsSync(DB_FILE)) {
    try {
        const data = fs.readFileSync(DB_FILE, 'utf-8');
        userRealmsStore = JSON.parse(data);
        console.log("Loaded saves from disk.");
    } catch (e) {
        console.error("Failed to load DB file:", e);
        userRealmsStore = {};
    }
}

const getRealmKey = (email: string, realmName: string) => `${email}-${realmName}`;

// Helper to persist data to disk
const persistDB = async () => {
    try {
        await fs.promises.writeFile(DB_FILE, JSON.stringify(userRealmsStore, null, 2), 'utf-8');
    } catch (e) {
        console.error("Failed to persist saves to disk:", e);
    }
};

export const db = {
  /**
   * Saves a game state to a specific slot for a user on a realm.
   */
  async saveGame(gameState: GameState, email: string, realmName: string): Promise<void> {
    const key = getRealmKey(email, realmName);
    const slot = gameState.saveSlot;

    console.log(`Saving game to key "${key}", slot ${slot}.`);
    
    if (!userRealmsStore[key]) {
      userRealmsStore[key] = {};
    }
    
    userRealmsStore[key][slot] = {
        ...gameState,
        lastSaved: new Date().getTime(),
    };

    await persistDB();
  },

  /**
   * Retrieves all saved games for a user on a realm, formatted as SaveFile objects.
   */
  async getAllSaves(email: string, realmName: string): Promise<SaveFile[]> {
    const key = getRealmKey(email, realmName);
    
    const realmSaves = userRealmsStore[key];
    if (!realmSaves) {
        return [];
    }

    return Object.values(realmSaves)
      .filter(gs => gs && gs.character) // Filter out empty or invalid states
      .map(gs => ({
        slot: gs.saveSlot,
        characterName: gs.character!.name,
        level: gs.character!.level,
        class: gs.character!.class,
        location: gs.character!.location,
        avatarUrl: gs.character!.avatarUrl,
        lastSaved: new Date(gs.lastSaved!).toISOString(),
        gameState: gs,
      }))
      .sort((a, b) => a.slot - b.slot); // Sort by slot number
  }
};
