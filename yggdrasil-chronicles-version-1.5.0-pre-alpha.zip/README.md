# Yggdrasil Chronicles: The Shattered Realms

**Yggdrasil Chronicles** is a dynamic, dark fantasy text adventure game powered by the Google Gemini API for narrative generation and Imagen 3 for atmospheric visuals. Players create a character, explore the Shattered Realms, make choices that shape their journey, and watch as the AI Dungeon Master crafts a unique story and world around them.

This project is built with a modern web stack, featuring a React frontend and a Node.js backend to handle game logic and AI integration.

## Technology Stack

-   **Frontend**: React, TypeScript, Vite, Tailwind CSS
-   **Backend**: Node.js, Express, TypeScript
-   **AI**: Google Gemini API (`gemini-2.5-flash-preview-04-17`)
-   **Image Generation**: Google Imagen 3 API (`imagen-3.0-generate-002`)

## Features

-   **Dynamic Narrative**: Gemini generates compelling story, locations, and events in real-time based on player choices.
-   **AI-Generated Imagery**: Imagen creates unique, atmospheric art for key scenes, bringing the world to life.
-   **Deep Character Customization**: Choose from multiple classes and allocate stats to define your character.
-   **Rich UI**: A clean, modern interface designed to immerse the player in the game world.
-   **Client/Server Architecture**: A robust backend handles all AI interactions, keeping the client light and responsive.
-   **Save/Load System**: Persist your progress and continue your adventure later.

## Getting Started

### Prerequisites

-   Node.js (v18 or later)
-   npm (v9 or later)
-   A Google AI API Key. You can get one from [Google AI Studio](https://aistudio.google.com/app/apikey).

### Installation & Setup

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-repo/yggdrasil-chronicles.git
    cd yggdrasil-chronicles
    ```

2.  **Install dependencies:**
    This project uses npm workspaces. Installing from the root directory will set up both the client and server.
    ```bash
    npm install
    ```

3.  **Configure Server Environment:**
    Navigate to the server directory, copy the example environment file, and add your API key.
    ```bash
    cd server
    cp .env.example .env
    ```
    Now, open `server/.env` and paste your Google AI API key.

4.  **Run the application:**
    Go back to the root directory and run the `dev` script. This will start both the backend server and the frontend Vite development server concurrently.
    ```bash
    cd ..
    npm run dev
    ```

The client will be available at `http://localhost:5173` (or another port if 5173 is busy), and the server will be running on `http://localhost:3001`.
