# Game Design Document: Yggdrasil Chronicles

## 1. Introduction

This document details the design of *Yggdrasil Chronicles: The Shattered Realms*. It serves as the primary blueprint for the development team.

## 2. Core Gameplay Loop

The gameplay is a continuous cycle of Observation, Decision, and Outcome.

1.  **Observation**: The player is presented with a scene described through narrative text and an accompanying image. They observe their character's current status (HP, effects, etc.) and location.
2.  **Decision**: The player is given 2-4 choices. These choices can be actions ("Enter the dark cave"), dialogue options ("Ask the old man about the ruins"), or strategic decisions ("Rest at the bonfire").
3.  **Outcome**: The player selects a choice. The game state and the player's action are sent to the AI Dungeon Master. The AI processes the input and generates a new scene, new stats, and new choices, thus starting the loop over.

## 3. Key Mechanics

### 3.1. Stats & Attributes

-   **Primary Stats**:
    -   **HP (Health Points)**: Character's life force. Reaches 0, the character dies.
    -   **MP (Mana Points)**: Used for casting spells and magical abilities.
    -   **SP (Stamina Points)**: Used for physical abilities, dodging, and sprinting.
-   **Core Attributes (Elden Ring inspired)**: Vigor, Mind, Endurance, Strength, Dexterity, Intelligence, Faith, Arcane. These will be implemented later to govern stat growth and ability scaling.

### 3.2. World Tier System

The game's difficulty is controlled by a World Tier, from 1 (Normal) to 9 (Ultra Nightmare). This affects:
-   Enemy toughness and intelligence in the narrative.
-   Severity of penalties for failure (e.g., HP loss on a failed action).
-   Quality of potential (but not guaranteed) narrative rewards.

### 3.3. Progression

-   **Leveling**: Players gain experience (narratively described as Runes, Echoes, etc.) from overcoming challenges. Reaching thresholds allows them to level up, increasing their attributes. The level cap is 720.
-   **Expansion Levels**: A prestige system beyond level 720 for long-term progression.
-   **Equipment**: Finding and equipping better gear is a primary progression vector.

## 4. The World

The setting is the Shattered Realms, a once-great kingdom now in ruins after a cataclysmic event shattered the World Tree, Yggdrasil. The world is fragmented, dangerous, and filled with echoes of its former glory and monstrous beings twisted by the cataclysm. It is inspired by Norse mythology and the dark, oppressive atmosphere of Souls-like games.
