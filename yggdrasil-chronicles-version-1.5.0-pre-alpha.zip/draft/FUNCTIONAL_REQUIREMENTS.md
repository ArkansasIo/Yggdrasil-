# Functional Requirements: Yggdrasil Chronicles

This document outlines the functional requirements for the game.

## 1. Core Systems

-   **FR1.1 Character Creation**:
    -   Players must be able to enter a character name.
    -   Players must be able to select from a list of predefined classes.
    -   Each class must have unique base stats (HP, MP, SP).
    -   Players must be able to allocate a set number of bonus points to their base stats.
-   **FR1.2 AI Narrative Engine**:
    -   The system must send the current game state and player action to the backend AI service.
    -   The AI service must return a JSON object containing the narrative update, character stat changes, new choices, and an image prompt.
    -   The game state must be consistently updated based on the AI's response.
-   **FR1.3 Image Generation**:
    -   The system must send the image prompt from the AI response to an image generation service.
    -   The service must return a base64-encoded image.
    -   The UI must display the generated image.
-   **FR1.4 Game Persistence**:
    -   The system must support saving the current `GameState` object.
    -   The system must support loading a `GameState` object to resume play.
    -   An auto-save feature should be implemented.

## 2. UI/UX

-   **FR2.1 Main Game Screen**:
    -   Must display the character's core stats (HP, MP, SP, Level, Name, Class).
    -   Must display the current narrative text.
    -   Must display the AI-generated scene image.
    -   Must display a list of 2-4 player choices as buttons.
-   **FR2.2 Menu System**:
    -   The UI must provide access to sub-menus for Character, Inventory, World, etc. via an accordion interface.
    -   Each sub-menu must lead to a dedicated screen for that system (e.g., Stats Page, Equipment Page).
-   **FR2.3 Title & Menus**:
    -   The application must start on a Title Screen.
    -   The Title Screen must provide options for "New Game" and "Credits".
    -   A "Game Mode" screen must provide options for "New Game" and "Load Game".

## 3. Future Systems (High-Level)

-   **FR3.1 Inventory System**: Players can acquire, view, and manage items.
-   **FR3.2 Equipment System**: Players can equip weapons and armor to modify their stats.
-   **FR3.3 Quest System**: The AI can grant and track quests with specific objectives.
-   **FR3.4 Multiplayer**: Asynchronous features like seeing other players' messages.
