# Story Bible: Yggdrasil Chronicles

## 1. The World: The Shattered Realms

In the beginning, there was only the Great Tree, Yggdrasil. Its branches touched the heavens, and its roots wove through the fabric of creation. Nine realms flourished under its boughs, connected by the Bifrost, a bridge of light and magic.

This age of prosperity ended with the **Sundering**. The nature of this cataclysm is lost to time—some blame a war between the gods, others a cosmic entity gnawing at the roots—but its effect was absolute. Yggdrasil shattered. The realms, no longer anchored, crashed and merged into a chaotic, broken landscape now known as the Shattered Realms.

## 2. Core Conflict

The player, known as a "Forsaken," awakens with no memory amidst the ruins. They are afflicted by a curse that prevents true death, reviving them at the last place of sanctuary they found. The central goal is twofold:
1.  **Uncover their identity**: Who were they before they became Forsaken?
2.  **Seek a cure for the curse**: To find a way to either restore the world or find peace in true death.

The overarching narrative, spanning 12 Acts, will follow the Forsaken's journey to the heart of the old world—the stump of Yggdrasil—to confront the source of the Sundering and decide the fate of what remains.

## 3. Key Factions & Covenants

-   **The Ashen Circle**: Custodians of the remaining Bonfires, the last vestiges of Yggdrasil's light. They guide the Forsaken, believing them to be part of a prophecy that foretells the coming of a new Age.
-   **The Jötun-blooded**: Descendants of the giants of Jötunheimr. They are massive, powerful beings who seek to reclaim the raw, chaotic magic unleashed by the Sundering and forge a new realm of ice and stone.
-   **The Glintstone Remnant**: Sorcerers who once advised the kings of old. They hoard knowledge and magical artifacts in their hidden enclaves, viewing the Sundering as an academic opportunity.
-   **The Wild Hunt**: A spectral legion that roams the darkest parts of the realms. They are neither living nor dead and serve an unknown master, hunting down Forsaken for a mysterious purpose.

## 4. The Curse

The curse of the Forsaken is both a boon and a burden. It grants immortality but slowly erodes one's memories and sanity with each "death." If a Forsaken loses their purpose, they become a Hollow—a mindless, aggressive shell of their former self. This provides the in-game explanation for the many hostile humanoids the player encounters.
