# Technical Design Document: Yggdrasil Chronicles

## 1. System Architecture

The application is architected as a single-page application (SPA) client that communicates with a dedicated backend server. This separation of concerns ensures that all AI processing and business logic are handled securely on the server, while the client remains focused on presentation and user interaction.

-   **Client (Frontend)**:
    -   Framework: React with TypeScript
    -   Bundler/Dev Server: Vite
    -   Styling: Tailwind CSS
    -   State Management: React Hooks (`useState`, `useCallback`)
    -   Responsibilities: Rendering UI, capturing user input, making API calls to the backend.

-   **Server (Backend)**:
    -   Framework: Express.js on Node.js with TypeScript
    -   Execution: `tsx` for development, compiled JS for production.
    -   Responsibilities:
        -   Serving as the API layer for the client.
        -   Handling all communication with external Google AI APIs.
        -   Managing game state logic and validation.
        -   Persisting game data (currently via a mock in-memory DB).

-   **External Services**:
    -   **Google Gemini API**: For all narrative, choice, and logic generation.
    -   **Google Imagen API**: For all visual generation.

## 2. Data Flow

### 2.1. New Game Initialization

1.  **Client**: User completes the Character Creation form. An `onComplete` callback fires with `CharacterCreationData`.
2.  **Client**: `App.tsx` calls `useGameEngine.startGame(characterData)`.
3.  **Client**: `useGameEngine` calls `gameApiService.getInitialState(characterData)`.
4.  **Client -> Server**: An HTTP POST request is sent to `/api/game/start` with the character data.
5.  **Server**: The Express route receives the request. It calls `geminiService.getInitialState()`.
6.  **Server -> Gemini**: `geminiService` constructs a detailed prompt and sends a request to the Gemini API.
7.  **Gemini -> Server**: Gemini returns a JSON `GameUpdateResponse`.
8.  **Server -> Client**: The server forwards the `GameUpdateResponse` to the client.
9.  **Client**: `gameApiService` receives the response. `useGameEngine` then processes it, applying the initial state and making subsequent calls to `/api/image/generate` for the avatar and scene images.
10. **Client**: The UI updates to the `GameplayScreen` with the new data.

### 2.2. Player Action Loop

The process is similar to initialization but uses the `/api/game/update` endpoint, sending the current `GameState` and the player's chosen `action` string.

## 3. State Management

-   **Client-Side**: The primary game state (`GameState` object) is held within the `useGameEngine` custom hook. This provides a centralized and controlled way to manage and update the state throughout the application.
-   **Server-Side**: The server is stateless with respect to individual game sessions. Each API request from the client contains all the necessary `GameState` information for the server to process the action. This simplifies scaling and removes the need for session management on the server.

## 4. Persistence

-   Game state is persisted via API calls to the `/api/game/save` endpoint.
-   The client-side `saveGameService` includes a debounce mechanism for its `autoSave` feature to prevent excessive API calls during rapid state changes.
-   The backend `db.ts` service is currently a mock in-memory store. This can be swapped out with a real database connector (e.g., Prisma, Mongoose) in the future with minimal changes to the API controller logic.
