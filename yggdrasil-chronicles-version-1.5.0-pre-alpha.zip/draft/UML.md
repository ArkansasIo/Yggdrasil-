# Yggdrasil Chronicles - UML Diagrams

This file contains UML diagrams to visualize the application's structure. They are written in Mermaid syntax.

## Component Diagram

This diagram shows the relationship between the main React components.

```mermaid
graph TD
    App --> TitleScreen
    App --> GameModeSelectionScreen
    App --> CharacterCreationScreen
    App --> LoadGameScreen
    App --> GameplayScreen
    App --> LoadingScreen
    App --> CreditsScreen

    GameplayScreen --> Header
    GameplayScreen --> CharacterSheet
    GameplayScreen --> GameView
    GameplayScreen --> Footer
    GameplayScreen --> Accordion
    
    Accordion --> SubMenuItem
    SubMenuItem --> SubMenuPage

    SubMenuPage --> StatsPage
    SubMenuPage --> EquipmentPage
    SubMenuPage --> InventoryPage
    SubMenuPage --> QuestLogPage
    
    CharacterSheet --> StatBar
```

## Sequence Diagram: Player Action

This diagram illustrates the data flow when a player makes a choice.

```mermaid
sequenceDiagram
    participant ClientUI as Player
    participant GameEngine as useGameEngine Hook
    participant APIService as gameApiService
    participant Server as Node.js/Express
    participant Gemini as Gemini API

    ClientUI->>GameEngine: handlePlayerChoice(choice)
    GameEngine->>APIService: getGameUpdate(gameState, choice.action)
    APIService->>Server: POST /api/game/update
    Server->>Gemini: generateContent(prompt)
    Gemini-->>Server: returns GameUpdateResponse
    Server-->>APIService: returns GameUpdateResponse
    APIService-->>GameEngine: returns update
    GameEngine->>GameEngine: applyUpdate(update)
    GameEngine->>APIService: generateImage(update.imagePrompt)
    APIService->>Server: POST /api/image/generate
    Server-->>APIService: returns imageUrl
    APIService-->>GameEngine: returns imageUrl
    GameEngine->>ClientUI: Update state (narrative, image, etc.)
```
