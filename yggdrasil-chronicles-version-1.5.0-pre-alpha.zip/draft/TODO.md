# Yggdrasil Chronicles - TODO List

This document tracks upcoming tasks and features.

## P1: Critical / Next Up

-   [ ] **Full Save/Load Implementation**:
    -   [ ] Add manual save slots in the UI.
    -   [ ] Replace mock DB with a persistent solution (e.g., a JSON file on disk, or a simple DB like SQLite).
-   [ ] **Refine AI Prompts**:
    -   [ ] Improve the `systemInstruction` to better handle inventory and quests.
    -   [ ] Add context for found items and active quests to the `getGameUpdate` prompt.
-   [ ] **Implement Core Systems**:
    -   [ ] Flesh out the `InventoryPage` to display actual items.
    -   [ ] Flesh out the `EquipmentPage` to allow equipping/unequipping items.
    -   [ ] Have the AI grant items and update `characterUpdate` accordingly.

## P2: High Priority Features

-   [ ] **Quest System**:
    -   [ ] AI should be able to grant quests, which are added to the `QuestLogPage`.
    -   [ ] AI should be able to recognize and complete quest objectives.
-   [ ] **Talent Tree**:
    -   [ ] Allow players to spend points to unlock nodes.
    -   [ ] Have talents provide meaningful, passive effects that are factored into the AI prompt.
-   [ ] **Combat Mechanics**:
    -   [ ] Formalize combat encounters. Maybe a separate "combat mode"?
    -   [ ] The AI should manage enemy HP and actions more explicitly.
-   [ ] **Authentication**:
    -   [ ] Implement a real authentication flow with JWTs.
    -   [ ] Associate save files with user accounts.

## P3: Medium Priority & Polish

-   [ ] **UI Enhancements**:
    -   [ ] Add toast notifications for events like "Game Saved" or "Item Found".
    -   [ ] Add animations and transitions to UI elements.
    -   [ ] Implement all placeholder pages.
-   [ ] **WebSockets for Live Features**:
    -   [ ] Implement a basic chat or live event system using the `webSocketService`.
-   [ ] **Sound Design**:
    -   [ ] Add background music and sound effects for UI interactions.

## P4: Long-Term / Wishlist

-   [ ] **Multiplayer**:
    -   [ ] Implement asynchronous multiplayer (seeing other players' ghosts, reading their messages).
    -   [ ] Implement synchronous co-op play.
-   [ ] **Procedural Map**:
    -   [ ] Generate a visual map of discovered locations.
