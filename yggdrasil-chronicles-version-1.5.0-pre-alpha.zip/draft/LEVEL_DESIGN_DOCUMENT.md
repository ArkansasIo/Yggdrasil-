# Level Design Document: Yggdrasil Chronicles

## 1. Philosophy

In a traditional game, level design involves manually creating maps, placing enemies, and scripting events. In *Yggdrasil Chronicles*, "level design" is about **prompt engineering** and establishing rules for the AI Dungeon Master to follow. Our goal is not to design specific levels, but to design a *framework* that allows the AI to generate compelling, coherent, and varied locations.

## 2. Location Generation Principles

The AI will be responsible for generating new locations based on player actions. The `systemInstruction` for the Gemini model will contain guidelines for this:

-   **Thematic Consistency**: A swamp should feel like a swamp. It should have murky water, twisted trees, and creatures appropriate for that biome. The AI will be instructed to maintain the game's overall dark fantasy tone.
-   **Connectivity**: New locations should logically connect to previous ones. A "path leading north" from a forest should lead to another part of the forest, a clearing, or a mountain pass, not a desert.
-   **Points of Interest**: The AI will be encouraged to create points of interest within a location (e.g., "a crumbling church," "a strange, glowing altar," "a hastily abandoned camp"). These serve as hooks for player choices.
-   **Verticality and Depth**: Narratively, locations should have a sense of depth. A simple cave can have a "narrow, descending passage" or a "ledge overlooking a chasm," giving the player choices that involve more than just moving on a flat plane.

## 3. Biome and Region Design

While the AI generates the specifics, we will define a high-level world map of regions and biomes to guide it. This gives the world structure.

-   **Example Region: The Weeping Fen**
    -   **High-Level Prompt**: "This is a vast, cursed swampland. The air is thick with mist, and the water is black and stagnant. Ancient, rotted trees claw at the sky. It is home to fungal creatures, giant insects, and the sorrowful spirits of a forgotten war."
    -   **Potential Locations**: The AI could generate locations like "Sunken Village," "Gnarled Mangrove," "Witch's Hovel," "Fungal Grotto."
    -   **Key Landmarks**: We can specify key landmarks in the prompt, like "The Black Obelisk at the center of the fen," to give the AI a major anchor point for the region.

## 4. Dynamic Events

Level design also includes the potential for the AI to introduce dynamic events.

-   **Weather**: The AI can decide it starts raining, affecting visibility and mood.
-   **Ambushes**: The AI can narrate an ambush based on the player's actions (e.g., "As you noisily trudge through the mud, a creature lunges from the water!").
-   **Discoveries**: A player's choice could lead to the AI revealing a hidden path or a secret item.
