
import { Weapon } from '../../types';

export const allWeapons: Weapon[] = [
    {
        id: 'weapon_moonveil',
        name: 'Moonveil',
        type: 'Katana',
        rarity: 'Legendary',
        description: 'A katana of exquisite make, found in the Caelid Wilds. Its sheath glows with a faint lunar light. Its transient moonlight is a formidable magic.',
        iconId: 'SamuraiIcon',
        damage: 120,
        scaling: { dex: 'B', int: 'B' },
        weight: 6.5
    },
    {
        id: 'weapon_dark_moon_greatsword',
        name: 'Dark Moon Greatsword',
        type: 'Greatsword',
        rarity: 'Mythic',
        description: 'A Moonlight Greatsword, bestowed upon a Carian queen by her lunar consort. It is a legendary sword, and it is said that it was waiting for its true master.',
        iconId: 'SparklesIcon',
        damage: 155,
        scaling: { str: 'C', dex: 'D', int: 'A' },
        weight: 10.0
    },
    {
        id: 'weapon_jarnbjorn',
        name: 'Jarnbjorn',
        type: 'Axe',
        rarity: 'Epic',
        description: 'A mighty battle axe of Norse legend, said to be capable of cleaving through the armor of a frost giant. It hums with ancient, earthy power.',
        iconId: 'WeaponIcon',
        damage: 140,
        scaling: { str: 'A' },
        weight: 7.0
    },
    {
        id: 'weapon_gungnir_replica',
        name: 'Gungnir Replica',
        type: 'Spear',
        rarity: 'Rare',
        description: 'A finely crafted spear, made in the image of the All-Father Odin\'s legendary weapon. It never misses its mark when thrown by a worthy hand.',
        iconId: 'WeaponIcon',
        damage: 110,
        scaling: { str: 'C', dex: 'C' },
        weight: 5.5
    },
    {
        id: 'weapon_rusted_shortsword',
        name: 'Rusted Shortsword',
        type: 'Sword',
        rarity: 'Common',
        description: 'A simple shortsword, pitted with rust and neglect. Better than nothing, but not by much.',
        iconId: 'WeaponIcon',
        damage: 55,
        scaling: { str: 'D', dex: 'D' },
        weight: 2.0
    },
    {
        id: 'weapon_thistle_bow',
        name: 'Thistle Bow',
        type: 'Bow',
        rarity: 'Uncommon',
        description: 'A longbow fashioned from the wood of a gnarled thistle tree. Its arrows fly true and carry a faint, stinging nettle effect.',
        iconId: 'WeaponIcon',
        damage: 80,
        scaling: { dex: 'C' },
        weight: 2.0
    }
];
