
import { Armor } from '../../types';

export const allArmor: Armor[] = [
    {
        id: 'armor_raging_wolf_helm',
        name: 'Raging Wolf Helm',
        slot: 'head',
        rarity: 'Epic',
        description: 'Helm of Vargram the Raging Wolf, one of the first Tarnished to be granted an audience with the Two Fingers.',
        iconId: 'ArmorIcon',
        defense: 10,
        resistance: { physical: 5, magic: 2 },
        weight: 4.0
    },
    {
        id: 'armor_raging_wolf_chest',
        name: 'Raging Wolf Armor',
        slot: 'chest',
        rarity: 'Epic',
        description: 'Armor of Vargram the Raging Wolf. The black wolf pelt symbolizes a silent promise to the hunt.',
        iconId: 'ShieldCheckIcon',
        defense: 22,
        resistance: { physical: 12, magic: 5 },
        weight: 18.0
    },
    {
        id: 'armor_einherjar_helm',
        name: 'Einherjar\'s Helm',
        slot: 'head',
        rarity: 'Legendary',
        description: 'A winged helm worn by the chosen warriors of Valhalla. It is said to echo with the songs of glorious battle.',
        iconId: 'ArmorIcon',
        defense: 12,
        resistance: { physical: 6, magic: 4 },
        weight: 5.0
    },
    {
        id: 'armor_berserker_mail',
        name: 'Berserker\'s Mail',
        slot: 'chest',
        rarity: 'Rare',
        description: 'Chainmail interwoven with bear pelts, favored by Norse warriors who enter a trance-like fury in battle.',
        iconId: 'ShieldCheckIcon',
        defense: 18,
        resistance: { physical: 10, frost: 3 },
        weight: 25.0
    },
     {
        id: 'armor_leather_trousers',
        name: 'Leather Trousers',
        slot: 'legs',
        rarity: 'Common',
        description: 'Sturdy trousers of boiled leather. Standard fare for any adventurer taking their first steps into danger.',
        iconId: 'ArmorIcon',
        defense: 8,
        resistance: { physical: 2 },
        weight: 3.0
    },
    {
        id: 'armor_sorcerers_manchettes',
        name: 'Sorcerer\'s Manchettes',
        slot: 'arms',
        rarity: 'Uncommon',
        description: 'Soft cloth gloves worn by glintstone sorcerers. They offer little protection, but are said to focus the mind.',
        iconId: 'ArmorIcon',
        defense: 3,
        resistance: { magic: 5 },
        weight: 0.5
    },
    // Nightrider Set
    {
        id: 'armor_nightrider_helm',
        name: 'Nightrider Helm',
        slot: 'head',
        rarity: 'Legendary',
        description: 'Coal-black helm worn by the Night\'s Cavalry who roam the realms on dark nights. Its surface is cold as the void.',
        iconId: 'ArmorIcon',
        defense: 12,
        resistance: { physical: 6, holy: 4 },
        weight: 5.5
    },
    {
        id: 'armor_nightrider_chest',
        name: 'Nightrider Armor',
        slot: 'chest',
        rarity: 'Legendary',
        description: 'Heavy plate armor used by the shadowy horsemen of the night. It is surprisingly silent, absorbing sound and light alike.',
        iconId: 'ShieldCheckIcon',
        defense: 28,
        resistance: { physical: 14, holy: 8 },
        weight: 22.0
    },
    {
        id: 'armor_nightrider_gauntlets',
        name: 'Nightrider Gauntlets',
        slot: 'arms',
        rarity: 'Legendary',
        description: 'Reinforced gauntlets designed for a firm grip on a heavy lance while riding through the darkness.',
        iconId: 'ArmorIcon',
        defense: 10,
        resistance: { physical: 5, holy: 3 },
        weight: 4.5
    },
    {
        id: 'armor_nightrider_greaves',
        name: 'Nightrider Greaves',
        slot: 'legs',
        rarity: 'Legendary',
        description: 'Solid black greaves that echo with the phantom gallop of a horse that is no longer there.',
        iconId: 'ArmorIcon',
        defense: 16,
        resistance: { physical: 8, holy: 5 },
        weight: 12.0
    }
];
