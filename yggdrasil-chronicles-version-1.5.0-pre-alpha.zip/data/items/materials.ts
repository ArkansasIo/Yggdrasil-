
import { CraftingMaterial } from '../../types';

export const allMaterials: CraftingMaterial[] = [
    // --- Ores & Ingots ---
    {
        id: 'mat_iron_ore',
        name: 'Iron Ore',
        type: 'Material',
        rarity: 'Common',
        description: 'Raw iron mined from the earth. Can be smelted into ingots.',
        iconId: 'MaterialIcon',
        weight: 1.0
    },
    {
        id: 'mat_iron_ingot',
        name: 'Iron Ingot',
        type: 'Material',
        rarity: 'Common',
        description: 'A standard bar of smelted iron. Essential for basic smithing.',
        iconId: 'MaterialIcon',
        weight: 1.0
    },
    {
        id: 'mat_steel_ingot',
        name: 'Steel Ingot',
        type: 'Material',
        rarity: 'Uncommon',
        description: 'An alloy of iron and carbon, stronger and more durable than iron.',
        iconId: 'MaterialIcon',
        weight: 1.0
    },
    {
        id: 'mat_mithril_ore',
        name: 'Mithril Ore',
        type: 'Material',
        rarity: 'Rare',
        description: 'A lightweight, silvery metal found deep in ancient mines.',
        iconId: 'MaterialIcon',
        weight: 0.5
    },
    {
        id: 'mat_glintstone_shard',
        name: 'Glintstone Shard',
        type: 'Material',
        rarity: 'Uncommon',
        description: 'A fragment of crystallized starlight. Pulsates with faint magic.',
        iconId: 'MaterialIcon',
        weight: 0.1
    },

    // --- Plants & Herbs ---
    {
        id: 'mat_kingsfoil',
        name: 'Kingsfoil',
        type: 'Material',
        rarity: 'Common',
        description: 'A common herb known for its healing properties. Used in restorative potions.',
        iconId: 'ConsumableIcon',
        weight: 0.1
    },
    {
        id: 'mat_grave_moss',
        name: 'Grave Moss',
        type: 'Material',
        rarity: 'Uncommon',
        description: 'Moss gathered from ancient tombstones. Used in necromantic concoctions.',
        iconId: 'ConsumableIcon',
        weight: 0.1
    },
    {
        id: 'mat_sunfire_rose',
        name: 'Sunfire Rose',
        type: 'Material',
        rarity: 'Rare',
        description: 'A flower that blooms only in intense sunlight. Its petals are warm to the touch.',
        iconId: 'ConsumableIcon',
        weight: 0.1
    },
    {
        id: 'mat_frostbloom',
        name: 'Frostbloom',
        type: 'Material',
        rarity: 'Rare',
        description: 'A pale blue flower that thrives in freezing temperatures.',
        iconId: 'ConsumableIcon',
        weight: 0.1
    },
    {
        id: 'mat_void_root',
        name: 'Void Root',
        type: 'Material',
        rarity: 'Epic',
        description: 'A writhed root corrupted by the void. It seems to absorb light around it.',
        iconId: 'MaterialIcon',
        weight: 0.5
    },

    // --- Monster Parts ---
    {
        id: 'mat_wolf_pelt',
        name: 'Wolf Pelt',
        type: 'Material',
        rarity: 'Common',
        description: 'The thick fur of a dire wolf. Used for leatherworking and warmth.',
        iconId: 'MaterialIcon',
        weight: 2.0
    },
    {
        id: 'mat_bone_dust',
        name: 'Bone Dust',
        type: 'Material',
        rarity: 'Common',
        description: 'Ground remains of skeletal warriors. Used in alchemy.',
        iconId: 'MaterialIcon',
        weight: 0.5
    },
    {
        id: 'mat_spider_silk',
        name: 'Giant Spider Silk',
        type: 'Material',
        rarity: 'Uncommon',
        description: 'Incredibly strong and sticky silk. Valuable for crafting light armor.',
        iconId: 'MaterialIcon',
        weight: 0.2
    },
    {
        id: 'mat_dragon_scale',
        name: 'Dragon Scale',
        type: 'Material',
        rarity: 'Legendary',
        description: 'A scale harder than steel, taken from a true dragon. Highly coveted.',
        iconId: 'MaterialIcon',
        weight: 3.0
    },
    {
        id: 'mat_elemental_core',
        name: 'Elemental Core',
        type: 'Material',
        rarity: 'Rare',
        description: 'The pulsating heart of an elemental entity. Hot to the touch.',
        iconId: 'MaterialIcon',
        weight: 1.5
    }
];
