import React from 'react';
import {
    WeaponIcon,
    SamuraiIcon,
    SparklesIcon,
    ArmorIcon,
    ShieldCheckIcon,
    ProphetIcon,
    AstrologerIcon,
    MaterialIcon,
    ConsumableIcon
} from '../../components/Icons';

export const itemIcons: { [key: string]: React.FC } = {
    WeaponIcon,
    SamuraiIcon,
    SparklesIcon,
    ArmorIcon,
    ShieldCheckIcon,
    ProphetIcon,
    AstrologerIcon,
    MaterialIcon,
    ConsumableIcon
};