
import { allWeapons } from './weapons';
import { allArmor } from './armor';
import { allMaterials } from './materials';
import { Weapon, Armor, CraftingMaterial } from '../../types';

export const allItems: (Weapon | Armor | CraftingMaterial)[] = [...allWeapons, ...allArmor, ...allMaterials];

const itemsById = new Map(allItems.map(item => [item.id, item]));

export const getItemById = (id: string): Weapon | Armor | CraftingMaterial | undefined => {
    return itemsById.get(id);
}

export { allWeapons, allArmor, allMaterials };
