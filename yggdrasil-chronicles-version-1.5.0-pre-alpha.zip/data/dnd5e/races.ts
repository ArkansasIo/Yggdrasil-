
import { Dnd5eRace } from '../../dnd5e-types';

export const dndRaces: Dnd5eRace[] = [
    {
        id: 'human',
        name: 'Human (Mannr)',
        description: 'Numerous and versatile, the Mannr are defined by their ambition and resilience. They are the most common sight in the Shattered Realms, their brief lives filled with struggle and purpose.',
        abilityScoreIncreases: { str: 1, dex: 1, con: 1, int: 1, wis: 1, cha: 1 },
        speed: 30,
        traits: [
            { name: 'Resourceful', description: 'You gain proficiency in one additional skill of your choice.' },
            { name: 'Determined', description: 'Once per long rest, you can reroll a failed ability check.' }
        ]
    },
    {
        id: 'elf',
        name: 'Elf (Álfr)',
        description: 'Graceful and ancient, the Álfar seem to move with an otherworldly elegance. They remember the world before the Sundering and are deeply connected to its fading magic.',
        abilityScoreIncreases: { dex: 2 },
        speed: 35,
        traits: [
            { name: 'Fey Ancestry', description: 'You have advantage on saving throws against being charmed, and magic can\'t put you to sleep.'},
            { name: 'Keen Senses', description: 'You have proficiency in the Perception skill.'},
        ]
    },
    {
        id: 'dwarf',
        name: 'Dwarf (Dvergr)',
        description: 'Stout and hardy folk from the mountainous heart of the earth. The Dvergr are master artisans and warriors, their resolve as unyielding as the stone they call home.',
        abilityScoreIncreases: { con: 2 },
        speed: 25,
        traits: [
            { name: 'Dwarven Resilience', description: 'You have advantage on saving throws against poison, and you have resistance to poison damage.'},
            { name: 'Stonecunning', description: 'You have proficiency with artisan\'s tools (smith\'s tools or mason\'s tools).'}
        ]
    },
    {
        id: 'jotunkin',
        name: 'Jötun-kin',
        description: 'Towering mortals with the blood of giants flowing through their veins. They are immensely strong and feel a deep connection to the untamed, elemental forces of the realms.',
        abilityScoreIncreases: { str: 2 },
        speed: 30,
        traits: [
            { name: 'Giant\'s Might', description: 'You count as one size larger when determining your carrying capacity and the weight you can push, drag, or lift.'},
            { name: 'Cold Resistance', description: 'You have resistance to cold damage.'}
        ]
    }
];
