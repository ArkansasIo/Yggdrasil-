
import { Dnd5eClass } from '../../dnd5e-types';
import { WarriorIcon, HeroIcon, ProphetIcon, AstrologerIcon, BanditIcon } from '../../components/Icons';

export const dndClasses: Dnd5eClass[] = [
    {
        id: 'barbarian',
        name: 'Barbarian (Berserkr)',
        description: 'A fierce warrior who can enter a battle rage. They draw power from the primal fury of the wild realms, their skin as hard as frozen earth.',
        hitDie: 12,
        primaryAbility: ['str'],
        savingThrowProficiencies: ['str', 'con'],
        skillProficiencyOptions: {
            choose: 2,
            from: ['animal_handling', 'athletics', 'intimidation', 'nature', 'perception', 'survival']
        },
        icon: HeroIcon,
    },
    {
        id: 'fighter',
        name: 'Fighter (Einherjar)',
        description: 'A master of martial combat, skilled with a variety of weapons and armor. They are the disciplined backbone of any warband, echoes of the legendary warriors of Valhalla.',
        hitDie: 10,
        primaryAbility: ['str', 'dex'],
        savingThrowProficiencies: ['str', 'con'],
        skillProficiencyOptions: {
            choose: 2,
            from: ['acrobatics', 'animal_handling', 'athletics', 'history', 'insight', 'intimidation', 'perception', 'survival']
        },
        icon: WarriorIcon,
    },
    {
        id: 'rogue',
        name: 'Rogue (Skugga)',
        description: 'A scoundrel who uses stealth and trickery to overcome obstacles and enemies. They thrive in the shadows of the crumbling world, their daggers ever ready.',
        hitDie: 8,
        primaryAbility: ['dex'],
        savingThrowProficiencies: ['dex', 'int'],
        skillProficiencyOptions: {
            choose: 4,
            from: ['acrobatics', 'athletics', 'deception', 'insight', 'intimidation', 'investigation', 'perception', 'performance', 'persuasion', 'sleight_of_hand', 'stealth']
        },
        icon: BanditIcon,
    },
    {
        id: 'cleric',
        name: 'Cleric (Völva/Gothi)',
        description: 'A priestly champion who wields divine magic in service of a higher power, be it the old gods or the fading memory of Yggdrasil itself. They are keepers of faith in a faithless age.',
        hitDie: 8,
        primaryAbility: ['wis'],
        savingThrowProficiencies: ['wis', 'cha'],
        skillProficiencyOptions: {
            choose: 2,
            from: ['history', 'insight', 'medicine', 'persuasion', 'religion']
        },
        icon: ProphetIcon,
    },
    {
        id: 'wizard',
        name: 'Wizard (Seiðr)',
        description: 'A scholarly magic-user capable of manipulating the structures of reality. They see the Sundering as a complex cosmic equation to be solved, hoarding runes and forgotten lore.',
        hitDie: 6,
        primaryAbility: ['int'],
        savingThrowProficiencies: ['int', 'wis'],
        skillProficiencyOptions: {
            choose: 2,
            from: ['arcana', 'history', 'insight', 'investigation', 'medicine', 'religion']
        },
        icon: AstrologerIcon,
    }
];
