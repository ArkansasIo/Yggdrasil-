
import { Realm } from '../../types';

export interface Zone {
    id: string;
    name: string;
    realm: string;
    levelRange: string;
    tier: number;
    description: string;
    type: 'Safe' | 'Contested' | 'Hostile';
}

const generateZones = (): Zone[] => {
    const realms = ['Midgard', 'Asgard', 'Vanaheim', 'Alfheim', 'Svartalfheim', 'Jotunheim', 'Niflheim', 'Muspelheim', 'Helheim'];
    const prefixes = ['The', 'High', 'Low', 'Dark', 'Frozen', 'Burning', 'Ancient', 'Ruined', 'Misty', 'Golden'];
    const roots = ['Forest', 'Plains', 'Mountains', 'Valley', 'Waste', 'Sanctuary', 'Citadel', 'Depths', 'Peaks', 'Shores', 'Woods', 'Hollow', 'Reach', 'Expanse'];
    
    const zones: Zone[] = [];
    let counter = 1;

    // Hand-crafted starter zones
    zones.push({ id: 'zone_001', name: 'The Awakening Glade', realm: 'Midgard', levelRange: '1-5', tier: 1, description: 'A peaceful grove where new souls arrive.', type: 'Safe' });
    zones.push({ id: 'zone_002', name: 'Ruins of First Light', realm: 'Midgard', levelRange: '3-8', tier: 1, description: 'Crumbling structures from the golden age.', type: 'Contested' });
    zones.push({ id: 'zone_003', name: 'Whispering Woods', realm: 'Midgard', levelRange: '5-12', tier: 1, description: 'A forest filled with voices of the past.', type: 'Hostile' });
    zones.push({ id: 'zone_004', name: 'Ironhold Outpost', realm: 'Midgard', levelRange: '10-15', tier: 1, description: 'A fortified settlement of survivors.', type: 'Safe' });

    // Procedurally generate the rest to reach ~70
    for (const realm of realms) {
        const countForRealm = realm === 'Midgard' ? 15 : 7; // Midgard is biggest
        for (let i = 0; i < countForRealm; i++) {
            const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
            const root = roots[Math.floor(Math.random() * roots.length)];
            const name = `${prefix} ${root} of ${realm}`;
            const baseLevel = (counter * 2) + 10;
            const maxLevel = baseLevel + 5;
            const tier = Math.min(9, Math.ceil(maxLevel / 10));

            zones.push({
                id: `zone_${100 + counter}`,
                name: name,
                realm: realm,
                levelRange: `${baseLevel}-${maxLevel}`,
                tier: tier,
                description: `A region in ${realm} challenged by the local fauna and the spreading corruption.`,
                type: Math.random() > 0.7 ? 'Hostile' : 'Contested'
            });
            counter++;
        }
    }
    return zones;
};

export const worldZones = generateZones();
