
export interface Instance {
    id: string;
    name: string;
    type: 'Dungeon' | 'Raid' | 'Trial' | 'Tower';
    minLevel: number;
    maxPlayers: number;
    description: string;
    bosses: string[];
    lootTier: string;
}

export const allInstances: Instance[] = [
    // Dungeons (5 Player)
    {
        id: 'dng_crypt',
        name: 'Crypt of the Forsaken King',
        type: 'Dungeon',
        minLevel: 10,
        maxPlayers: 5,
        description: 'Navigate the treacherous halls of the first fallen king.',
        bosses: ['Gatekeeper Xol', 'The Forsaken King'],
        lootTier: 'Uncommon'
    },
    {
        id: 'dng_spire',
        name: 'The Sunken Spire',
        type: 'Dungeon',
        minLevel: 25,
        maxPlayers: 5,
        description: 'A mage tower submerged in the swamp, filled with aquatic horrors.',
        bosses: ['Hydra Spawn', 'Archmage Vex'],
        lootTier: 'Rare'
    },
    {
        id: 'dng_quarry',
        name: 'Glintstone Quarry',
        type: 'Dungeon',
        minLevel: 40,
        maxPlayers: 5,
        description: 'A mine overrun by crystal-infused madness.',
        bosses: ['Crystal Golem', 'Mad Overseer'],
        lootTier: 'Rare'
    },
    {
        id: 'dng_forge',
        name: 'Forge of the Fire Giants',
        type: 'Dungeon',
        minLevel: 60,
        maxPlayers: 5,
        description: 'The heat here is unbearable for the unprepared.',
        bosses: ['Flame Warden', 'Surtr\'s Avatar'],
        lootTier: 'Epic'
    },
    // Raids (12-24 Player)
    {
        id: 'raid_yggdrasil',
        name: 'Roots of Yggdrasil',
        type: 'Raid',
        minLevel: 80,
        maxPlayers: 24,
        description: 'The source of the corruption gnawing at the world tree.',
        bosses: ['Nidhogg the Corrupter', 'Void Manifestation'],
        lootTier: 'Legendary'
    },
    {
        id: 'raid_valhalla',
        name: 'Siege of Valhalla',
        type: 'Raid',
        minLevel: 100,
        maxPlayers: 12,
        description: 'Reclaim the golden halls from the frost giants.',
        bosses: ['Jarl Frostbeard', 'Fenrir Unbound'],
        lootTier: 'Mythic'
    },
    // Trials (Boss Rush / Mechanics)
    {
        id: 'trial_valor',
        name: 'Trial of Valor',
        type: 'Trial',
        minLevel: 30,
        maxPlayers: 1,
        description: 'Prove your worth in single combat against spectral champions.',
        bosses: ['Champion Gundyr', 'Shieldmaiden Brynhildr'],
        lootTier: 'Rare'
    },
    {
        id: 'trial_elements',
        name: 'Trial of Elements',
        type: 'Trial',
        minLevel: 50,
        maxPlayers: 4,
        description: 'Survive waves of elemental fury.',
        bosses: ['Elemental Council'],
        lootTier: 'Epic'
    },
    // Tower
    {
        id: 'tower_infinity',
        name: 'The Infinity Tower',
        type: 'Tower',
        minLevel: 1,
        maxPlayers: 1,
        description: 'An endless ascent. How high can you climb?',
        bosses: ['Randomized'],
        lootTier: 'Scaling'
    }
];
