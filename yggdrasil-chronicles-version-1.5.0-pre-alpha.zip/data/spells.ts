
import { Spell } from '../types';

export const allSpells: Spell[] = [
    {
        id: 'spell_glintstone_pebble',
        name: 'Glintstone Pebble',
        description: 'A basic sorcery of the Raya Lucaria Academy. Fires a small magic projectile at the enemy.',
        mpCost: 7,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_carian_slicer',
        name: 'Carian Slicer',
        description: 'Conjures a magic sword to deliver a swift slashing attack. Can be cast repeatedly.',
        mpCost: 4,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_comet_azur',
        name: 'Comet Azur',
        description: 'Legendary sorcery of the primeval current. Fires a tremendous beam of starry energy.',
        mpCost: 60,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_rannis_dark_moon',
        name: 'Ranni\'s Dark Moon',
        description: 'Incarnates a cold, dark moon and launches it at foes. Dispels magic and reduces magic negation.',
        mpCost: 57,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_rock_sling',
        name: 'Rock Sling',
        description: ' summons three rocks from the earth and flings them at the target. Deals physical damage.',
        mpCost: 18,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_magic_glintblade',
        name: 'Magic Glintblade',
        description: 'Creates a sigil overhead that fires a magic blade at the enemy after a short delay.',
        mpCost: 12,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_terra_magica',
        name: 'Terra Magica',
        description: 'Draws a sigil on the ground, increasing the magic strength of those within.',
        mpCost: 20,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_urgent_heal',
        name: 'Urgent Heal',
        description: 'A swift incantation taught to confessors. Heals a small amount of HP.',
        mpCost: 16,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_lightning_spear',
        name: 'Lightning Spear',
        description: 'Conjures a bolt of lightning and throws it at the target.',
        mpCost: 28,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_flame_grant_strength',
        name: 'Flame, Grant Me Strength',
        description: 'Raises physical and fire-affinity attack power for a short time.',
        mpCost: 28,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_wrath_of_gold',
        name: 'Wrath of Gold',
        description: 'Produces a golden shockwave that knocks back enemies and deals holy damage.',
        mpCost: 40,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_golden_vow',
        name: 'Golden Vow',
        description: 'An ancient Erdtree incantation. Increases attack and defense for self and allies.',
        mpCost: 47,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_black_flame',
        name: 'Black Flame',
        description: 'Throws a ball of raging black fire that saps the foe\'s HP over time.',
        mpCost: 18,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_rotten_breath',
        name: 'Rotten Breath',
        description: 'Transforms caster into a dragon to spew scarlet rot breath across a wide area.',
        mpCost: 36,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_frenzied_burst',
        name: 'Frenzied Burst',
        description: 'Emits a concentrated blast of yellow flame of frenzy from the eyes. Long range.',
        mpCost: 24,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'ba_lions_claw',
        name: 'Lion\'s Claw',
        description: 'Somersault forwards to strike enemies with a powerful overhead smash.',
        mpCost: 20,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'ba_quickstep',
        name: 'Quickstep',
        description: 'Perform a quick dodge maneuver to avoid attacks and circle enemies.',
        mpCost: 3,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'ba_bloody_slash',
        name: 'Bloody Slash',
        description: 'Coat your weapon in your own blood to unleash a wide, tearing slash.',
        mpCost: 15,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'ba_transient_moonlight',
        name: 'Transient Moonlight',
        description: 'Sheathe the blade and unleash a wave of light with a rapid slash.',
        mpCost: 20,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'ba_hoarfrost_stomp',
        name: 'Hoarfrost Stomp',
        description: 'Stomp the ground to spread a freezing mist that erupts into jagged ice spikes.',
        mpCost: 10,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'ba_corpse_piler',
        name: 'Corpse Piler',
        description: 'Forms a blade of cursed blood to unleash a flurry of criss-cross slashes.',
        mpCost: 17,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'ba_seppuku',
        name: 'Seppuku',
        description: 'Plunge the blade into your stomach to coat it in blood, increasing attack power.',
        mpCost: 4,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'spell_crystal_torrent',
        name: 'Crystal Torrent',
        description: 'Creates a mass of crystals that fires a continuous stream of small shards.',
        mpCost: 38,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_shattering_crystal',
        name: 'Shattering Crystal',
        description: 'Creates a large mass of crystal that shatters forward, dealing heavy damage at close range.',
        mpCost: 21,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_blessings_boon',
        name: "Blessing's Boon",
        description: 'Grant a blessing to yourself and those nearby, gradually restoring HP.',
        mpCost: 30,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'spell_flame_of_frenzy',
        name: 'The Flame of Frenzy',
        description: 'Emit yellow flames of frenzy from your eyes, causing fire damage and madness buildup.',
        mpCost: 16,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'ba_storm_wall',
        name: 'Storm Wall',
        description: 'Swing your shield to create a wall of wind that deflects arrows and other projectiles.',
        mpCost: 5,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'ba_giant_hunt',
        name: 'Giant Hunt',
        description: 'Take a sudden step forward and deliver a powerful upward thrust with your weapon.',
        mpCost: 16,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'spell_night_comet',
        name: 'Night Comet',
        description: 'Fires a semi-invisible comet of night. Foes will not attempt to dodge this sorcery.',
        mpCost: 24,
        type: 'Sorcery',
        iconId: 'AstrologerIcon'
    },
    {
        id: 'spell_stone_of_gurranq',
        name: 'Stone of Gurranq',
        description: 'Throws a large boulder that deals heavy physical damage on impact.',
        mpCost: 15,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    },
    {
        id: 'ba_spinning_strikes',
        name: 'Spinning Strikes',
        description: 'Spin your weapon overhead continuously. Can follow up with normal or strong attacks.',
        mpCost: 2,
        type: 'Battle Art',
        iconId: 'WeaponIcon'
    },
    {
        id: 'spell_orders_blade',
        name: "Order's Blade",
        description: 'Enchant your right-hand weapon with holy energy, dealing bonus damage to the undead.',
        mpCost: 22,
        type: 'Incantation',
        iconId: 'ProphetIcon'
    }
];
