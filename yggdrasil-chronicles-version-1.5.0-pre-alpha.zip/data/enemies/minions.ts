
import { EnemyEntry, EnemyType } from '../../types';

export const minions: EnemyEntry[] = [
    {
        id: 'hollow_draugr',
        name: 'Hollow Draugr',
        rank: 'Minion',
        type: EnemyType.Undead,
        description: 'The animated husks of fallen warriors, their minds gone but muscle memory remaining. They shamble relentlessly towards the living, wielding rusted weapons with mindless fervor.',
        locations: ['Ruined villages', 'Ancient battlefields', 'Shallow graves'],
        stats: {
            ac: 12,
            hp: '3d8 + 3', 
            speed: '25 ft.',
            str: 14, dex: 10, con: 12, int: 4, wis: 8, cha: 5
        },
        vulnerabilities: 'Fire',
        immunities: 'Poison',
        behaviors: ['Aggressive', 'Pack Instinct', 'Mindless Pursuit'],
        actions: [
            { name: 'Rusted Longsword', description: 'Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 6 (1d8 + 2) slashing damage.' },
            { name: 'Mindless Lunge', description: 'The draugr throws itself forward. It moves up to its speed and makes one Rusted Longsword attack with advantage.' }
        ]
    },
    {
        id: 'myri_creeper',
        name: 'Mýri Creeper',
        rank: 'Minion',
        type: EnemyType.Monstrosity,
        description: 'A grotesque, insectoid creature that lurks in murky waters. It strikes from ambush with surprising speed, dragging its prey beneath the surface.',
        locations: ['The Weeping Fen', 'Stagnant Swamps'],
        stats: {
            ac: 13,
            hp: '4d6 + 4', 
            speed: '20 ft., swim 30 ft.',
            str: 12, dex: 14, con: 13, int: 2, wis: 10, cha: 3
        },
        vulnerabilities: 'Lightning, Cold',
        behaviors: ['Ambush Specialist', 'Leashes near water', 'Low Threat'],
        actions: [
            { name: 'Bite', description: 'Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) piercing damage.' },
            { name: 'Ensnare', description: 'The creeper attempts to grapple a target within 5 feet (Escape DC 12).' }
        ]
    },
    {
        id: 'clockwork_spider',
        name: 'Clockwork Spider',
        rank: 'Minion',
        type: EnemyType.Construct,
        description: 'A small, skittering automaton made of brass and ticking gears. They were once simple couriers but now defend ancient workshops with lethal efficiency.',
        locations: ['Svartálfheim Workshops', 'Ancient Citadels'],
        stats: {
            ac: 14,
            hp: '2d6 + 2', 
            speed: '30 ft., climb 30 ft.',
            str: 10, dex: 16, con: 12, int: 1, wis: 10, cha: 1
        },
        vulnerabilities: 'Thunder',
        immunities: 'Poison, Psychic',
        behaviors: ['Tactical Retreat', 'Explosive Death', 'Focuses Lowest HP'],
        actions: [
            { name: 'Needle Limb', description: 'Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 4 (1d4 + 2) piercing damage.' },
            { name: 'Self-Destruct', description: 'When the spider reaches 0 HP, it explodes. Each creature within 5 ft must make a DC 11 Dex save or take 3 (1d6) fire damage.' }
        ]
    }
];
