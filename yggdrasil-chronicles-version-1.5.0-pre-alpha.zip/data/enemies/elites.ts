import { EnemyEntry, EnemyType } from '../../types';

export const elites: EnemyEntry[] = [
    {
        id: 'glintstone_seidr',
        name: 'Glintstone Seiðr',
        rank: 'Elite',
        type: EnemyType.Humanoid,
        description: 'A rogue mage, driven mad by the whispers of their own unstable magic. They wield powerful but slow-casting sorceries, their bodies encrusted with raw glintstone.',
        locations: ['Glintstone Quarries', 'Mage Towers', 'Shattered Libraries'],
        stats: {
            ac: 12,
            hp: '9d8', 
            speed: '30 ft.',
            str: 9, dex: 14, con: 11, int: 17, wis: 12, cha: 11
        },
        resistances: 'Damage from spells',
        vulnerabilities: 'Physical (Bludgeoning/Slashing/Piercing)',
        // Fix: Added missing behaviors property
        behaviors: ['Ranged Specialist', 'Glass Cannon', 'Teleports when cornered'],
        actions: [
            { name: 'Glintstone Shard', description: 'Ranged Spell Attack: +6 to hit, range 120 ft., one target. Hit: 13 (2d10 + 3) magic damage.' },
            { name: 'Carian Phalanx', description: 'The seiðr summons three magical, floating swords. The next time a creature comes within 10 feet, the swords fly to strike it. Each sword makes a separate attack roll (+6 to hit) and deals 4 (1d8) force damage.' }
        ]
    },
    {
        id: 'einherjar_knight',
        name: 'Einherjar Knight',
        rank: 'Elite',
        type: EnemyType.Undead,
        description: 'An ancient warrior of Asgard, bound to guard a forgotten place. Their movements are deliberate, their shield impenetrable, and their attacks are imbued with a faint golden light.',
        locations: ['Tombs of Heroes', 'Valhallan Ruins'],
        stats: {
            ac: 18,
            hp: '10d8 + 20', 
            speed: '30 ft.',
            str: 18, dex: 13, con: 14, int: 11, wis: 11, cha: 15
        },
        resistances: 'Non-magical bludgeoning, piercing, and slashing damage',
        vulnerabilities: 'Necrotic, Bludgeoning (if unshielded)',
        // Fix: Added missing behaviors property
        behaviors: ['Phalanx Stance', 'Unyielding Defense', 'Shield Basher'],
        actions: [
            { name: 'Valorous Greatsword', description: 'Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 11 (2d6 + 4) slashing damage plus 4 (1d8) radiant damage.' },
            { name: 'Shield Bash', description: 'Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 6 (1d4 + 4) bludgeoning damage. If the target is a creature, it must succeed on a DC 15 Strength saving throw or be knocked prone.' }
        ]
    },
    {
        id: 'runabjorn',
        name: 'Rúnabjörn (Runebear)',
        rank: 'Elite',
        type: EnemyType.Beast,
        description: 'A colossal bear, its hide scarred with glowing, corrupted runes that pulse with furious energy. It moves with deceptive speed, tearing apart everything in its path.',
        locations: ['Deep Woods', 'Corrupted Groves'],
        stats: {
            ac: 15,
            hp: '12d10 + 36', 
            speed: '40 ft., climb 30 ft.',
            str: 20, dex: 10, con: 16, int: 3, wis: 13, cha: 7
        },
        resistances: 'Cold; Bludgeoning',
        vulnerabilities: 'Fire, Piercing',
        // Fix: Added missing behaviors property
        behaviors: ['Frenzied Charge', 'Relentless Pursuit', 'Berserker Rage'],
        actions: [
            { name: 'Multiattack', description: 'The rúnabjörn makes two attacks: one with its bite and one with its claws.' },
            { name: 'Bite', description: 'Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 9 (1d8 + 5) piercing damage.' },
            { name: 'Claws', description: 'Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 12 (2d6 + 5) slashing damage.' }
        ]
    },
    {
        id: 'void_gazer',
        name: 'Void Gazer',
        rank: 'Elite',
        type: EnemyType.Aberration,
        description: 'A floating mass of tentacles and eyes that bled into this reality through a tear in the void. Its gaze can liquefy flesh and unmake the mind.',
        locations: ['Void Zones', 'Rifts', 'Shattered Temples'],
        stats: {
            ac: 13,
            hp: '10d8 + 10',
            speed: '0 ft., fly 30 ft. (hover)',
            str: 10, dex: 14, con: 12, int: 16, wis: 15, cha: 14
        },
        resistances: 'Psychic',
        vulnerabilities: 'Radiant',
        // Fix: Added missing behaviors property
        behaviors: ['Hovering Ambush', 'Mind Control attempts', 'Phases through walls'],
        actions: [
            { name: 'Mind Blast (Recharge 5-6)', description: 'The gazer emits psychic energy in a 30-foot cone. Each creature must succeed on a DC 14 Intelligence save or take 15 (4d6 + 1) psychic damage and be stunned.' },
            { name: 'Void Eye', description: 'Ranged Spell Attack: +6 to hit, range 60 ft., one target. Hit: 10 (3d6) necrotic damage.' }
        ]
    }
];