import { EnemyEntry, EnemyType } from '../../types';

export const bosses: EnemyEntry[] = [
    {
        id: 'val_omen',
        name: 'The Val-Omen',
        rank: 'Boss',
        type: EnemyType.Fiend,
        description: 'A twisted, hunched guardian spirit that appears to test those who would trespass on sacred ground. It wields a staff of bone and casts shadowy, golden hexes.',
        locations: ['Gatefronts to sacred sites', 'Choke points on the main path'],
        stats: {
            ac: 16,
            hp: '15d10 + 45', // avg 127
            speed: '40 ft.',
            str: 18, dex: 20, con: 16, int: 14, wis: 15, cha: 17
        },
        resistances: 'Necrotic; Bludgeoning, piercing, and slashing from non-magical attacks',
        vulnerabilities: 'Radiant',
        // Fix: Added missing behaviors property
        behaviors: ['Omen Curse', 'Shadow Boxing', 'High Mobility'],
        actions: [
            { name: 'Multiattack', description: 'The Val-Omen makes two attacks with its Omen Staff.' },
            { name: 'Omen Staff', description: 'Melee Weapon Attack: +8 to hit, reach 10 ft., one target. Hit: 11 (1d12 + 4) bludgeoning damage plus 5 (1d10) necrotic damage.' },
            { name: 'Golden Daggers', description: 'The Val-Omen conjures and throws a fan of three spectral daggers. Each dagger requires a separate ranged spell attack (+7 to hit, range 60ft.) and deals 7 (1d10 + 2) force damage.' }
        ],
        legendaryActions: [
            { name: 'Reposition', description: 'The Val-Omen moves up to its speed without provoking opportunity attacks.' },
            { name: 'Omen Shout (Costs 2 Actions)', description: 'The Val-Omen lets out a horrifying shout. All creatures within 30 feet must succeed on a DC 15 Wisdom saving throw or become frightened for 1 minute.' }
        ]
    },
    {
        id: 'valkyrja_aesir_blade',
        name: 'Valkyrja, Blade of the Æsir',
        rank: 'Great Boss',
        type: EnemyType.Celestial,
        description: 'An impossibly beautiful and graceful warrior, chosen of the old gods, now afflicted by a divine curse known as Yggdrasil\'s Blight. She awaits a worthy challenger in the deepest roots of the Great Tree.',
        locations: ['The Haligtree Roots'],
        stats: {
            ac: 20,
            hp: '20d12 + 100', // avg 230
            speed: '50 ft.',
            str: 22, dex: 26, con: 20, int: 18, wis: 22, cha: 24
        },
        resistances: 'Radiant; Slashing, Piercing',
        vulnerabilities: 'Necrotic',
        immunities: 'Charmed, Frightened',
        // Fix: Added missing behaviors property
        behaviors: ['Waterfowl Dance', 'Lifesteal', 'Hyper-aggressive'],
        actions: [
            { name: 'Multiattack', description: 'The Valkyrja makes three attacks with her Prosthetic Blade.' },
            { name: 'Prosthetic Blade', description: 'Melee Weapon Attack: +12 to hit, reach 10 ft., one target. Hit: 16 (2d8 + 7) slashing damage. Each time she hits a creature, she regains 10 hit points.' },
            { name: 'Yggdrasil\'s Blight', description: 'The Valkyrja inflicts a creature she can see within 60 feet with a divine curse. The target must make a DC 19 Constitution saving throw. On a failure, the target takes 22 (4d10) poison damage and cannot regain hit points until the start of the Valkyrja\'s next turn.' }
        ],
        legendaryActions: [
            { name: 'Dash', description: 'The Valkyrja moves up to her speed.' },
            { name: 'Blade Dance (Costs 2 Actions)', description: 'The Valkyrja unleashes a flurry of strikes. Each creature within 10 feet must make a DC 20 Dexterity saving throw, taking 27 (6d8) slashing damage on a failed save, or half as much on a successful one.' },
            { name: 'Ascendant Bloom (Recharge 5-6, Costs 3 Actions)', description: 'The Valkyrja leaps into the air and crashes down, creating a massive explosion of blighted petals. Creatures within a 30-foot radius must make a DC 20 Constitution saving throw, taking 45 (10d8) poison damage and becoming blighted for 1 minute on a failed save. Half damage and no blight on a success.' }
        ]
    },
    // New World Bosses
    {
        id: 'world_boss_dragon',
        name: 'Nidhogg the Void Dragon',
        rank: 'Great Boss',
        type: EnemyType.Dragon,
        description: 'A colossal dragon gnawing at the roots of Yggdrasil, corrupted by the void. Its scales are harder than diamond, and its breath is pure entropy.',
        locations: ['Niflheim - Void Gap'],
        stats: {
             ac: 22,
             hp: '50d20 + 300', // World boss HP
             speed: 'Fly 80ft',
             str: 30, dex: 14, con: 28, int: 18, wis: 20, cha: 24
        },
        resistances: 'All except radiant',
        vulnerabilities: 'Radiant',
        immunities: 'Necrotic, Poison',
        // Fix: Added missing behaviors property
        behaviors: ['Flight Phase', 'Area Denial', 'Enrage Timer'],
        actions: [
             { name: 'Void Breath', description: 'Exhales void energy in a 90-foot cone. 20d10 necrotic damage.'}
        ]
    },
    {
        id: 'world_boss_fenrir',
        name: 'Fenrir Unbound',
        rank: 'Great Boss',
        type: EnemyType.Monstrosity,
        description: 'The wolf that swallows the sun. Broken free of his chains, he roams the realms seeking to devour the remaining gods.',
        locations: ['Random Spawn'],
        stats: {
             ac: 19,
             hp: '45d20 + 250',
             speed: '60ft',
             str: 28, dex: 18, con: 26, int: 12, wis: 16, cha: 14
        },
        vulnerabilities: 'Silver weapons, Slashing',
        // Fix: Added missing behaviors property
        behaviors: ['God Slayer', 'Pack Alpha', 'Bleed Stacking'],
        actions: [
             { name: 'World Eater', description: 'Melee Weapon Attack. +15 to hit. Hit: 4d12+10 piercing damage.'}
        ]
    }
];