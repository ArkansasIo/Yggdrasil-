
import { minions } from './minions';
import { elites } from './elites';
import { bosses } from './bosses';
import { wildlife } from './wildlife';
import { EnemyEntry } from '../../types';

export const allEnemies: EnemyEntry[] = [
    ...minions,
    ...elites,
    ...bosses,
    ...wildlife
];

const enemiesById = new Map(allEnemies.map(enemy => [enemy.id, enemy]));

export const getEnemyById = (id: string): EnemyEntry | undefined => {
    return enemiesById.get(id);
};
