import { EnemyEntry, EnemyType } from '../../types';

export const wildlife: EnemyEntry[] = [
    {
        id: 'dire_wolf',
        name: 'Dire Wolf',
        rank: 'Minion',
        type: EnemyType.Beast,
        description: 'A massive, feral wolf with eyes like burning coals. They hunt in packs and show no fear of man.',
        locations: ['Whispering Woods', 'Deep Forests', 'Snowy Tundras'],
        stats: {
            ac: 14,
            hp: '5d10 + 10', // avg 37
            speed: '50 ft.',
            str: 17, dex: 15, con: 15, int: 3, wis: 12, cha: 7
        },
        vulnerabilities: 'Fire',
        // Fix: Added missing behaviors property
        behaviors: ['Pack Tactics', 'Crippling Bite', 'Stalking'],
        actions: [
            { name: 'Bite', description: 'Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 10 (2d6 + 3) piercing damage. If the target is a creature, it must succeed on a DC 13 Strength saving throw or be knocked prone.' }
        ]
    },
    {
        id: 'corpse_flower',
        name: 'Corpse Flower',
        rank: 'Elite',
        type: EnemyType.Plant,
        description: 'A monstrous, foul-smelling plant that grows on battlefields, feeding on the decaying remains of the fallen. Its vines are strong enough to crush bone.',
        locations: ['Old Battlefields', 'Swamps', 'Graveyards'],
        stats: {
            ac: 12,
            hp: '15d10 + 45', // avg 127
            speed: '20 ft., climb 20 ft.',
            str: 14, dex: 14, con: 16, int: 6, wis: 15, cha: 3
        },
        resistances: 'Bludgeoning',
        vulnerabilities: 'Fire',
        // Fix: Added missing behaviors property
        behaviors: ['Stationary Guardian', 'Poison Cloud', 'Vineseizing'],
        actions: [
            { name: 'Tentacle', description: 'Melee Weapon Attack: +5 to hit, reach 10 ft., one target. Hit: 9 (2d6 + 2) bludgeoning damage plus 3 (1d6) poison damage.' },
            { name: 'Stench of Death', description: 'Each creature within 10 feet of the flower must make a DC 14 Constitution saving throw or be poisoned until the start of its next turn.' }
        ]
    },
    {
        id: 'magma_elemental',
        name: 'Magma Elemental',
        rank: 'Elite',
        type: EnemyType.Elemental,
        description: 'A living construct of molten rock and fire, birthed from the heart of a volcano. It burns everything it touches.',
        locations: ['Muspelheim', 'Volcanic Caverns'],
        stats: {
            ac: 13,
            hp: '12d10 + 60', // avg 126
            speed: '30 ft.',
            str: 20, dex: 8, con: 20, int: 5, wis: 10, cha: 5
        },
        resistances: 'Bludgeoning, piercing, and slashing from nonmagical attacks',
        immunities: 'Fire, Poison',
        vulnerabilities: 'Cold',
        // Fix: Added missing behaviors property
        behaviors: ['Aura of Fire', 'Lava Pools', 'Slow but Heavy'],
        actions: [
            { name: 'Multiattack', description: 'The elemental makes two slam attacks.' },
            { name: 'Slam', description: 'Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 14 (2d8 + 5) bludgeoning damage plus 7 (2d6) fire damage.' }
        ]
    },
    {
        id: 'giant_spider',
        name: 'Giant Spider',
        rank: 'Minion',
        type: EnemyType.Beast,
        description: 'A spider the size of a horse, weaving thick webs in dark forests and caves to ensnare unwary travelers.',
        locations: ['Dark Caves', 'Deep Woods'],
        stats: {
            ac: 14,
            hp: '4d10 + 4', // avg 26
            speed: '40 ft., climb 40 ft.',
            str: 14, dex: 16, con: 12, int: 2, wis: 11, cha: 4
        },
        vulnerabilities: 'Fire',
        // Fix: Added missing behaviors property
        behaviors: ['Web Trapper', 'Venomous Strike', 'Ceiling Ambusher'],
        actions: [
            { name: 'Bite', description: 'Melee Weapon Attack: +5 to hit, reach 5 ft., one creature. Hit: 7 (1d8 + 3) piercing damage, and the target must make a DC 11 Constitution saving throw, taking 9 (2d8) poison damage on a failed save, or half as much on a successful one.' },
            { name: 'Web (Recharge 5-6)', description: 'Ranged Weapon Attack: +5 to hit, range 30/60 ft., one creature. Hit: The target is restrained by webbing.' }
        ]
    },
    {
        id: 'basilisk',
        name: 'Basilisk',
        rank: 'Elite',
        type: EnemyType.Monstrosity,
        description: 'A multilegged reptilian horror whose gaze can turn living flesh into stone.',
        locations: ['Subterranean Caverns', 'Stone Ruins'],
        stats: {
            ac: 15,
            hp: '8d8 + 16', // avg 52
            speed: '20 ft.',
            str: 16, dex: 8, con: 15, int: 2, wis: 8, cha: 7
        },
        vulnerabilities: 'Thunder',
        // Fix: Added missing behaviors property
        behaviors: ['Petrifying Stare', 'Toxic Trail', 'Slow Slither'],
        actions: [
            { name: 'Bite', description: 'Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 10 (2d6 + 3) piercing damage plus 7 (2d6) poison damage.' },
            { name: 'Petrifying Gaze', description: 'If a creature starts its turn within 30 feet of the basilisk and the two of them can see each other, the basilisk can force the creature to make a DC 12 Constitution saving throw. On a failure, the creature begins to turn to stone.' }
        ]
    }
];