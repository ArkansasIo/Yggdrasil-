import React, { useState, useEffect } from 'react';
import { YggdrasilIcon } from './Icons';

const LOADING_TIPS = [
    "Consulting the Norns for your thread of fate...",
    "Whispering into the well of Mimir...",
    "Drafting the layout of the Nine Realms...",
    "Stoking the fires of Muspelheim...",
    "Carving runes onto the roots of Yggdrasil...",
    "Gathering the echoes of fallen Einherjar...",
    "Polishing the scales of Nidhogg...",
    "Waiting for Huginn and Muninn to return...",
    "The Shattered Realms are coalescing...",
    "Sharpening the blades of the Forsaken..."
];

const LoadingScreen: React.FC = () => {
    const [tipIndex, setTipIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setTipIndex((prev) => (prev + 1) % LOADING_TIPS.length);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center h-full flex-grow p-8 bg-brand-dark overflow-hidden">
            <div className="relative">
                {/* Decorative Ring */}
                <div className="absolute inset-0 scale-150 border border-brand-gold/10 rounded-full animate-[spin_10s_linear_infinite]"></div>
                <div className="absolute inset-0 scale-125 border border-brand-gold/5 rounded-full animate-[spin_15s_linear_reverse_infinite]"></div>
                
                <div className="w-32 h-32 text-brand-gold animate-pulse-logo relative z-10">
                    <YggdrasilIcon />
                </div>
            </div>

            <div className="mt-12 text-center max-w-xs">
                <p className="font-cinzel text-xl text-brand-gold tracking-widest uppercase mb-4 animate-pulse">
                    Initializing
                </p>
                
                <div className="h-12 flex items-center justify-center">
                    <p className="text-sm text-gray-400 italic font-inter tracking-wide animate-[fadeIn_0.5s_ease-out]">
                        {LOADING_TIPS[tipIndex]}
                    </p>
                </div>
            </div>

            {/* Simple progress indicator bar */}
            <div className="mt-8 w-48 h-1 bg-brand-gray rounded-full overflow-hidden">
                <div className="h-full bg-brand-gold animate-[loading_20s_ease-in-out_infinite]"></div>
            </div>

            <style>{`
                @keyframes loading {
                    0% { width: 0%; }
                    50% { width: 70%; }
                    100% { width: 100%; }
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(5px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </div>
    );
};

export default LoadingScreen;