
import React from 'react';
import { allInstances } from '../../data/world/instances';

const RaidsPage: React.FC = () => {
    const raids = allInstances.filter(i => i.type === 'Raid');

    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Raids</h3>
                <p className="text-sm text-gray-400 mt-1">Massive challenges for large groups. High coordination required.</p>
            </div>
            <div className="space-y-4">
                {raids.map(raid => (
                     <div key={raid.id} className="w-full text-left p-4 bg-brand-gray-dark border-2 border-brand-gray rounded-lg">
                        <div className="flex justify-between items-center">
                            <h4 className="font-bold text-lg text-red-400">{raid.name}</h4>
                            <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-900/50 text-red-300">
                                {raid.maxPlayers} Players
                            </span>
                        </div>
                        <p className="text-sm text-gray-400 mt-1">{raid.description}</p>
                        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                            <div className="text-gray-400">Bosses: <span className="text-white">{raid.bosses.length}</span></div>
                             <div className="text-gray-400 text-right">Min Level: <span className="text-white">{raid.minLevel}</span></div>
                        </div>
                         <button className="w-full mt-4 bg-brand-gold/10 hover:bg-brand-gold/20 text-brand-gold font-bold py-2 rounded border border-brand-gold/50 transition-colors">
                            Open Raid Finder
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default RaidsPage;
