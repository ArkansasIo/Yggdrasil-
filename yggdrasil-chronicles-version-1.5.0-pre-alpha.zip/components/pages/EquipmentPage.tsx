
import React, { useState } from 'react';
import { Character, EquipmentSlot, Item, Armor, Weapon } from '../../types';
import { itemIcons } from '../../data/items/icons';
import { EquipmentIcon, ShieldCheckIcon, SparklesIcon, WeaponIcon, SmithingIcon, MaterialIcon } from '../Icons';

interface EquipmentPageProps {
    character: Character;
    onEquipItem: (index: number) => void;
    onMasterwork: (location: { type: 'inventory', index: number } | { type: 'equipment', slot: EquipmentSlot }) => void;
}

const RarityPill: React.FC<{ rarity: Item['rarity'] }> = ({ rarity }) => {
    const rarityColors: { [key in Item['rarity']]: string } = {
        Common: 'bg-gray-500/20 text-gray-300 ring-gray-500/50',
        Uncommon: 'bg-green-500/20 text-green-300 ring-green-500/50',
        Rare: 'bg-blue-500/20 text-blue-300 ring-blue-500/50',
        Epic: 'bg-purple-500/20 text-purple-300 ring-purple-500/50',
        Legendary: 'bg-orange-500/20 text-orange-300 ring-orange-500/50',
        Mythic: 'bg-red-600/20 text-red-300 ring-red-500/50',
    };
    return (
        <span className={`absolute -top-1 -right-1 px-1.5 py-0.5 text-xs font-semibold rounded-full ${rarityColors[rarity]} ring-1`}>
            {rarity.charAt(0)}
        </span>
    );
};

const ComparisonTooltip: React.FC<{ item: Weapon | Armor; equippedItem?: Weapon | Armor }> = ({ item, equippedItem }) => {
    const isWeapon = (i: Item): i is Weapon => 'damage' in i;
    const isArmor = (i: Item): i is Armor => 'defense' in i;

    const getEffectiveDefense = (armor: Armor) => armor.defense + (armor.masterworkLevel || 0);
    
    const renderStatDiff = (label: string, current: number, equippedVal?: number) => {
        if (equippedVal === undefined) return <div className="flex justify-between"><span>{label}:</span> <span className="text-white">{current}</span></div>;
        
        const diff = current - equippedVal;
        const color = diff > 0 ? 'text-green-400' : diff < 0 ? 'text-red-400' : 'text-gray-400';
        const sign = diff > 0 ? '+' : '';

        return (
            <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">{label}:</span>
                <div className="flex space-x-2">
                    <span className="text-white">{current}</span>
                    {diff !== 0 && (
                        <span className={`${color} font-bold text-xs`}>
                            ({sign}{diff})
                        </span>
                    )}
                </div>
            </div>
        );
    };

    const getScalingRank = (rank: string) => {
        const ranks: {[key: string]: number} = { 'S': 6, 'A': 5, 'B': 4, 'C': 3, 'D': 2, 'E': 1 };
        return ranks[rank] || 0;
    }

    const renderScalingComparison = (itemScaling: Partial<Record<string, string>>, equippedScaling?: Partial<Record<string, string>>) => {
        if (!itemScaling || Object.keys(itemScaling).length === 0) return null;
        
        return (
            <div className="mt-2 pt-2 border-t border-brand-gray-light">
                <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Scaling</p>
                <div className="grid grid-cols-2 gap-1">
                    {Object.entries(itemScaling).map(([stat, rank]) => {
                        const equippedRank = equippedScaling ? equippedScaling[stat] : undefined;
                        let diffElement = null;
                        
                        if (equippedRank) {
                            const itemRankVal = getScalingRank(rank as string);
                            const equippedRankVal = getScalingRank(equippedRank);
                            
                            if (itemRankVal > equippedRankVal) {
                                diffElement = <span className="text-green-400 text-[10px] ml-1">(&#8593;{equippedRank})</span>
                            } else if (itemRankVal < equippedRankVal) {
                                diffElement = <span className="text-red-400 text-[10px] ml-1">(&#8595;{equippedRank})</span>
                            } else {
                                diffElement = <span className="text-gray-500 text-[10px] ml-1">(=)</span>
                            }
                        }

                        return (
                            <div key={stat} className="flex items-center text-xs">
                                <span className="text-gray-400 uppercase w-8">{stat.substring(0,3)}</span>
                                <span className="font-bold text-white">{rank}</span>
                                {diffElement}
                            </div>
                        );
                    })}
                </div>
            </div>
        )
    }

    return (
        <div className="hidden group-hover:block absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-64 bg-brand-dark border border-brand-gray-light rounded-lg shadow-xl z-50 p-3 pointer-events-none">
            <h5 className={`font-bold text-sm ${item.rarity === 'Legendary' || item.rarity === 'Mythic' ? 'text-brand-gold' : 'text-white'}`}>
                {item.name} {(item.masterworkLevel || 0) > 0 && `+${item.masterworkLevel}`}
            </h5>
            <p className="text-xs text-gray-500 mb-2">{item.rarity} {isWeapon(item) ? item.type : (item as Armor).slot}</p>
            
            <div className="space-y-1 border-t border-brand-gray-light pt-2">
                {equippedItem && <p className="text-xs text-gray-500 italic mb-1">Vs. {equippedItem.name} {(equippedItem.masterworkLevel || 0) > 0 && `+${equippedItem.masterworkLevel}`}</p>}
                
                {isWeapon(item) && renderStatDiff('Damage', item.damage, isWeapon(equippedItem!) ? (equippedItem as Weapon).damage : undefined)}
                {isArmor(item) && renderStatDiff('Defense', getEffectiveDefense(item), isArmor(equippedItem!) ? getEffectiveDefense(equippedItem as Armor) : undefined)}
                
                {isWeapon(item) && renderScalingComparison(item.scaling, isWeapon(equippedItem!) ? (equippedItem as Weapon).scaling : undefined)}
            </div>
            
            <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-8 border-transparent border-t-brand-gray-light"></div>
        </div>
    );
};

const getMasterworkCost = (level: number) => {
    if (level >= 10) return null;
    return (level + 1) * 2;
};

const EquippedItemSlot: React.FC<{ 
    slot: EquipmentSlot; 
    item: Weapon | Armor | undefined; 
    defaultIcon: React.ReactNode; 
    label: string;
    onClick?: (location: { type: 'equipment', slot: EquipmentSlot }) => void;
    isSmithingMode: boolean;
    materials: Partial<Record<string, number>>;
}> = ({ slot, item, defaultIcon, label, onClick, isSmithingMode, materials }) => {
    const Icon = item ? itemIcons[item.iconId] : null;

    const cost = item ? getMasterworkCost(item.masterworkLevel || 0) : null;
    const canAfford = cost !== null ? (materials['mat_iron_ingot'] || 0) >= cost : false;
    const isMaxLevel = item && (item.masterworkLevel || 0) >= 10;

    return (
        <div 
            onClick={() => {
                if (isSmithingMode && item && onClick) onClick({ type: 'equipment', slot });
            }}
            className={`flex items-center justify-between p-2 bg-brand-gray-dark rounded-md border transition-all relative overflow-hidden
                ${isSmithingMode && item 
                    ? canAfford 
                        ? 'cursor-pointer border-brand-gold hover:bg-brand-gold/10 ring-1 ring-brand-gold' 
                        : 'cursor-pointer border-red-500/50 hover:bg-red-900/10 ring-1 ring-red-500/50'
                    : 'border-brand-gray'}`}
        >
            <div className="flex items-center space-x-3 z-10">
                <div className="w-12 h-12 bg-black/20 rounded-md flex items-center justify-center text-gray-500 flex-shrink-0 relative">
                    {Icon ? <Icon /> : defaultIcon}
                    {item && <RarityPill rarity={item.rarity} />}
                </div>
                <div>
                    <p className="text-xs text-gray-400">{label}</p>
                    <div className="flex items-center space-x-1">
                        <p className="font-semibold text-white truncate">{item?.name || 'Empty'}</p>
                        {item?.masterworkLevel && item.masterworkLevel > 0 && <span className="text-xs text-brand-gold">+{item.masterworkLevel}</span>}
                    </div>
                    {item && (
                        <p className="text-xs text-gray-500 mt-0.5">
                            {'damage' in item && (
                                <>Damage: <span className="text-gray-300">{(item as Weapon).damage}</span></>
                            )}
                            {'defense' in item && (
                                <>Defense: <span className="text-gray-300">{(item as Armor).defense + ((item as Armor).masterworkLevel || 0)}</span></>
                            )}
                        </p>
                    )}
                </div>
            </div>
            
            {isSmithingMode && item && (
                 <div className="text-right flex flex-col items-end z-10 pl-4">
                    {isMaxLevel ? (
                        <span className="text-xs font-bold text-gray-500 bg-black/30 px-2 py-1 rounded">MAX LEVEL</span>
                    ) : cost !== null && (
                        <div className="flex flex-col items-end">
                            <span className="text-[9px] text-gray-400 uppercase tracking-wider mb-0.5">Upgrade Cost</span>
                            <div className={`flex items-center space-x-1.5 px-2 py-1 rounded-md bg-black/40 border ${canAfford ? 'border-brand-gold/30' : 'border-red-500/30'}`}>
                                <span className={`font-bold text-sm ${canAfford ? 'text-brand-gold' : 'text-red-500'}`}>{cost}</span>
                                <div className="w-3 h-3 text-gray-400"><MaterialIcon /></div>
                            </div>
                            {!canAfford && <span className="text-[9px] text-red-400 mt-0.5 font-semibold">Not Enough Iron</span>}
                        </div>
                    )}
                 </div>
            )}
            
            {/* Background Hint for smithing */}
            {isSmithingMode && item && !isMaxLevel && canAfford && (
                <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-brand-gold/5 to-transparent pointer-events-none"></div>
            )}
        </div>
    );
};

const InventoryItemSlot: React.FC<{ 
    item: Weapon | Armor; 
    index: number;
    onClick: (index: number) => void; 
    equippedItem?: Weapon | Armor;
    isSmithingMode: boolean;
    materials: Partial<Record<string, number>>;
}> = ({ item, index, onClick, equippedItem, isSmithingMode, materials }) => {
    const Icon = itemIcons[item.iconId];
    
    const cost = getMasterworkCost(item.masterworkLevel || 0);
    const canAfford = cost !== null ? (materials['mat_iron_ingot'] || 0) >= cost : false;
    const isMaxLevel = (item.masterworkLevel || 0) >= 10;

    return (
        <button
            onClick={() => onClick(index)}
            className={`w-16 h-16 bg-brand-gray-dark border-2 rounded-md flex items-center justify-center text-gray-500 aspect-square relative group transition-colors 
                ${isSmithingMode 
                    ? `border-brand-gold hover:bg-brand-gold/10 ring-1 ${canAfford ? 'ring-brand-gold' : 'ring-red-500 border-red-500'}`
                    : 'border-brand-gray hover:border-brand-gold hover:bg-brand-gray-light'}`}
        >
            {Icon && <Icon />}
            <RarityPill rarity={item.rarity} />
            <div className="z-50">
                 <ComparisonTooltip item={item} equippedItem={equippedItem} />
            </div>
            
            {/* Level Badge (Normal Mode) */}
            {(item.masterworkLevel || 0) > 0 && !isSmithingMode && (
                <span className="absolute bottom-0 right-1 text-[10px] font-bold text-brand-gold">
                    +{item.masterworkLevel}
                </span>
            )}

            {/* Cost Badge (Smithing Mode) */}
            {isSmithingMode && (
                <div className={`absolute bottom-0 left-0 w-full text-center py-0.5 text-[9px] font-bold z-20 
                    ${isMaxLevel 
                        ? 'bg-gray-700 text-gray-300' 
                        : canAfford 
                            ? 'bg-brand-gold text-brand-dark' 
                            : 'bg-red-900 text-white'
                    }`}
                >
                   {isMaxLevel ? 'MAX' : `${cost} Iron`}
                </div>
            )}
        </button>
    );
}

const EquipmentPage: React.FC<EquipmentPageProps> = ({ character, onEquipItem, onMasterwork }) => {
    const [isSmithingMode, setIsSmithingMode] = useState(false);

    const equipmentSlots: { slot: EquipmentSlot, label: string, icon: React.ReactNode }[] = [
        { slot: 'rightHand1', label: 'Right Hand', icon: <WeaponIcon /> },
        { slot: 'leftHand1', label: 'Left Hand', icon: <ShieldCheckIcon /> },
        { slot: 'head', label: 'Head', icon: <EquipmentIcon /> },
        { slot: 'chest', label: 'Chest', icon: <EquipmentIcon /> },
        { slot: 'arms', label: 'Arms', icon: <EquipmentIcon /> },
        { slot: 'legs', label: 'Legs', icon: <EquipmentIcon /> },
    ];

    const getEquippedItemForInventoryItem = (item: Weapon | Armor): Weapon | Armor | undefined => {
        if ('damage' in item) {
             return character.equipment.rightHand1;
        } else if ('defense' in item) {
            return character.equipment[item.slot];
        }
        return undefined;
    };
    
    return (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
            {/* Left side: Equipment */}
            <div className="lg:col-span-2 space-y-4">
                 <div>
                    <h3 className="text-xl font-cinzel text-brand-gold mb-2">Equipment</h3>
                    <div className="space-y-2">
                        {equipmentSlots.map(({ slot, label, icon }) => (
                             <EquippedItemSlot 
                                key={slot}
                                slot={slot}
                                item={character.equipment[slot]}
                                defaultIcon={icon}
                                label={label}
                                isSmithingMode={isSmithingMode}
                                onClick={onMasterwork}
                                materials={character.materials}
                             />
                        ))}
                    </div>
                </div>
                 <div>
                    <h3 className="text-xl font-cinzel text-brand-gold mb-2">Combat Stats</h3>
                    <div className="grid grid-cols-2 gap-2 text-center">
                         <div className="bg-brand-gray-dark p-2 rounded-md"><div className="text-xs text-gray-400">Armor Class</div><div className="font-bold text-white text-lg">{character.armorClass}</div></div>
                         <div className="bg-brand-gray-dark p-2 rounded-md"><div className="text-xs text-gray-400">Attack Power</div><div className="font-bold text-white text-lg">---</div></div>
                    </div>
                </div>
            </div>

            {/* Right side: Inventory */}
            <div className="lg:col-span-3">
                <div className="flex justify-between items-center mb-2">
                    <h3 className="text-xl font-cinzel text-brand-gold">Inventory</h3>
                    <button 
                        onClick={() => setIsSmithingMode(!isSmithingMode)}
                        className={`px-3 py-1 rounded text-sm font-bold flex items-center space-x-2 transition-colors ${isSmithingMode ? 'bg-brand-gold text-brand-dark' : 'bg-brand-gray border border-brand-gray-light text-gray-300'}`}
                    >
                        <SmithingIcon />
                        <span>{isSmithingMode ? 'Smithing Active' : 'Enable Smithing'}</span>
                    </button>
                </div>

                {isSmithingMode && (
                    <div className="mb-2 p-2 bg-brand-gold/10 border border-brand-gold/50 rounded text-xs text-brand-gold text-center">
                         Available: {character.materials['mat_iron_ingot'] || 0} Iron Ingots.
                    </div>
                )}

                <div className="bg-brand-gray p-3 rounded-lg min-h-[300px]">
                    {character.inventory.length > 0 ? (
                        <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-7 gap-2">
                            {character.inventory
                                .map((item, index) => {
                                    if (!('damage' in item) && !('defense' in item)) return null;
                                    return (
                                        <InventoryItemSlot 
                                            key={`${item.id}-${index}`} 
                                            index={index}
                                            item={item as Weapon | Armor} 
                                            onClick={isSmithingMode ? (idx) => onMasterwork({ type: 'inventory', index: idx }) : onEquipItem} 
                                            equippedItem={getEquippedItemForInventoryItem(item as Weapon | Armor)}
                                            isSmithingMode={isSmithingMode}
                                            materials={character.materials}
                                        />
                                    );
                                })
                                .filter(Boolean)}
                        </div>
                    ) : (
                        <div className="flex items-center justify-center h-full text-center text-gray-500">
                            Your inventory is empty.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default EquipmentPage;
