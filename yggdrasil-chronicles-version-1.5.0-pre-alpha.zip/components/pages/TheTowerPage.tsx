
import React, { useState } from 'react';
import { TowerIcon } from '../Icons';

const TheTowerPage: React.FC = () => {
    const [currentFloor, setCurrentFloor] = useState(1);
    const maxFloor = 100;

    return (
        <div className="space-y-6 text-center">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">The Infinity Tower</h3>
                <p className="text-sm text-gray-400 mt-1">Ascend the tower. Enemies grow stronger with every floor.</p>
            </div>
            
            <div className="bg-brand-gray-dark p-8 rounded-lg border-2 border-brand-gray flex flex-col items-center justify-center space-y-4">
                <div className="w-24 h-24 text-brand-gold animate-pulse">
                    <TowerIcon />
                </div>
                <div>
                    <h2 className="text-4xl font-bold text-white">FLOOR {currentFloor}</h2>
                    <p className="text-gray-400 uppercase tracking-widest text-sm">Checkpoint: Floor {Math.floor((currentFloor-1)/10)*10}</p>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="bg-brand-gray p-3 rounded text-left">
                    <h5 className="font-bold text-gray-300 text-sm">Floor Effects</h5>
                    <p className="text-xs text-red-400 mt-1">• Enemy Damage +{currentFloor * 2}%</p>
                    <p className="text-xs text-red-400">• Trap Frequency Increased</p>
                </div>
                 <div className="bg-brand-gray p-3 rounded text-left">
                    <h5 className="font-bold text-gray-300 text-sm">Potential Rewards</h5>
                    <p className="text-xs text-green-400 mt-1">• {currentFloor * 100} Gold</p>
                    <p className="text-xs text-green-400">• T{Math.ceil(currentFloor/10)} Crafting Mats</p>
                </div>
            </div>

            <button 
                onClick={() => setCurrentFloor(prev => Math.min(prev + 1, maxFloor))}
                className="w-full bg-brand-gold text-brand-dark font-bold py-4 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-colors shadow-lg shadow-brand-gold/20"
            >
                Enter Floor {currentFloor}
            </button>
        </div>
    );
};

export default TheTowerPage;
