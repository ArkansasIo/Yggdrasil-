
import React from 'react';
import { GuildIcon } from '../Icons';

const GuildRow: React.FC<{ name: string, members: number, focus: string }> = ({ name, members, focus }) => (
    <div className="flex items-center justify-between p-3 bg-brand-gray-dark border border-brand-gray rounded-lg hover:border-brand-gold transition-colors cursor-pointer">
        <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-brand-dark border-2 border-brand-gray rounded flex items-center justify-center text-gray-500">
                <GuildIcon />
            </div>
            <div>
                <h4 className="font-bold text-white">{name}</h4>
                <p className="text-xs text-gray-400">{focus}</p>
            </div>
        </div>
        <div className="text-right">
             <span className="text-sm font-bold text-white">{members} / 50</span>
             <p className="text-[10px] text-gray-500">Members</p>
        </div>
    </div>
);

const GuildsPage: React.FC = () => {
    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Guilds & Clans</h3>
                <p className="text-sm text-gray-400 mt-1">Join a community of like-minded adventurers.</p>
            </div>

            <div className="flex space-x-2">
                <input type="text" placeholder="Search Guilds..." className="flex-grow bg-brand-gray-dark border border-brand-gray rounded p-2 text-white focus:border-brand-gold outline-none" />
                <button className="bg-brand-gold text-brand-dark font-bold px-4 rounded">Search</button>
            </div>

            <div className="space-y-3">
                <h4 className="text-sm text-gray-400 uppercase tracking-wider font-bold">Recommended</h4>
                <GuildRow name="The Ashen Watch" members={34} focus="PvE / Raiding" />
                <GuildRow name="Midnight Crows" members={12} focus="PvP / Ganking" />
                <GuildRow name="Merchants of Venice" members={48} focus="Trading / Crafting" />
            </div>
            
            <div className="pt-4 border-t border-brand-gray">
                <button className="w-full py-3 bg-brand-gray hover:bg-brand-gray-light text-white font-bold rounded-lg transition-colors">
                    Create New Guild (5000 Gold)
                </button>
            </div>
        </div>
    );
};

export default GuildsPage;
