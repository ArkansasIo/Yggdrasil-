
import React from 'react';
import { Armor } from '../../types';
import { allArmor } from '../../data/items';
import { itemIcons } from '../../data/items/icons';

const RarityPill: React.FC<{ rarity: Armor['rarity'] }> = ({ rarity }) => {
    const rarityColors: { [key in Armor['rarity']]: string } = {
        Common: 'bg-gray-500/20 text-gray-300',
        Uncommon: 'bg-green-500/20 text-green-300',
        Rare: 'bg-blue-500/20 text-blue-300',
        Epic: 'bg-purple-500/20 text-purple-300',
        Legendary: 'bg-orange-500/20 text-orange-300',
        Mythic: 'bg-red-600/20 text-red-300',
    };
    return (
        <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${rarityColors[rarity]}`}>
            {rarity}
        </span>
    );
};

const ArmorCard: React.FC<{ item: Armor }> = ({ item }) => {
    const Icon = itemIcons[item.iconId] || null;
    return (
        <div className="bg-brand-gray-dark border border-brand-gray rounded-lg p-3 flex space-x-3 items-start">
            <div className="flex-shrink-0 w-12 h-12 bg-black/20 rounded-md flex items-center justify-center text-brand-gold">
                {Icon && <Icon />}
            </div>
            <div className="flex-grow">
                <div className="flex justify-between items-center">
                    <h4 className="font-bold text-white">{item.name}</h4>
                    <RarityPill rarity={item.rarity} />
                </div>
                <p className="text-xs text-gray-400 mt-1">{item.description}</p>
                
                <div className="mt-3 flex flex-col space-y-2">
                    <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-400 uppercase font-bold tracking-tighter">Defense</span>
                        <span className="font-bold text-white text-sm px-2 py-0.5 bg-brand-gray rounded border border-brand-gray-light">{item.defense}</span>
                    </div>
                    
                    {item.resistance && Object.keys(item.resistance).length > 0 && (
                        <div className="mt-1 pt-1 border-t border-brand-gray-light/10">
                            <div className="flex flex-wrap gap-x-4 gap-y-1">
                                {Object.entries(item.resistance).map(([key, value]) => (
                                    <span key={key} className="text-[11px] text-gray-400">
                                        <span className="capitalize">{key}</span>: <span className="text-brand-gold font-bold">+{value}</span>
                                    </span>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const ArmorPage: React.FC = () => {
    const armorBySlot = {
        Head: allArmor.filter(a => a.slot === 'head'),
        Chest: allArmor.filter(a => a.slot === 'chest'),
        Arms: allArmor.filter(a => a.slot === 'arms'),
        Legs: allArmor.filter(a => a.slot === 'legs'),
    };

    return (
        <div className="space-y-6">
            {(Object.keys(armorBySlot) as Array<keyof typeof armorBySlot>).map(slot => (
                armorBySlot[slot].length > 0 && (
                    <div key={slot}>
                        <h3 className="text-xl font-cinzel text-brand-gold mb-2 border-b border-brand-gold/20 pb-1">{slot}</h3>
                        <div className="space-y-3">
                            {armorBySlot[slot].map(item => <ArmorCard key={item.id} item={item} />)}
                        </div>
                    </div>
                )
            ))}
        </div>
    );
};

export default ArmorPage;
