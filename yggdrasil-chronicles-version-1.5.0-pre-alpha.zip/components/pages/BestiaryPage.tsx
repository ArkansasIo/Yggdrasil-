
import React from 'react';
import { GameState, EnemyEntry } from '../../types';
import { EnemyIcon } from '../Icons';
import { allEnemies } from '../../data/enemies';
import { getAbilityModifier } from '../../data/dnd5e/rules';
import { ABILITIES } from '../../dnd5e-types';

const StatBlock: React.FC<{ value: number, label: string }> = ({ value, label }) => (
    <div className="flex flex-col items-center">
        <span className="text-xs font-bold text-gray-400">{label.toUpperCase()}</span>
        <span className="font-bold text-white">{value} ({getAbilityModifier(value) >= 0 ? '+' : ''}{getAbilityModifier(value)})</span>
    </div>
);

const BestiaryCard: React.FC<{ entry: EnemyEntry }> = ({ entry }) => (
    <div className="p-4 bg-brand-gray-dark border border-brand-gray rounded-lg">
        <div className="flex justify-between items-start">
            <div>
                <h4 className="font-bold text-lg text-white">{entry.name}</h4>
                <div className="flex items-center space-x-2 mt-1">
                     <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-brand-gray text-gray-300 border border-brand-gray-light">
                        {entry.rank}
                    </span>
                    <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-red-900/30 text-red-300 border border-red-900/50">
                        {entry.type}
                    </span>
                </div>
            </div>
            <div className="text-right">
                <p className="text-sm font-semibold">AC <span className="text-white">{entry.stats.ac}</span></p>
                <p className="text-sm font-semibold">HP <span className="text-white">{entry.stats.hp}</span></p>
            </div>
        </div>

        <div className="my-3 border-t-2 border-brand-gold/20"></div>

        <div className="grid grid-cols-6 gap-2 text-center text-sm mb-3">
            {ABILITIES.map(ab => <StatBlock key={ab} value={entry.stats[ab]} label={ab} />)}
        </div>
        
        <p className="text-sm text-gray-300 mb-3">{entry.description}</p>
        
        {entry.resistances && <p className="text-xs"><strong className="text-gray-400">Resistances:</strong> {entry.resistances}</p>}
        {entry.vulnerabilities && <p className="text-xs"><strong className="text-gray-400">Vulnerabilities:</strong> {entry.vulnerabilities}</p>}
        {entry.immunities && <p className="text-xs"><strong className="text-gray-400">Immunities:</strong> {entry.immunities}</p>}
        
        <div className="my-3 border-t border-brand-gold/20"></div>

        <div>
            <h5 className="font-bold text-brand-gold mb-1">Actions</h5>
            <div className="space-y-2">
                {entry.actions.map(action => (
                    <p key={action.name} className="text-sm">
                        <strong className="text-white italic">{action.name}.</strong>
                        <span className="text-gray-300"> {action.description}</span>
                    </p>
                ))}
            </div>
        </div>

        {entry.legendaryActions && (
             <>
                <div className="my-3 border-t border-brand-gold/20"></div>
                <div>
                    <h5 className="font-bold text-brand-gold mb-1">Legendary Actions</h5>
                    <div className="space-y-2">
                        {entry.legendaryActions.map(action => (
                            <p key={action.name} className="text-sm">
                                <strong className="text-white italic">{action.name}.</strong>
                                <span className="text-gray-300"> {action.description}</span>
                            </p>
                        ))}
                    </div>
                </div>
            </>
        )}

    </div>
);


const BestiaryPage: React.FC<{gameState: GameState}> = ({ gameState }) => {
    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Bestiary</h3>
                <p className="text-sm text-gray-400 mt-1">A compendium of the creatures you have encountered in your travels.</p>
            </div>
            
            {gameState.discoveredEnemies.length === 0 ? (
                <div className="text-center text-gray-500 p-8 border-2 border-dashed border-brand-gray rounded-lg">
                    <EnemyIcon />
                    <p className="mt-2">No creatures discovered yet.</p>
                    <p className="text-xs">Defeat new foes to add them to your bestiary.</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {gameState.discoveredEnemies
                        .map(enemyId => allEnemies.find(e => e.id === enemyId))
                        .filter((entry): entry is EnemyEntry => !!entry)
                        .map(entry => <BestiaryCard key={entry.id} entry={entry} />)
                    }
                </div>
            )}
        </div>
    );
};

export default BestiaryPage;
