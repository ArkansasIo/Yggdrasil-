
import React from 'react';
import { GameState } from '../../types';


const StoryPage: React.FC<{gameState: GameState}> = ({ gameState }) => {
    return (
        <div className="text-center text-gray-400 p-8">
            <h3 className="text-xl font-cinzel text-brand-gold mb-4">Story Progress</h3>
            <div className="bg-brand-gray-dark p-4 rounded-lg space-y-2">
                <div className="flex justify-between"><span>Current Act:</span><span className="font-bold text-white">{gameState.act}</span></div>
                <div className="flex justify-between"><span>Current Chapter:</span><span className="font-bold text-white">{gameState.chapter}</span></div>
                <div className="flex justify-between"><span>Story Completion:</span><span className="font-bold text-white">{(((gameState.act-1)*50 + gameState.chapter) / (12*50) * 100).toFixed(2)}%</span></div>
            </div>
             <p className="mt-4">Review key story moments and character journals here.</p>
        </div>
    );
};

export default StoryPage;
