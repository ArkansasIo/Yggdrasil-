
import React, { useState, useEffect } from 'react';
import { UserIcon, ShieldCheckIcon, SparklesIcon } from '../Icons';

interface PlayerStatus {
    name: string;
    role: 'Tank' | 'Healer' | 'DPS';
    isReady: boolean;
    level: number;
}

const DungeonLobbyPage: React.FC<{ type: string }> = ({ type }) => {
    const [isSearching, setIsSearching] = useState(true);
    const [players, setPlayers] = useState<PlayerStatus[]>([]);
    const [playerReady, setPlayerReady] = useState(false);

    useEffect(() => {
        // Simulate matchmaking
        const timer = setTimeout(() => {
            setIsSearching(false);
            setPlayers([
                { name: 'You', role: 'DPS', isReady: false, level: 15 },
                { name: 'Vargram', role: 'Tank', isReady: true, level: 18 },
                { name: 'Ranni', role: 'Healer', isReady: true, level: 17 },
                { name: 'Bernahl', role: 'DPS', isReady: false, level: 14 }
            ]);
        }, 2000);
        return () => clearTimeout(timer);
    }, []);

    const toggleReady = () => {
        setPlayerReady(!playerReady);
        setPlayers(prev => prev.map(p => p.name === 'You' ? { ...p, isReady: !playerReady } : p));
    };

    if (isSearching) {
        return (
            <div className="flex flex-col items-center justify-center h-full py-20 space-y-4">
                <div className="w-12 h-12 border-4 border-brand-gray border-t-brand-gold rounded-full animate-spin"></div>
                <p className="text-brand-gold font-cinzel text-lg animate-pulse">Finding a Group for {type}...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="bg-brand-gray-dark p-4 rounded-lg border border-brand-gold/30">
                 <h3 className="text-xl font-cinzel text-brand-gold mb-1">{type}: Shadow over Midgard</h3>
                 <p className="text-sm text-gray-400">Wait for all party members to ready up before entering.</p>
            </div>

            <div className="space-y-3">
                {players.map((player, idx) => (
                    <div key={idx} className="p-3 bg-brand-gray border border-brand-gray-light rounded-lg flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-black/20 rounded-full flex items-center justify-center text-gray-400">
                                {player.role === 'Tank' ? <ShieldCheckIcon /> : player.role === 'Healer' ? <SparklesIcon /> : <UserIcon />}
                            </div>
                            <div>
                                <h4 className="font-bold text-white text-sm">{player.name} <span className="text-xs text-gray-500 ml-1">Lv {player.level}</span></h4>
                                <p className="text-[10px] text-brand-gold uppercase tracking-widest">{player.role}</p>
                            </div>
                        </div>
                        <div className="flex items-center">
                            <span className={`text-xs font-bold uppercase tracking-widest ${player.isReady ? 'text-green-500' : 'text-red-500'}`}>
                                {player.isReady ? 'Ready' : 'Waiting'}
                            </span>
                            <div className={`ml-3 w-3 h-3 rounded-full ${player.isReady ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="pt-6 border-t border-brand-gray">
                 <button 
                    onClick={toggleReady}
                    className={`w-full py-4 rounded-lg font-bold uppercase tracking-widest transition-all shadow-lg ${playerReady ? 'bg-green-600 hover:bg-green-500 text-white' : 'bg-brand-gold hover:bg-yellow-300 text-brand-dark'}`}
                 >
                    {playerReady ? 'Unready' : 'Ready Up'}
                 </button>
            </div>
        </div>
    );
};

export default DungeonLobbyPage;
