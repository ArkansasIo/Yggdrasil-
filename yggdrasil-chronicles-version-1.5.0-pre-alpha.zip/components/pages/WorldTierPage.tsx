

import React from 'react';
import { GameState } from '../../types';
import { LockClosedIcon } from '../Icons';

interface WorldTierPageProps {
    gameState: GameState;
    setGameState: (newState: Partial<GameState>) => void;
}

const worldTierNames: { [key: number]: { name: string, description: string } } = {
    1: { name: 'Normal', description: 'The intended starting experience.' },
    2: { name: 'Hard', description: 'For those who seek a greater challenge.' },
    3: { name: 'Veteran', description: 'Enemies are significantly stronger.' },
    4: { name: 'Nightmare', description: 'Only the truly prepared should venture here.' },
    5: { name: 'Torment', description: 'A hellish landscape where survival is a luxury.' },
    6: { name: 'Inferno', description: 'The world itself seeks to destroy you.' },
    7: { name: 'Apocalypse', description: 'Beyond mortal comprehension.' },
    8: { name: 'Harrowing', description: 'A realm of pure suffering.' },
    9: { name: 'Ultra Nightmare', description: 'You are not welcome here.' },
};

const WorldTierPage: React.FC<WorldTierPageProps> = ({ gameState, setGameState }) => {
    const currentTier = gameState.worldTier;
    // Example logic: unlock a new tier every 10 levels. Player starts with tier 1.
    const highestUnlockedTier = gameState.character?.level ? Math.floor((gameState.character.level - 1) / 10) + 2 : 1;

    const handleTierChange = (newTier: number) => {
        if (newTier <= highestUnlockedTier) {
            setGameState({ worldTier: newTier });
            // Here you might add a toast/notification
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold">World Tier</h3>
                <p className="text-sm text-gray-400 mt-1">Increase the World Tier to face greater challenges and earn better rewards. New tiers unlock as you level up.</p>
                <p className="text-sm text-gray-400 mt-1">Highest Unlocked Tier: <span className='font-bold text-white'>{worldTierNames[highestUnlockedTier]?.name || highestUnlockedTier}</span></p>
            </div>
            <div className="space-y-3">
                {Object.entries(worldTierNames).map(([tierStr, details]) => {
                    const tier = parseInt(tierStr);
                    const isLocked = tier > highestUnlockedTier;
                    const isSelected = tier === currentTier;

                    return (
                        <button
                            key={tier}
                            onClick={() => handleTierChange(tier)}
                            disabled={isLocked}
                            className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                                isSelected
                                    ? 'bg-brand-gold/20 border-brand-gold'
                                    : isLocked
                                    ? 'bg-brand-gray-dark border-brand-gray opacity-50 cursor-not-allowed'
                                    : 'bg-brand-gray-dark border-brand-gray hover:border-brand-gold/50'
                            }`}
                        >
                            <div className="flex justify-between items-center">
                                <h4 className="font-bold text-lg text-white">{details.name}</h4>
                                {isLocked && <div className="flex items-center space-x-1 text-xs text-red-400"><LockClosedIcon className="w-3 h-3"/><span>Locked</span></div>}
                                {isSelected && <span className="text-xs font-bold text-brand-gold">Selected</span>}
                            </div>
                            <p className="text-xs text-gray-400">{details.description}</p>
                        </button>
                    );
                })}
            </div>
        </div>
    );
};

export default WorldTierPage;
