
import React from 'react';
import { Weapon } from '../../types';
import { allWeapons } from '../../data/items';
import { itemIcons } from '../../data/items/icons';

const RarityPill: React.FC<{ rarity: Weapon['rarity'] }> = ({ rarity }) => {
    const rarityColors: { [key in Weapon['rarity']]: string } = {
        Common: 'bg-gray-500/20 text-gray-300 ring-gray-500/50',
        Uncommon: 'bg-green-500/20 text-green-300 ring-green-500/50',
        Rare: 'bg-blue-500/20 text-blue-300 ring-blue-500/50',
        Epic: 'bg-purple-500/20 text-purple-300 ring-purple-500/50',
        Legendary: 'bg-orange-500/20 text-orange-300 ring-orange-500/50',
        Mythic: 'bg-red-600/20 text-red-300 ring-red-500/50',
    };
    return (
        <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ring-1 ${rarityColors[rarity]}`}>
            {rarity}
        </span>
    );
};

const WeaponCard: React.FC<{ item: Weapon }> = ({ item }) => {
    const Icon = itemIcons[item.iconId] || null;
    return (
        <div className="bg-brand-gray-dark border border-brand-gray rounded-lg p-3 flex space-x-3 items-start group hover:border-brand-gold/50 transition-colors">
            <div className="flex-shrink-0 w-12 h-12 bg-black/20 rounded-md flex items-center justify-center text-brand-gold">
                {Icon && <Icon />}
            </div>
            <div className="flex-grow">
                <div className="flex justify-between items-start">
                    <div>
                        <h4 className="font-bold text-white leading-none">{item.name}</h4>
                        <p className="text-xs text-gray-500 mt-1">{item.type}</p>
                    </div>
                    <RarityPill rarity={item.rarity} />
                </div>
                
                <p className="text-xs text-gray-400 mt-2 line-clamp-2">{item.description}</p>
                
                <div className="mt-3 flex items-center justify-between bg-black/20 p-2 rounded">
                    <div className="flex flex-col">
                        <span className="text-[10px] text-gray-500 uppercase tracking-wider">Damage</span>
                        <span className="text-lg font-bold text-white">{item.damage}</span>
                    </div>
                    
                    <div className="flex flex-col items-end">
                         <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Scaling</span>
                         <div className="flex space-x-1">
                            {Object.entries(item.scaling).map(([stat, rank]) => (
                                <div key={stat} className="flex items-center bg-brand-gray px-1.5 py-0.5 rounded border border-brand-gray-light" title={`${stat.toUpperCase()} Scaling: ${rank}`}>
                                    <span className="text-[10px] uppercase text-gray-400 mr-1">{stat.substring(0,3)}</span>
                                    <span className={`text-xs font-bold ${typeof rank === 'string' && ['S','A','B'].includes(rank) ? 'text-brand-gold' : 'text-gray-200'}`}>{rank as React.ReactNode}</span>
                                </div>
                            ))}
                         </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const WeaponsPage: React.FC = () => {
    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold mb-2">Armory</h3>
                <div className="space-y-3">
                    {allWeapons.map(item => <WeaponCard key={item.id} item={item} />)}
                </div>
            </div>
        </div>
    );
};

export default WeaponsPage;
