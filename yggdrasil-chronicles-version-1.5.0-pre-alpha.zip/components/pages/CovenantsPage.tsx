
import React from 'react';
import { ShieldCheckIcon, SparklesIcon, HeroIcon, GlobeAltIcon } from '../Icons';

const factions = [
    { id: 'ashen_circle', name: 'The Ashen Circle', icon: GlobeAltIcon, description: 'Keepers of the bonfires and guides for the Forsaken.' },
    { id: 'glintstone_remnant', name: 'Glintstone Remnant', icon: SparklesIcon, description: 'Sorcerers hoarding knowledge from the age before the sundering.' },
    { id: 'jotun_blooded', name: 'Jötun-blooded', icon: HeroIcon, description: 'Descendants of giants who respect raw strength and frozen lands.' },
    { id: 'wild_hunt', name: 'The Wild Hunt', icon: ShieldCheckIcon, description: 'Mysterious hunters who roam the dark paths between realms.' },
];

const getRank = (value: number) => {
    if (value < 0) return 'Hostile';
    if (value < 500) return 'Neutral';
    if (value < 2000) return 'Friendly';
    if (value < 5000) return 'Honored';
    return 'Exalted';
};

const ReputationBar: React.FC<{ value: number }> = ({ value }) => {
    const normalizedValue = Math.max(0, Math.min(5000, value));
    const percent = (normalizedValue / 5000) * 100;
    
    return (
        <div className="w-full h-1.5 bg-gray-800 rounded-full mt-2 overflow-hidden border border-black/20">
            <div 
                className="h-full bg-brand-gold transition-all duration-700"
                style={{ width: `${percent}%` }}
            ></div>
        </div>
    );
};

const CovenantsPage: React.FC<{ character: any }> = ({ character }) => {
    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Factions & Covenants</h3>
                <p className="text-sm text-gray-400 mt-1">Track your influence and standing with the major powers of the Nine Realms.</p>
            </div>

            <div className="space-y-3">
                {factions.map(faction => {
                    const repValue = character.reputation[faction.id] || 0;
                    const rank = getRank(repValue);

                    return (
                        <div key={faction.id} className="p-4 bg-brand-gray-dark border border-brand-gray rounded-lg">
                            <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-black/20 rounded flex items-center justify-center text-brand-gold">
                                    <faction.icon />
                                </div>
                                <div className="flex-grow">
                                    <div className="flex justify-between items-center">
                                        <h4 className="font-bold text-white">{faction.name}</h4>
                                        <span className={`text-xs font-bold uppercase tracking-wider ${rank === 'Hostile' ? 'text-red-500' : 'text-brand-gold'}`}>{rank}</span>
                                    </div>
                                    <p className="text-[11px] text-gray-500 line-clamp-1">{faction.description}</p>
                                </div>
                            </div>
                            <ReputationBar value={repValue} />
                            <div className="flex justify-between mt-1 text-[10px] text-gray-600 font-bold uppercase tracking-widest">
                                <span>{repValue} RP</span>
                                <span>{rank === 'Exalted' ? 'Max Rank' : `${5000 - repValue} to next rank`}</span>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default CovenantsPage;
