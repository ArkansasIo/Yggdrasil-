
import React, { useState } from 'react';
import { worldZones, Zone } from '../../data/world/zones';
import { MapIcon, LockClosedIcon } from '../Icons';

const ZoneCard: React.FC<{ zone: Zone }> = ({ zone }) => (
    <div className="p-3 bg-brand-gray-dark border border-brand-gray rounded-lg flex justify-between items-center group hover:border-brand-gold transition-colors">
        <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${zone.type === 'Safe' ? 'bg-green-900/50 text-green-400' : zone.type === 'Hostile' ? 'bg-red-900/50 text-red-400' : 'bg-yellow-900/50 text-yellow-400'}`}>
                <MapIcon />
            </div>
            <div>
                <h4 className="font-bold text-white group-hover:text-brand-gold">{zone.name}</h4>
                <p className="text-xs text-gray-400">{zone.realm} • Lv {zone.levelRange}</p>
            </div>
        </div>
        <div className="text-right">
             <span className="text-xs font-bold text-brand-gray-light bg-brand-gold px-2 py-0.5 rounded">T{zone.tier}</span>
             <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-wide">{zone.type}</p>
        </div>
    </div>
);

const KnownLocationsPage: React.FC = () => {
    const [filter, setFilter] = useState('All');
    const realms = Array.from(new Set(worldZones.map(z => z.realm)));

    const filteredZones = filter === 'All' ? worldZones : worldZones.filter(z => z.realm === filter);

    return (
        <div className="space-y-4">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Known Locations</h3>
                <p className="text-sm text-gray-400 mt-1">Explore over 70 unique zones across the 9 Realms.</p>
            </div>
            
            <div className="flex space-x-2 overflow-x-auto pb-2">
                <button onClick={() => setFilter('All')} className={`px-3 py-1 text-xs font-bold rounded-full whitespace-nowrap ${filter === 'All' ? 'bg-brand-gold text-brand-dark' : 'bg-brand-gray text-gray-300'}`}>All</button>
                {realms.map(r => (
                    <button key={r} onClick={() => setFilter(r)} className={`px-3 py-1 text-xs font-bold rounded-full whitespace-nowrap ${filter === r ? 'bg-brand-gold text-brand-dark' : 'bg-brand-gray text-gray-300'}`}>{r}</button>
                ))}
            </div>

            <div className="grid grid-cols-1 gap-2 h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                {filteredZones.map(zone => (
                    <ZoneCard key={zone.id} zone={zone} />
                ))}
            </div>
        </div>
    );
};

export default KnownLocationsPage;
