
import React from 'react';
import { Recipe, CraftingMaterial } from '../../types';
import { getItemById } from '../../data/items';
import { itemIcons } from '../../data/items/icons';
import { SmithingIcon, MaterialIcon } from '../Icons';

const MOCK_RECIPES: Recipe[] = [
    {
        id: 'recipe_iron_shortsword',
        resultItemId: 'weapon_rusted_shortsword', // Re-using existing ID for demo
        name: 'Standard Iron Sword',
        description: 'A clean, well-forged blade that holds its edge.',
        ingredients: [{ id: 'mat_iron_ingot', quantity: 5 }],
        requiredLevel: 1,
        xpReward: 50
    },
    {
        id: 'recipe_berserker_mail',
        resultItemId: 'armor_leather_trousers', // Re-using existing ID for demo
        name: 'Reinforced Leggings',
        description: 'Standard leather pants reinforced with iron plating.',
        ingredients: [{ id: 'mat_iron_ingot', quantity: 3 }, { id: 'mat_wolf_pelt', quantity: 2 }],
        requiredLevel: 2,
        xpReward: 75
    }
];

interface SmithingPageProps {
    character: any;
    onCraft: (recipe: Recipe) => void;
}

const SmithingPage: React.FC<SmithingPageProps> = ({ character, onCraft }) => {
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-xl font-cinzel text-brand-gold">Smithing Anvil</h3>
                    <p className="text-sm text-gray-400 mt-1">Forge new weapons and armor using materials found in your travels.</p>
                </div>
                <div className="bg-brand-gray-dark px-3 py-2 rounded border border-brand-gray text-xs">
                    <p className="text-gray-500 uppercase tracking-tighter mb-1">Available Resources</p>
                    <div className="flex space-x-3">
                         <div className="flex items-center space-x-1">
                            <span className="text-brand-gold font-bold">{character.materials['mat_iron_ingot'] || 0}</span>
                            <span className="text-gray-400">Iron</span>
                         </div>
                         <div className="flex items-center space-x-1">
                            <span className="text-brand-gold font-bold">{character.materials['mat_wolf_pelt'] || 0}</span>
                            <span className="text-gray-400">Pelt</span>
                         </div>
                    </div>
                </div>
            </div>

            <div className="space-y-3">
                {MOCK_RECIPES.map(recipe => {
                    const resultItem = getItemById(recipe.resultItemId);
                    const canAfford = recipe.ingredients.every(ing => (character.materials[ing.id] || 0) >= ing.quantity);
                    const isLevelMet = character.level >= recipe.requiredLevel;
                    const Icon = resultItem ? itemIcons[resultItem.iconId] : SmithingIcon;

                    return (
                        <div key={recipe.id} className={`p-4 bg-brand-gray-dark border-2 rounded-lg transition-all ${canAfford && isLevelMet ? 'border-brand-gray hover:border-brand-gold' : 'border-red-900/30 opacity-60'}`}>
                            <div className="flex space-x-4">
                                <div className="w-16 h-16 bg-black/30 rounded flex items-center justify-center text-brand-gold border border-brand-gray flex-shrink-0">
                                    <Icon />
                                </div>
                                <div className="flex-grow">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h4 className="font-bold text-white text-lg">{recipe.name}</h4>
                                            <p className="text-xs text-gray-500">{recipe.description}</p>
                                        </div>
                                        <div className="text-right">
                                            <span className="text-[10px] text-brand-gold uppercase font-bold bg-brand-gold/10 px-1.5 py-0.5 rounded">Lv {recipe.requiredLevel}</span>
                                        </div>
                                    </div>
                                    
                                    <div className="mt-4 flex items-center justify-between">
                                        <div className="flex space-x-4">
                                            {recipe.ingredients.map(ing => (
                                                <div key={ing.id} className="flex items-center space-x-1.5">
                                                    <div className="w-3 h-3 text-gray-500"><MaterialIcon /></div>
                                                    <span className={`text-xs font-bold ${(character.materials[ing.id] || 0) >= ing.quantity ? 'text-gray-300' : 'text-red-500'}`}>
                                                        {(character.materials[ing.id] || 0)} / {ing.quantity}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                        
                                        <button 
                                            onClick={() => onCraft(recipe)}
                                            disabled={!canAfford || !isLevelMet}
                                            className={`px-4 py-1.5 rounded font-bold text-xs uppercase transition-all ${canAfford && isLevelMet ? 'bg-brand-gold text-brand-dark hover:bg-yellow-300' : 'bg-gray-700 text-gray-500 cursor-not-allowed'}`}
                                        >
                                            {canAfford ? 'Forge Item' : 'Missing Mats'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default SmithingPage;
