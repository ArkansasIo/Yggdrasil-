
import React, { useState } from 'react';
import { StoreBattlePassPage } from './StoreBattlePassPage';
import { StoreCurrencyPage } from './StoreCurrencyPage';
import { StoreExpansionsPage } from './StoreExpansionsPage';
import { StoreSeasonPassPage } from './StoreSeasonPassPage';


const StoreNav: React.FC<{ activeTab: string, setActiveTab: (tab: string) => void }> = ({ activeTab, setActiveTab }) => {
    const tabs = ['Featured', 'Expansions', 'Season Pass', 'Battle Pass', 'Currency'];
    return (
        <div className="flex space-x-1 bg-brand-gray-dark p-1 rounded-lg mb-4 overflow-x-auto">
            {tabs.map(tab => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-shrink-0 py-2 px-3 text-sm font-bold rounded-md transition-colors ${activeTab === tab ? 'bg-brand-gold text-brand-dark' : 'text-gray-300 hover:bg-brand-gray'}`}
                >
                    {tab}
                </button>
            ))}
        </div>
    )
};

const FeaturedItem: React.FC<{ title: string; price: string; imageUrl: string; tag?: string }> = ({ title, price, imageUrl, tag }) => (
    <div className="bg-brand-gray-dark rounded-lg overflow-hidden border border-brand-gray relative group">
        {tag && <div className="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">{tag}</div>}
        <img src={imageUrl} alt={title} className="w-full h-32 object-cover" />
        <div className="p-3">
            <h4 className="font-bold text-white group-hover:text-brand-gold transition-colors">{title}</h4>
            <p className="text-sm text-gray-400">{price}</p>
        </div>
    </div>
);


const StoreFeaturedContent: React.FC = () => (
    <div className="space-y-6">
        <div>
            <h3 className="text-xl font-cinzel text-brand-gold mb-2">Featured Items</h3>
            <div className="grid grid-cols-2 gap-4">
                <FeaturedItem title="Starter Pack" price="$4.99" imageUrl="https://picsum.photos/seed/store1/400/200" tag="Best Value" />
                <FeaturedItem title="Ashen Wolf Armor Set" price="1200 Gold" imageUrl="https://picsum.photos/seed/store2/400/200" />
                <FeaturedItem title="Mount: Shadowmane" price="1500 Gold" imageUrl="https://picsum.photos/seed/store3/400/200" />
                <FeaturedItem title="Weapon Skin: Moonlight" price="800 Gold" imageUrl="https://picsum.photos/seed/store4/400/200" />
            </div>
        </div>
    </div>
);

const StoreFeaturedPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState('Featured');

    const renderContent = () => {
        switch (activeTab) {
            case 'Expansions':
                return <StoreExpansionsPage />;
            case 'Season Pass':
                return <StoreSeasonPassPage />;
            case 'Battle Pass':
                return <StoreBattlePassPage />;
            case 'Currency':
                return <StoreCurrencyPage />;
            case 'Featured':
            default:
                return <StoreFeaturedContent />;
        }
    };

    return (
        <div className="space-y-4">
            <StoreNav activeTab={activeTab} setActiveTab={setActiveTab} />
            {renderContent()}
        </div>
    );
};

export default StoreFeaturedPage;
