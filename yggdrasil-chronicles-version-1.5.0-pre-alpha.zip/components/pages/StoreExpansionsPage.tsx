
import React from 'react';

const PlaceholderContent: React.FC<{title: string}> = ({ title }) => (
    <div className="text-center text-gray-400 p-8">
        <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
        <p>This feature is currently under development.</p>
        <p>Full functionality for {title} will be available in a future update.</p>
    </div>
);


export const StoreExpansionsPage: React.FC = () => {
    return <PlaceholderContent title="Expansions" />;
};
