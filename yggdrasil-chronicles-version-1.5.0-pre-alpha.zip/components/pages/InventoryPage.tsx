
import React, { useMemo } from 'react';
import { Character, Item } from '../../types';
import { getItemById } from '../../data/items';
import { itemIcons } from '../../data/items/icons';

interface InventoryPageProps {
    character: Character;
}

const InventorySlot: React.FC<{ item?: Item, count?: number }> = ({ item, count }) => {
    const Icon = item ? itemIcons[item.iconId] : null;
    const rarityColors: { [key: string]: string } = {
        Common: 'border-brand-gray',
        Uncommon: 'border-green-500',
        Rare: 'border-blue-500',
        Epic: 'border-purple-500',
        Legendary: 'border-orange-500',
        Mythic: 'border-red-600',
    };
    
    const borderColor = item ? rarityColors[item.rarity] || 'border-brand-gray' : 'border-brand-gray';

    return (
        <div className={`w-16 h-16 bg-brand-gray-dark border-2 ${borderColor} rounded-md flex items-center justify-center text-gray-600 aspect-square relative group hover:bg-brand-gray transition-colors`}>
            {Icon && <div className={item?.rarity === 'Legendary' || item?.rarity === 'Mythic' ? 'text-brand-gold' : 'text-gray-400'}><Icon /></div>}
            {count && count > 1 && <span className="absolute bottom-1 right-1 text-xs text-white bg-black/70 px-1 rounded">{count}</span>}
            
            {item && (
                <div className="hidden group-hover:block absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 bg-black/90 border border-brand-gray-light rounded p-2 z-50 pointer-events-none">
                    <p className="font-bold text-white text-sm">{item.name}</p>
                    <p className="text-xs text-gray-400">{item.rarity} {item.weight?.toFixed(1) || '0.0'} lbs</p>
                    <p className="text-xs text-gray-500 mt-1 line-clamp-2">{item.description}</p>
                </div>
            )}
        </div>
    );
};

const InventoryPage: React.FC<InventoryPageProps> = ({ character }) => {
    const totalWeight = useMemo(() => {
        const getWeight = (item: Item) => item.weight || 0;
        const inventoryWeight = character.inventory.reduce((sum: number, item) => sum + getWeight(item), 0);
        const equipmentWeight = Object.values(character.equipment).reduce((sum: number, item) => {
            const equippedItem = item as Item | undefined;
            return sum + (equippedItem ? getWeight(equippedItem) : 0);
        }, 0);
        const materialsWeight = Object.entries(character.materials).reduce((sum: number, [id, qty]) => {
            const item = getItemById(id) as Item | undefined;
            const quantity = Number(qty) || 0;
            return sum + (item ? getWeight(item) * quantity : 0);
        }, 0);
        return inventoryWeight + equipmentWeight + materialsWeight;
    }, [character.inventory, character.equipment, character.materials]);

    const maxWeight = character.carryingCapacity || (character.abilityScores.str * 15);
    const isEncumbered = totalWeight > maxWeight;

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-xl font-cinzel text-brand-gold mb-2">Inventory</h3>
                    <p className="text-sm text-gray-400">Manage your items and resources.</p>
                </div>
                <div className="bg-brand-gray-dark px-4 py-2 rounded-lg border border-brand-gold/30 flex flex-col items-end">
                    <span className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">Currency</span>
                    <div className="flex items-center space-x-2">
                        <span className="font-bold text-brand-gold text-lg">{character.gold?.toLocaleString() || 0}</span>
                        <div className="w-4 h-4 bg-brand-gold rounded-full border border-yellow-700 shadow-inner"></div>
                    </div>
                </div>
            </div>
            
            <div className="bg-brand-gray-dark p-4 rounded-lg">
                <div className="grid grid-cols-5 gap-3">
                    {character.inventory.map((item, index) => (
                        <InventorySlot key={`${item.id}-${index}`} item={item} />
                    ))}
                    {Array.from({ length: Math.max(0, 25 - character.inventory.length) }).map((_, index) => (
                        <InventorySlot key={`empty-${index}`} />
                    ))}
                </div>
            </div>
            
            <div className="flex flex-col items-center justify-center space-y-1">
                <div className="w-full max-w-md bg-brand-gray-dark h-3 rounded-full overflow-hidden border border-brand-gray">
                    <div 
                        className={`h-full transition-all duration-500 ${isEncumbered ? 'bg-red-600' : 'bg-brand-gold'}`}
                        style={{ width: `${Math.min((totalWeight / maxWeight) * 100, 100)}%` }}
                    ></div>
                </div>
                <div className="text-center text-sm">
                     <p className={`font-bold ${isEncumbered ? "text-red-500" : "text-gray-400"}`}>
                        Weight: {totalWeight.toFixed(1)} / {maxWeight.toFixed(1)} lbs
                    </p>
                    {isEncumbered && <p className="text-xs text-red-400 animate-pulse">You are encumbered!</p>}
                </div>
            </div>
        </div>
    );
};

export default InventoryPage;
