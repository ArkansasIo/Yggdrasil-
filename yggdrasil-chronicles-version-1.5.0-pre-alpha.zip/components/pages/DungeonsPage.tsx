import React from 'react';
import { allInstances } from '../../data/world/instances';

interface DungeonsPageProps {
    onEnterDungeon: (name: string) => void;
}

const DungeonsPage: React.FC<DungeonsPageProps> = ({ onEnterDungeon }) => {
    const dungeons = allInstances.filter(i => i.type === 'Dungeon');

    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Dungeons</h3>
                <p className="text-sm text-gray-400 mt-1">Instanced challenges for parties of up to 5 players.</p>
            </div>
            <div className="space-y-4">
                {dungeons.map(dungeon => (
                    <button
                        key={dungeon.id}
                        onClick={() => onEnterDungeon(dungeon.name)}
                        className="w-full text-left p-4 bg-brand-gray-dark border-2 border-brand-gray rounded-lg transition-colors hover:border-brand-gold group"
                    >
                        <div className="flex justify-between items-center">
                            <h4 className="font-bold text-lg text-white group-hover:text-brand-gold">{dungeon.name}</h4>
                            <span className="px-2 py-1 text-xs font-semibold rounded-full bg-blue-500/20 text-blue-300">
                                {dungeon.maxPlayers} Players
                            </span>
                        </div>
                        <p className="text-sm text-gray-400 mt-1">{dungeon.description}</p>
                        <div className="flex justify-between items-center mt-3 text-sm">
                            <span className="text-gray-400">Min Level: <span className="font-bold text-white">{dungeon.minLevel}</span></span>
                            <span className="text-gray-500 text-xs">Loot: {dungeon.lootTier}</span>
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default DungeonsPage;