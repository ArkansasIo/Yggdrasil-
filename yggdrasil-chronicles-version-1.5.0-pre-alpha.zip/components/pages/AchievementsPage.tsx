
import React from 'react';
import { GameState, Achievement } from '../../types';
import { HeroIcon, SparklesIcon, EnemyIcon, UserIcon } from '../Icons';

const allAchievements: Achievement[] = [
    { id: 'level_10', name: 'Seasoned Wanderer', description: 'Reach level 10.', icon: UserIcon },
    { id: 'level_50', name: 'Veteran of the Realms', description: 'Reach level 50.', icon: HeroIcon },
    { id: 'first_boss', name: 'Giant Slayer', description: 'Defeat your first major boss.', icon: EnemyIcon },
    { id: 'first_dungeon', name: 'Dungeon Delver', description: 'Complete your first dungeon.', icon: EnemyIcon },
    { id: 'first_spell', name: 'A-Spark-ening', description: 'Learn your first spell.', icon: SparklesIcon },
];


const AchievementItem: React.FC<{ achievement: Achievement, completed: boolean }> = ({ achievement, completed }) => (
    <div className={`p-3 bg-brand-gray-dark rounded-lg border border-brand-gray flex items-center space-x-4 transition-opacity ${!completed && 'opacity-40'}`}>
        <div className={`w-10 h-10 flex-shrink-0 rounded-md flex items-center justify-center ${completed ? 'bg-brand-gold/10 text-brand-gold' : 'bg-black/20 text-gray-500'}`}>
            <achievement.icon />
        </div>
        <div>
            <h4 className={`font-bold ${completed ? 'text-white' : 'text-gray-400'}`}>{achievement.name}</h4>
            <p className="text-sm text-gray-500">{achievement.description}</p>
        </div>
        {completed && <div className="ml-auto text-green-400 font-bold text-sm">Completed</div>}
    </div>
);


const AchievementsPage: React.FC<{gameState: GameState}> = ({ gameState }) => {
    return (
        <div className="space-y-6">
            <div>
                <div className="flex justify-between items-center">
                    <h3 className="text-xl font-cinzel text-brand-gold">Achievements</h3>
                    <span className="text-gray-400 font-semibold">
                        {gameState.completedAchievements.length} / {allAchievements.length} Unlocked
                    </span>
                </div>
                 <p className="text-sm text-gray-400 mt-1">Track your accomplishments throughout the Shattered Realms.</p>
            </div>
            <div className="space-y-3">
                {allAchievements.map(ach => (
                    <AchievementItem 
                        key={ach.id} 
                        achievement={ach} 
                        completed={gameState.completedAchievements.includes(ach.id)} 
                    />
                ))}
            </div>
        </div>
    );
};

export default AchievementsPage;
