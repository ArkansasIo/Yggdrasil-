
import React from 'react';
import { allInstances } from '../../data/world/instances';

const TrialsPage: React.FC = () => {
    const trials = allInstances.filter(i => i.type === 'Trial');

    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Trials</h3>
                <p className="text-sm text-gray-400 mt-1">Skill-based challenges with specific mechanics.</p>
            </div>
            <div className="grid grid-cols-1 gap-4">
                {trials.map(trial => (
                     <div key={trial.id} className="p-4 bg-brand-gray-dark border border-brand-gray rounded-lg hover:border-blue-400 transition-colors cursor-pointer">
                        <h4 className="font-bold text-lg text-white">{trial.name}</h4>
                         <p className="text-sm text-gray-400 mt-1 mb-2">{trial.description}</p>
                         <div className="flex items-center space-x-2">
                             <span className="text-xs bg-brand-gray text-white px-2 py-1 rounded">Solo/Group</span>
                             <span className="text-xs bg-brand-gray text-white px-2 py-1 rounded">Lv {trial.minLevel}+</span>
                         </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default TrialsPage;
