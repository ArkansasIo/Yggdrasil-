
import React from 'react';
import { Character, Consumable } from '../../types';
import { itemIcons } from '../../data/items/icons';

interface ConsumablesPageProps {
    character: Character;
    onUseConsumable: (index: number) => void;
}

const ConsumablesPage: React.FC<ConsumablesPageProps> = ({ character, onUseConsumable }) => {
    const consumables = character.inventory
        .map((item, index) => ({ item, index }))
        .filter(({ item }) => 'type' in item && item.type === 'Consumable');

    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Satchel & Consumables</h3>
                <p className="text-sm text-gray-400 mt-1">Quickly access potions, food, and scrolls to aid you in your journey.</p>
            </div>

            {consumables.length === 0 ? (
                <div className="text-center text-gray-500 py-12 border-2 border-dashed border-brand-gray rounded-lg">
                    <p>Your satchel is empty.</p>
                    <p className="text-xs">Find or craft potions to see them here.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {consumables.map(({ item, index }) => {
                        const consumable = item as Consumable;
                        const Icon = itemIcons[consumable.iconId] || null;
                        
                        return (
                            <div key={`${consumable.id}-${index}`} className="p-4 bg-brand-gray-dark border border-brand-gray rounded-lg flex items-center space-x-4">
                                <div className="w-12 h-12 bg-black/20 rounded flex items-center justify-center text-brand-gold border border-brand-gray">
                                    {Icon && <Icon />}
                                </div>
                                <div className="flex-grow">
                                    <h4 className="font-bold text-white">{consumable.name}</h4>
                                    <p className="text-xs text-gray-500 line-clamp-1">{consumable.description}</p>
                                    <div className="mt-2 flex space-x-2">
                                        {consumable.effect.hp && <span className="text-[10px] bg-red-900/30 text-red-300 px-1.5 py-0.5 rounded">+{consumable.effect.hp} HP</span>}
                                        {consumable.effect.mp && <span className="text-[10px] bg-blue-900/30 text-blue-300 px-1.5 py-0.5 rounded">+{consumable.effect.mp} MP</span>}
                                    </div>
                                </div>
                                <button 
                                    onClick={() => onUseConsumable(index)}
                                    className="px-4 py-2 bg-brand-gold text-brand-dark font-bold rounded text-xs uppercase hover:bg-yellow-300 transition-colors"
                                >
                                    Use
                                </button>
                            </div>
                        );
                    })}
                </div>
            )}

            <div className="pt-6 border-t border-brand-gray">
                 <h4 className="font-cinzel text-brand-gold text-sm uppercase tracking-widest mb-3">Quick Slots</h4>
                 <div className="flex space-x-3">
                    {Array.from({ length: 4 }).map((_, i) => (
                        <div key={i} className="w-14 h-14 bg-brand-gray-dark border-2 border-brand-gray rounded-md flex items-center justify-center text-gray-700 font-bold">
                            {i + 1}
                        </div>
                    ))}
                 </div>
                 <p className="text-[10px] text-gray-500 mt-2 italic">Assign consumables to quick slots for fast access during combat encounters.</p>
            </div>
        </div>
    );
};

export default ConsumablesPage;
