
import React from 'react';
import { WeaponIcon, AstrologerIcon, ProphetIcon, ShieldCheckIcon } from '../Icons';

const SkillBar: React.FC<{ value: number, maxValue: number, color: string }> = ({ value, maxValue, color }) => {
    const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;
    return (
        <div className="w-full bg-brand-gray-light rounded-full h-2.5">
            <div className={`h-full rounded-full ${color}`} style={{ width: `${percentage}%` }}></div>
        </div>
    );
};


const SkillMasteryItem: React.FC<{ icon: React.ReactNode, name: string, level: number, progress: number }> = ({ icon, name, level, progress }) => (
    <div className="p-3 bg-brand-gray-dark rounded-lg border border-brand-gray flex items-center space-x-4">
        <div className="w-10 h-10 flex-shrink-0 rounded-md flex items-center justify-center bg-black/20 text-brand-gold">
            {icon}
        </div>
        <div className="flex-grow">
            <div className="flex justify-between items-center mb-1">
                <h4 className="font-bold text-white">{name}</h4>
                <p className="text-sm font-semibold text-gray-300">Mastery <span className="text-brand-gold">{level}</span></p>
            </div>
            <SkillBar value={progress} maxValue={100} color="bg-brand-gold" />
        </div>
    </div>
);


const SkillMasteryPage: React.FC = () => {
    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Skill Mastery</h3>
                <p className="text-sm text-gray-400 mt-1">Hone your proficiency with different abilities. Continued use of a skill in your adventures will increase its mastery, unlocking new effects.</p>
            </div>
            <div className="space-y-3">
                <SkillMasteryItem icon={<WeaponIcon />} name="One-Handed Swords" level={5} progress={35} />
                <SkillMasteryItem icon={<ShieldCheckIcon />} name="Parrying" level={2} progress={80} />
                <SkillMasteryItem icon={<AstrologerIcon />} name="Glintstone Sorcery" level={1} progress={15} />
                <SkillMasteryItem icon={<ProphetIcon />} name="Healing Incantations" level={1} progress={5} />
            </div>
        </div>
    );
};

export default SkillMasteryPage;
