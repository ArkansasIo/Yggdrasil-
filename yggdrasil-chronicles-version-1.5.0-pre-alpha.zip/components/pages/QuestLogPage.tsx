
import React, { useState } from 'react';
import { GameState, Quest } from '../../types';

const QuestItem: React.FC<{ quest: Quest }> = ({ quest }) => (
    <div className="p-3 bg-brand-gray-dark rounded-lg border border-brand-gray">
        <div className="flex justify-between items-start">
            <div>
                <h4 className="font-bold text-white">{quest.title}</h4>
                <p className="text-sm text-gray-400 mt-1">{quest.description}</p>
            </div>
            <span className={`flex-shrink-0 ml-2 px-2 py-0.5 text-xs font-semibold rounded-full ${quest.type === 'Main' ? 'bg-brand-gold/20 text-brand-gold' : 'bg-blue-500/20 text-blue-300'}`}>
                {quest.type} Quest
            </span>
        </div>
        <div className="mt-3 space-y-1.5">
            {quest.objectives.map((obj, index) => (
                <div key={index} className="flex items-center text-sm">
                    <input type="checkbox" checked={obj.completed} readOnly className="h-4 w-4 rounded bg-brand-gray border-brand-gray-light text-brand-gold focus:ring-brand-gold mr-2" />
                    <span className={`${obj.completed ? 'text-gray-500 line-through' : 'text-gray-300'}`}>{obj.text}</span>
                </div>
            ))}
        </div>
    </div>
);

const QuestLogPage: React.FC<{ gameState: GameState }> = ({ gameState }) => {
    const [showCompleted, setShowCompleted] = useState(false);

    const activeQuests = gameState.quests.filter(q => q.status === 'Active');
    const completedQuests = gameState.quests.filter(q => q.status !== 'Active');
    const questsToShow = showCompleted ? completedQuests : activeQuests;

    return (
        <div className="space-y-6">
            <div>
                <div className="flex justify-between items-center">
                    <h3 className="text-xl font-cinzel text-brand-gold">Quest Log</h3>
                    <span className="text-gray-400 font-semibold">{activeQuests.length} / 25 Active</span>
                </div>
                 <p className="text-sm text-gray-400 mt-1">Track your main story quests, side quests, and contracts.</p>
            </div>
            
            <div className="flex space-x-2 border-b border-brand-gray-light">
                <button onClick={() => setShowCompleted(false)} className={`py-2 px-4 text-sm font-bold ${!showCompleted ? 'text-brand-gold border-b-2 border-brand-gold' : 'text-gray-400'}`}>
                    Active
                </button>
                 <button onClick={() => setShowCompleted(true)} className={`py-2 px-4 text-sm font-bold ${showCompleted ? 'text-brand-gold border-b-2 border-brand-gold' : 'text-gray-400'}`}>
                    Completed
                </button>
            </div>

            <div className="space-y-4">
                {questsToShow.length > 0 ? (
                    questsToShow.map(quest => <QuestItem key={quest.id} quest={quest} />)
                ) : (
                    <div className="text-center text-gray-500 p-8 border-2 border-dashed border-brand-gray rounded-lg">
                        <p>No {showCompleted ? 'completed' : 'active'} quests.</p>
                        <p className="text-xs">Explore the world to uncover new stories and challenges.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default QuestLogPage;
