
import React from 'react';
import { Recipe, Character } from '../../types';
import { getItemById } from '../../data/items';
import { itemIcons } from '../../data/items/icons';
import { AlchemyIcon, MaterialIcon } from '../Icons';

const ALCHEMY_RECIPES: Recipe[] = [
    {
        id: 'recipe_health_potion',
        resultItemId: 'consumable_health_potion',
        name: 'Healing Draught',
        description: 'A standard mixture of sun-soaked herbs that mends flesh.',
        ingredients: [{ id: 'mat_kingsfoil', quantity: 3 }],
        requiredLevel: 1,
        xpReward: 30
    },
    {
        id: 'recipe_mana_elixir',
        resultItemId: 'consumable_mana_elixir',
        name: 'Glintstone Tonic',
        description: 'Brewed from crushed shards, this tonic replenishes inner focus.',
        ingredients: [{ id: 'mat_glintstone_shard', quantity: 2 }, { id: 'mat_kingsfoil', quantity: 1 }],
        requiredLevel: 3,
        xpReward: 60
    }
];

interface AlchemyPageProps {
    character: Character;
    onCraft: (recipe: Recipe) => void;
}

const AlchemyPage: React.FC<AlchemyPageProps> = ({ character, onCraft }) => {
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-xl font-cinzel text-brand-gold">Alchemy Laboratory</h3>
                    <p className="text-sm text-gray-400 mt-1">Concoct potent potions and elixirs from gathered flora and crystals.</p>
                </div>
                <div className="bg-brand-gray-dark px-3 py-2 rounded border border-brand-gray text-xs">
                    <p className="text-gray-500 uppercase tracking-tighter mb-1">Reagents</p>
                    <div className="flex space-x-3">
                         <div className="flex items-center space-x-1">
                            <span className="text-brand-gold font-bold">{character.materials['mat_kingsfoil'] || 0}</span>
                            <span className="text-gray-400">Kingsfoil</span>
                         </div>
                         <div className="flex items-center space-x-1">
                            <span className="text-brand-gold font-bold">{character.materials['mat_glintstone_shard'] || 0}</span>
                            <span className="text-gray-400">Shards</span>
                         </div>
                    </div>
                </div>
            </div>

            <div className="space-y-3">
                {ALCHEMY_RECIPES.map(recipe => {
                    const resultItem = getItemById(recipe.resultItemId);
                    const canAfford = recipe.ingredients.every(ing => (character.materials[ing.id] || 0) >= ing.quantity);
                    const isLevelMet = character.level >= recipe.requiredLevel;
                    const Icon = resultItem ? itemIcons[resultItem.iconId] : AlchemyIcon;

                    return (
                        <div key={recipe.id} className={`p-4 bg-brand-gray-dark border-2 rounded-lg transition-all ${canAfford && isLevelMet ? 'border-brand-gray hover:border-brand-gold' : 'border-red-900/30 opacity-60'}`}>
                            <div className="flex space-x-4">
                                <div className="w-16 h-16 bg-black/30 rounded flex items-center justify-center text-brand-gold border border-brand-gray flex-shrink-0">
                                    <Icon />
                                </div>
                                <div className="flex-grow">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h4 className="font-bold text-white text-lg">{recipe.name}</h4>
                                            <p className="text-xs text-gray-500">{recipe.description}</p>
                                        </div>
                                        <div className="text-right">
                                            <span className="text-[10px] text-brand-gold uppercase font-bold bg-brand-gold/10 px-1.5 py-0.5 rounded">Lv {recipe.requiredLevel}</span>
                                        </div>
                                    </div>
                                    
                                    <div className="mt-4 flex items-center justify-between">
                                        <div className="flex space-x-4">
                                            {recipe.ingredients.map(ing => (
                                                <div key={ing.id} className="flex items-center space-x-1.5">
                                                    <div className="w-3 h-3 text-gray-500"><MaterialIcon /></div>
                                                    <span className={`text-xs font-bold ${(character.materials[ing.id] || 0) >= ing.quantity ? 'text-gray-300' : 'text-red-500'}`}>
                                                        {(character.materials[ing.id] || 0)} / {ing.quantity}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                        
                                        <button 
                                            onClick={() => onCraft(recipe)}
                                            disabled={!canAfford || !isLevelMet}
                                            className={`px-4 py-1.5 rounded font-bold text-xs uppercase transition-all ${canAfford && isLevelMet ? 'bg-brand-gold text-brand-dark hover:bg-yellow-300' : 'bg-gray-700 text-gray-500 cursor-not-allowed'}`}
                                        >
                                            {canAfford ? 'Brew Potion' : 'Missing Reagents'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default AlchemyPage;
