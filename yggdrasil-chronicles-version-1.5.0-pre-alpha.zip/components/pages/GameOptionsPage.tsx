import React, { useState, useEffect } from 'react';

const OptionToggle: React.FC<{ label: string, description: string, storageKey: string, defaultValue: boolean }> = ({ label, description, storageKey, defaultValue }) => {
    const [isEnabled, setIsEnabled] = useState(() => {
        const storedValue = localStorage.getItem(storageKey);
        return storedValue ? JSON.parse(storedValue) : defaultValue;
    });

    useEffect(() => {
        localStorage.setItem(storageKey, JSON.stringify(isEnabled));
    }, [isEnabled, storageKey]);

    return (
        <div className="flex justify-between items-center p-3 bg-brand-gray-dark rounded-lg">
            <div>
                <p className="font-bold text-white">{label}</p>
                <p className="text-xs text-gray-400">{description}</p>
            </div>
            <button onClick={() => setIsEnabled(!isEnabled)} className={`w-12 h-6 rounded-full p-1 transition-colors ${isEnabled ? 'bg-brand-gold' : 'bg-brand-gray'}`}>
                <div className={`w-4 h-4 rounded-full bg-white transform transition-transform ${isEnabled ? 'translate-x-6' : 'translate-x-0'}`} />
            </button>
        </div>
    );
};

const OptionSlider: React.FC<{ label: string, description: string, storageKey: string, defaultValue: number }> = ({ label, description, storageKey, defaultValue }) => {
     const [value, setValue] = useState(() => {
        const storedValue = localStorage.getItem(storageKey);
        return storedValue ? parseInt(storedValue) : defaultValue;
    });

     useEffect(() => {
        localStorage.setItem(storageKey, String(value));
    }, [value, storageKey]);

    return (
        <div className="p-3 bg-brand-gray-dark rounded-lg">
            <div>
                <p className="font-bold text-white">{label}</p>
                <p className="text-xs text-gray-400 mb-2">{description}</p>
            </div>
            <div className="flex items-center space-x-4">
                <input 
                    type="range" 
                    min="1" 
                    max="5" 
                    step="1"
                    value={value}
                    onChange={(e) => setValue(parseInt(e.target.value))}
                    className="w-full h-2 bg-brand-gray rounded-lg appearance-none cursor-pointer accent-brand-gold"
                />
                <span className="font-bold text-lg text-white">{['Slowest', 'Slow', 'Normal', 'Fast', 'Instant'][value - 1]}</span>
            </div>
        </div>
    );
};

interface GameOptionsPageProps {
    onSave?: () => Promise<boolean>;
    onExit?: () => void;
}

const GameOptionsPage: React.FC<GameOptionsPageProps> = ({ onSave, onExit }) => {
    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Game Options</h3>
                <p className="text-sm text-gray-400 mt-1">Adjust your gameplay experience.</p>
            </div>
            <div className="space-y-4">
                <OptionToggle 
                    label="Auto-Save"
                    description="Automatically save progress during your adventure."
                    storageKey="yc_autosave_enabled"
                    defaultValue={true}
                />
                 <OptionToggle 
                    label="AI Image Generation"
                    description="Generate images for scenes. Disabling may improve performance."
                    storageKey="yc_images_enabled"
                    defaultValue={true}
                />
                <OptionSlider
                    label="Text Speed"
                    description="Control how fast the narrative text appears on screen."
                    storageKey="yc_text_speed"
                    defaultValue={3}
                />
                {onSave && (
                    <div className="pt-4 border-t border-brand-gray-light space-y-3">
                        <button 
                            onClick={() => {
                                if (onSave) {
                                    onSave().then(success => {
                                        if(success) alert("Game Saved Successfully!");
                                        else alert("Save Failed.");
                                    });
                                }
                            }}
                            className="w-full bg-brand-gold text-brand-dark font-bold py-3 px-4 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-colors"
                        >
                            Save Game
                        </button>
                        
                        {onExit && (
                            <button
                                onClick={onExit}
                                className="w-full bg-red-900/50 text-red-300 font-bold py-3 px-4 rounded-lg uppercase tracking-wider hover:bg-red-900/80 border border-red-900 transition-colors"
                            >
                                Return to Title
                            </button>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default GameOptionsPage;