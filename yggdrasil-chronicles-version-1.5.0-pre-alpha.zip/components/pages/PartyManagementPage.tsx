
import React from 'react';
import { UserIcon } from '../Icons';

const PartyMember: React.FC<{ name: string, role: string, hp: number, level: number, isLeader?: boolean }> = ({ name, role, hp, level, isLeader }) => (
    <div className="flex items-center space-x-3 p-3 bg-brand-gray-dark border border-brand-gray rounded-lg">
        <div className="w-10 h-10 bg-brand-gray rounded-full flex items-center justify-center text-gray-400 border border-gray-600">
             <UserIcon />
        </div>
        <div className="flex-grow">
            <div className="flex justify-between items-center">
                <span className="font-bold text-white text-sm">{name} {isLeader && <span className="text-yellow-500 text-xs ml-1">★</span>}</span>
                <span className="text-xs text-gray-400">Lv {level} {role}</span>
            </div>
            <div className="w-full bg-gray-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                <div className="bg-green-500 h-full" style={{ width: `${hp}%` }}></div>
            </div>
        </div>
    </div>
);

const PartyManagementPage: React.FC = () => {
    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Party Management</h3>
                <p className="text-sm text-gray-400 mt-1">Manage your current group, set loot rules, and mark targets.</p>
            </div>
            
            <div className="space-y-2">
                <h4 className="font-bold text-gray-300 text-sm uppercase tracking-wider">Current Party (1/5)</h4>
                <PartyMember name="You" role="Leader" hp={100} level={15} isLeader />
                <div className="border-2 border-dashed border-brand-gray rounded-lg p-4 text-center text-gray-500 text-sm">
                    Empty Slot
                </div>
                 <div className="border-2 border-dashed border-brand-gray rounded-lg p-4 text-center text-gray-500 text-sm">
                    Empty Slot
                </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
                <button className="bg-brand-gray text-white py-2 rounded font-bold hover:bg-brand-gray-light">Convert to Raid</button>
                <button className="bg-red-900/50 text-red-300 py-2 rounded font-bold hover:bg-red-900/80 border border-red-900">Leave Party</button>
            </div>
        </div>
    );
};

export default PartyManagementPage;
