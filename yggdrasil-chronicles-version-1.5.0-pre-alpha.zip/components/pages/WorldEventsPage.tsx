
import React from 'react';
import { WorldEventsIcon, EnemyIcon } from '../Icons';

const EventCard: React.FC<{ title: string, location: string, timeLeft: string, type: 'Boss' | 'Invasion' | 'Gathering' }> = ({ title, location, timeLeft, type }) => {
    const colors = {
        'Boss': 'border-red-500/50 bg-red-900/10',
        'Invasion': 'border-orange-500/50 bg-orange-900/10',
        'Gathering': 'border-green-500/50 bg-green-900/10',
    };

    return (
        <div className={`p-4 rounded-lg border-2 ${colors[type]} flex justify-between items-center`}>
            <div>
                <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-black/40 text-white">{type}</span>
                    <h4 className="font-bold text-white">{title}</h4>
                </div>
                <p className="text-sm text-gray-400 mt-1">{location}</p>
            </div>
            <div className="text-right">
                <p className="text-xl font-mono font-bold text-brand-gold">{timeLeft}</p>
                <p className="text-xs text-gray-500">Remaining</p>
            </div>
        </div>
    );
};

const WorldEventsPage: React.FC = () => {
    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">World Events</h3>
                <p className="text-sm text-gray-400 mt-1">Limited time events occurring across the Realms.</p>
            </div>

            <div className="space-y-3">
                <EventCard title="The Void Dragon Arises" location="Niflheim - Frozen Wastes" timeLeft="14:20" type="Boss" />
                <EventCard title="Legion Invasion" location="Midgard - Ironhold" timeLeft="05:45" type="Invasion" />
                <EventCard title="Lunar Flower Bloom" location="Alfheim - Moonlit Grove" timeLeft="42:10" type="Gathering" />
            </div>

            <div className="bg-brand-gray-dark p-4 rounded-lg">
                <h4 className="font-bold text-white mb-2 flex items-center"><EnemyIcon /><span className="ml-2">Next World Boss</span></h4>
                <div className="w-full bg-brand-gray h-2 rounded-full overflow-hidden">
                    <div className="bg-brand-gold h-full" style={{ width: '75%' }}></div>
                </div>
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>Fenrir Unbound</span>
                    <span>Spawns in ~2 hours</span>
                </div>
            </div>
        </div>
    );
};

export default WorldEventsPage;
