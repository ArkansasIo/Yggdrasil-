
import React, { useState, useEffect } from 'react';
import { ShieldCheckIcon, UserIcon, SparklesIcon } from '../Icons';

const RoleButton: React.FC<{ 
    role: string, 
    icon: React.ReactNode, 
    selected: boolean, 
    onClick: () => void 
}> = ({ role, icon, selected, onClick }) => (
    <button 
        onClick={onClick}
        className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all ${selected ? 'bg-brand-gold/20 border-brand-gold text-white' : 'bg-brand-gray-dark border-brand-gray text-gray-500 hover:border-gray-400'}`}
    >
        <div className={`w-8 h-8 mb-2 ${selected ? 'text-brand-gold' : 'text-gray-500'}`}>{icon}</div>
        <span className="font-bold text-sm">{role}</span>
    </button>
);

const GroupFinderPage: React.FC = () => {
    const [selectedRole, setSelectedRole] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [timer, setTimer] = useState(0);

    useEffect(() => {
        let interval: ReturnType<typeof setInterval>;
        if (isQueued) {
            interval = setInterval(() => {
                setTimer(t => t + 1);
            }, 1000);
        } else {
            setTimer(0);
        }
        return () => clearInterval(interval);
    }, [isQueued]);

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    return (
        <div className="space-y-6">
             <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Group Finder</h3>
                <p className="text-sm text-gray-400 mt-1">Queue for dungeons, raids, and events automatically.</p>
            </div>

            {!isQueued ? (
                <>
                    <div className="space-y-2">
                        <h4 className="font-bold text-white text-center">Select Your Role</h4>
                        <div className="grid grid-cols-3 gap-3">
                            <RoleButton role="Tank" icon={<ShieldCheckIcon />} selected={selectedRole === 'Tank'} onClick={() => setSelectedRole('Tank')} />
                            <RoleButton role="Healer" icon={<SparklesIcon />} selected={selectedRole === 'Healer'} onClick={() => setSelectedRole('Healer')} />
                            <RoleButton role="Damage" icon={<UserIcon />} selected={selectedRole === 'Damage'} onClick={() => setSelectedRole('Damage')} />
                        </div>
                    </div>
                    
                    <div className="bg-brand-gray-dark p-4 rounded-lg">
                        <div className="flex justify-between items-center text-sm mb-2">
                            <span className="text-gray-400">Activity</span>
                            <span className="text-white font-bold">Random Dungeon (Normal)</span>
                        </div>
                         <div className="flex justify-between items-center text-sm">
                            <span className="text-gray-400">Reward</span>
                            <span className="text-brand-gold font-bold">Bonus Gold & XP</span>
                        </div>
                    </div>

                    <button 
                        onClick={() => selectedRole && setIsQueued(true)}
                        disabled={!selectedRole}
                        className="w-full bg-brand-gold text-brand-dark font-bold py-3 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Find Group
                    </button>
                </>
            ) : (
                <div className="flex flex-col items-center justify-center py-10 space-y-6">
                    <div className="w-16 h-16 border-4 border-brand-gray border-t-brand-gold rounded-full animate-spin"></div>
                    <div className="text-center">
                        <h4 className="text-2xl font-bold text-white mb-1">Searching...</h4>
                        <p className="text-brand-gold font-mono text-xl">{formatTime(timer)}</p>
                        <p className="text-xs text-gray-500 mt-2">Estimated wait: 0:45</p>
                    </div>
                     <button 
                        onClick={() => setIsQueued(false)}
                        className="px-8 py-2 border border-red-500 text-red-500 font-bold rounded hover:bg-red-500/10 transition-colors"
                    >
                        Cancel Queue
                    </button>
                </div>
            )}
        </div>
    );
};

export default GroupFinderPage;
