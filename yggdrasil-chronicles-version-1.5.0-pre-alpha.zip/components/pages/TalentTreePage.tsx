
import React from 'react';
import { GameState } from '../../types';
import { SparklesIcon, LockClosedIcon } from '../Icons';

interface TalentTreePageProps {
    gameState: GameState;
    setGameState: (newState: Partial<GameState>) => void;
}

const talentData: { [key: string]: { label: string; description: string; requires: string[] } } = {
    'core_power': { label: 'Core Power', description: 'Starting point.', requires: [] },
    'minor_haste': { label: 'Minor Haste', description: '+5% Action Speed.', requires: ['core_power'] },
    'minor_vigor': { label: 'Minor Vigor', description: '+5% Max HP.', requires: ['core_power'] },
    'adept_haste': { label: 'Adept Haste', description: '+10% Action Speed.', requires: ['minor_haste'] },
    'adept_vigor': { label: 'Adept Vigor', description: '+10% Max HP.', requires: ['minor_vigor'] },
};

const talentPositions: { [key: string]: string } = {
    'core_power': '50px,120px',
    'minor_haste': '150px,50px',
    'minor_vigor': '150px,190px',
    'adept_haste': '250px,50px',
    'adept_vigor': '250px,190px',
};

const TalentNode: React.FC<{
    id: string;
    label: string;
    position: string;
    isUnlocked: boolean;
    canUnlock: boolean;
    onClick: (id: string) => void;
}> = ({ id, label, position, isUnlocked, canUnlock, onClick }) => (
    <div className="absolute" style={{ top: position.split(',')[0], left: position.split(',')[1] }}>
        <button
            onClick={() => onClick(id)}
            disabled={!canUnlock || isUnlocked}
            className={`relative w-24 h-24 flex items-center justify-center rounded-full border-2 transition-all transform hover:enabled:scale-110
                ${isUnlocked ? 'bg-brand-gold/20 border-brand-gold shadow-lg shadow-brand-gold/20' : canUnlock ? 'bg-brand-gray-dark border-brand-gray-light cursor-pointer' : 'bg-brand-gray-dark border-brand-gray opacity-60 cursor-not-allowed'}`}
        >
            <div className="text-center p-1">
                <div className={`w-6 h-6 mx-auto ${isUnlocked ? 'text-brand-gold' : canUnlock ? 'text-gray-300' : 'text-gray-600'}`}>
                    {isUnlocked ? <SparklesIcon /> : <LockClosedIcon className='w-full h-full'/>}
                </div>
                <span className={`text-xs font-bold ${isUnlocked ? 'text-white' : canUnlock ? 'text-gray-300' : 'text-gray-500'}`}>{label}</span>
            </div>
        </button>
    </div>
);

const TalentLine: React.FC<{ from: string, to: string, unlocked: boolean }> = ({ from, to, unlocked }) => {
    const [y1, x1] = from.split(',').map(s => parseInt(s.replace('px', '')) + 48);
    const [y2, x2] = to.split(',').map(s => parseInt(s.replace('px', '')) + 48);
    
    const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
    const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

    return (
        <div 
            className={`absolute h-0.5 transition-colors ${unlocked ? 'bg-brand-gold' : 'bg-brand-gray'}`}
            style={{
                top: `${y1}px`,
                left: `${x1}px`,
                width: `${length}px`,
                transform: `rotate(${angle}deg)`,
                transformOrigin: '0 0'
            }}
        />
    );
};

const TalentTreePage: React.FC<TalentTreePageProps> = ({ gameState, setGameState }) => {
    const talentPoints = gameState.character?.talentPoints ?? 0;
    const unlockedTalents = ['core_power', ...(gameState.unlockedTalents || [])]; // Core is always unlocked

    const handleUnlockTalent = (talentId: string) => {
        if (talentPoints > 0 && !unlockedTalents.includes(talentId) && gameState.character) {
            const requiredTalents = talentData[talentId as keyof typeof talentData].requires;
            const requirementsMet = requiredTalents.every(req => unlockedTalents.includes(req));

            if (requirementsMet) {
                const newUnlocked = [...(gameState.unlockedTalents || []), talentId];
                setGameState({
                    unlockedTalents: newUnlocked,
                    character: {
                        ...gameState.character,
                        talentPoints: talentPoints - 1,
                    },
                });
            }
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold mb-1">Talent Tree</h3>
                <p className="text-sm text-gray-400">Spend Talent Points to unlock powerful new passive abilities and character enhancements.</p>
                <p className="text-lg text-brand-gold font-bold mt-2">Available Points: {talentPoints}</p>
            </div>

            <div className="bg-brand-gray-dark p-4 rounded-lg min-h-[500px] relative overflow-hidden">
                {Object.keys(talentData).map(talentId => {
                     const talent = talentData[talentId as keyof typeof talentData];
                     return talent.requires.map(reqId => (
                        <TalentLine 
                            key={`${reqId}-${talentId}`}
                            from={talentPositions[reqId]} 
                            to={talentPositions[talentId]}
                            unlocked={unlockedTalents.includes(talentId) && unlockedTalents.includes(reqId)}
                        />
                     ))
                })}
                
                {Object.keys(talentData).map(talentId => {
                    const talent = talentData[talentId as keyof typeof talentData];
                    const isUnlocked = unlockedTalents.includes(talentId);
                    const requirementsMet = talent.requires.every(req => unlockedTalents.includes(req));
                    const canUnlock = talentPoints > 0 && requirementsMet && !isUnlocked;

                    return (
                        <TalentNode
                            key={talentId}
                            id={talentId}
                            label={talent.label}
                            position={talentPositions[talentId]}
                            isUnlocked={isUnlocked}
                            canUnlock={canUnlock}
                            onClick={handleUnlockTalent}
                        />
                    );
                })}
            </div>
        </div>
    );
};

export default TalentTreePage;
