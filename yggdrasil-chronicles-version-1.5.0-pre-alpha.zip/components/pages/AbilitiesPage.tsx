
import React from 'react';
import { Character } from '../../types';
import { SparklesIcon, ProphetIcon, AstrologerIcon, WeaponIcon } from '../Icons';

const spellIcons: { [key: string]: React.FC } = {
    'AstrologerIcon': AstrologerIcon,
    'ProphetIcon': ProphetIcon,
    'WeaponIcon': WeaponIcon,
    'Default': SparklesIcon,
};

const AbilitiesPage: React.FC<{character: Character | null}> = ({character}) => {
    if (!character) return null;

    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold">Abilities & Magic</h3>
                <p className="text-sm text-gray-400 mt-1">Manage and review your learned sorceries and incantations.</p>
            </div>
            
            {character.knownSpells.length === 0 ? (
                <div className="text-center text-gray-500 p-8 border-2 border-dashed border-brand-gray rounded-lg">
                    <SparklesIcon />
                    <p className="mt-2">You have not learned any spells yet.</p>
                    <p className="text-xs">Explore the world to find new masters and ancient texts.</p>
                </div>
            ) : (
                <div className="space-y-3">
                    {character.knownSpells.map(spell => {
                         const IconComponent = spellIcons[spell.iconId] || spellIcons['Default'];
                         return (
                            <div key={spell.id} className="bg-brand-gray-dark border border-brand-gray rounded-lg p-3 flex space-x-3 items-start">
                                <div className="flex-shrink-0 w-12 h-12 bg-black/20 rounded-md flex items-center justify-center text-brand-gold">
                                    <IconComponent />
                                </div>
                                <div className="flex-grow">
                                    <div className="flex justify-between items-center">
                                        <h4 className="font-bold text-white">{spell.name}</h4>
                                        <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${spell.type === 'Sorcery' ? 'bg-blue-500/20 text-blue-300' : spell.type === 'Incantation' ? 'bg-yellow-500/20 text-yellow-300' : 'bg-red-500/20 text-red-300'}`}>
                                            {spell.type}
                                        </span>
                                    </div>
                                    <p className="text-xs text-gray-400 mt-1">{spell.description}</p>
                                    <p className="text-xs text-gray-300 mt-2">MP Cost: <span className="font-bold text-white">{spell.mpCost}</span></p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

export default AbilitiesPage;
