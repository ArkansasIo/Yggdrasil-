
import React from 'react';
import { Character } from '../../types';
import { getAbilityModifier } from '../../data/dnd5e/rules';
import { ABILITIES } from '../../dnd5e-types';

interface StatsPageProps {
    character: Character;
}

const AbilityScoreDisplay: React.FC<{ label: string, score: number }> = ({ label, score }) => {
    const modifier = getAbilityModifier(score);
    return (
        <div className="bg-brand-gray-dark rounded-lg p-3 text-center border border-brand-gray">
            <div className="font-bold uppercase text-gray-400 text-sm">{label}</div>
            <div className="font-bold text-white text-4xl my-1">{score}</div>
            <div className={`font-bold text-lg rounded-full w-10 h-10 flex items-center justify-center mx-auto ${modifier >= 0 ? 'bg-brand-gray-light text-white' : 'bg-red-900/50 text-red-300'}`}>
                {modifier >= 0 ? `+${modifier}` : modifier}
            </div>
        </div>
    );
};

const SkillRow: React.FC<{ skill: Character['skills'][0], proficiencyBonus: number, abilityScores: Character['abilityScores'] }> = ({ skill, proficiencyBonus, abilityScores }) => {
    const abilityMod = getAbilityModifier(abilityScores[skill.ability]);
    const totalMod = abilityMod + (skill.proficient ? proficiencyBonus : 0);

    return (
        <div className="flex items-center space-x-2 py-1.5 px-2 rounded-md hover:bg-brand-gray-dark">
             <div className="w-5 h-5 flex items-center justify-center">
                {skill.proficient ? 
                    <div className="w-3 h-3 bg-brand-gold rounded-full border-2 border-brand-dark ring-1 ring-brand-gold"></div> :
                    <div className="w-3 h-3 border-2 border-brand-gray rounded-full"></div>
                }
            </div>
            <span className="text-gray-400 text-xs uppercase w-8">{skill.ability}</span>
            <span className="flex-grow capitalize text-gray-200">{skill.name.replace('_', ' ')}</span>
            <span className="font-bold text-white text-lg w-8 text-right">{totalMod >= 0 ? `+${totalMod}` : totalMod}</span>
        </div>
    )
}

const StatsPage: React.FC<StatsPageProps> = ({ character }) => {
    if (!character.abilityScores) {
        return <div className="text-center text-gray-400">Character data is not available.</div>
    }

    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-xl font-cinzel text-brand-gold mb-2">Primary Stats</h3>
                <div className="grid grid-cols-4 gap-2 text-center">
                    <div className="bg-brand-gray-dark p-2 rounded-md"><div className="text-xs text-gray-400">HP</div><div className="font-bold text-white">{character.hp}/{character.maxHp}</div></div>
                    <div className="bg-brand-gray-dark p-2 rounded-md"><div className="text-xs text-gray-400">AC</div><div className="font-bold text-white">{character.armorClass}</div></div>
                    <div className="bg-brand-gray-dark p-2 rounded-md"><div className="text-xs text-gray-400">Speed</div><div className="font-bold text-white">{character.speed} ft</div></div>
                    <div className="bg-brand-gray-dark p-2 rounded-md"><div className="text-xs text-gray-400">Proficiency</div><div className="font-bold text-white">+{character.proficiencyBonus}</div></div>
                </div>
            </div>

            <div>
                <h3 className="text-xl font-cinzel text-brand-gold mb-2">Ability Scores</h3>
                 <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                    {ABILITIES.map(ability => (
                        <AbilityScoreDisplay key={ability} label={ability} score={character.abilityScores[ability]} />
                    ))}
                 </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 className="text-xl font-cinzel text-brand-gold mb-2">Saving Throws</h3>
                    <div className="bg-brand-gray p-2 rounded-lg space-y-1">
                        {ABILITIES.map(ability => {
                            const isProficient = character.savingThrows[ability]?.proficient ?? false;
                             const abilityMod = getAbilityModifier(character.abilityScores[ability]);
                             const totalMod = abilityMod + (isProficient ? character.proficiencyBonus : 0);
                            return (
                                <div key={ability} className="flex items-center space-x-2 py-1.5 px-2 rounded-md hover:bg-brand-gray-dark">
                                     <div className="w-5 h-5 flex items-center justify-center">
                                        {isProficient ? 
                                            <div className="w-3 h-3 bg-brand-gold rounded-full border-2 border-brand-dark ring-1 ring-brand-gold"></div> :
                                            <div className="w-3 h-3 border-2 border-brand-gray rounded-full"></div>
                                        }
                                    </div>
                                    <span className="flex-grow capitalize text-gray-200">{ability}</span>
                                    <span className="font-bold text-white text-lg w-8 text-right">{totalMod >= 0 ? `+${totalMod}` : totalMod}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
                <div>
                    <h3 className="text-xl font-cinzel text-brand-gold mb-2">Skills</h3>
                    <div className="bg-brand-gray p-2 rounded-lg space-y-0.5">
                        {character.skills.map(skill => (
                            <SkillRow key={skill.name} skill={skill} proficiencyBonus={character.proficiencyBonus} abilityScores={character.abilityScores}/>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StatsPage;
