import React, { useState } from 'react';
import { User } from '../types';
import { authService } from '../services/authService';
import { YggdrasilIcon } from './Icons';

interface AuthModalProps {
    onClose: () => void;
    onLoginSuccess: (user: User) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ onClose, onLoginSuccess }) => {
    const [email, setEmail] = useState('forsaken@realms.com');
    const [password, setPassword] = useState('password');
    const [error, setError] = useState('');
    const [isLoggingIn, setIsLoggingIn] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setIsLoggingIn(true);
        
        // Demo Note: Any email works as long as password is "password"
        const user = await authService.login(email, password);

        setIsLoggingIn(false);

        if (user) {
            onLoginSuccess(user);
        } else {
            setError('Invalid credentials. Hint: use password "password"');
        }
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-brand-gray-dark rounded-lg border border-brand-gray-light p-8 max-w-sm w-full relative">
                 <button onClick={onClose} className="absolute top-2 right-2 text-gray-400 hover:text-white text-2xl font-bold" aria-label="Close modal">&times;</button>
                 <div className="w-16 h-16 text-brand-gold mx-auto mb-4">
                     <YggdrasilIcon />
                </div>
                <h2 className="font-cinzel text-2xl font-bold text-center text-brand-gold mb-6">Account Login</h2>
                <form className="space-y-4" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">Email</label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="user@domain.com"
                            className="w-full bg-brand-gray border border-brand-gray-light rounded-md p-2 focus:ring-brand-gold focus:border-brand-gold text-white"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-1">Password</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="********"
                            className="w-full bg-brand-gray border border-brand-gray-light rounded-md p-2 focus:ring-brand-gold focus:border-brand-gold text-white"
                            required
                        />
                    </div>
                     {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                     <button
                        type="submit"
                        disabled={isLoggingIn}
                        className="w-full bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-colors disabled:bg-brand-gray-light disabled:cursor-wait"
                    >
                        {isLoggingIn ? 'Logging in...' : 'Login'}
                    </button>
                    <p className="text-xs text-gray-400 text-center">This is a mock login. Use any email with the password "password".</p>
                </form>
            </div>
        </div>
    );
};

export default AuthModal;