
import React from 'react';
import { BackArrowIcon } from './Icons';
import { Realm } from '../types';

interface RealmSelectionPageProps {
    onRealmSelect: (realm: Realm) => void;
    onBack: () => void;
}

const mockRealms: Realm[] = [
    // Upper Realms
    { id: 'asgard', name: 'Asgard', type: 'PvE', population: 'Medium' },
    { id: 'vanaheim', name: 'Vanaheim', type: 'PvE', population: 'High' },
    { id: 'alfheim', name: 'Álfheim', type: 'PvE', population: 'Medium' },
    // Middle Realm
    { id: 'midgard', name: 'Midgard', type: 'PvE', population: 'Full' },
    // Lower/Outer Realms
    { id: 'svartalfheim', name: 'Svartálfheim', type: 'PvE', population: 'Medium' },
    { id: 'jotunheim', name: 'Jötunheim', type: 'PvP', population: 'High' },
    { id: 'muspelheim', name: 'Múspellsheim', type: 'PvP', population: 'Low' },
    { id: 'niflheim', name: 'Niflheim', type: 'PvP', population: 'Low' },
    { id: 'helheim', name: 'Helheim', type: 'PvP', population: 'Medium' },
];

const PopulationIndicator: React.FC<{ population: Realm['population'] }> = ({ population }) => {
    const colorMap = {
        'Low': 'bg-green-500',
        'Medium': 'bg-yellow-500',
        'High': 'bg-red-500',
        'Full': 'bg-gray-600',
    };
    const textColorMap = {
        'Full': 'text-gray-400'
    }
    return <span className={`px-2 py-1 text-xs font-semibold rounded ${colorMap[population]} ${textColorMap[population] ?? 'text-white'}`}>{population}</span>
}


const RealmSelectionPage: React.FC<RealmSelectionPageProps> = ({ onRealmSelect, onBack }) => {
    return (
        <div className="flex flex-col h-full flex-grow bg-brand-dark">
            <header className="flex-shrink-0 flex items-center p-3 border-b border-brand-gray-light bg-brand-gray-dark">
                 <button 
                    onClick={onBack} 
                    className="p-2 mr-3 rounded-full text-gray-300 hover:bg-brand-gray-light hover:text-white transition-colors"
                    aria-label="Go back"
                >
                    <BackArrowIcon />
                </button>
                <h2 className="font-cinzel text-xl font-bold text-brand-gold uppercase tracking-wider">Select a Realm</h2>
            </header>
            <div className="flex-grow p-4 overflow-y-auto">
                <div className="w-full space-y-3">
                    {mockRealms.map((realm) => (
                        <button 
                            key={realm.id} 
                            onClick={() => onRealmSelect(realm)}
                            disabled={realm.population === 'Full'}
                            className="w-full text-left p-4 bg-brand-gray-dark border-2 border-brand-gray rounded-lg transition-colors flex justify-between items-center hover:enabled:border-brand-gold disabled:opacity-60 disabled:cursor-not-allowed"
                        >
                            <div className="flex-grow">
                                <p className="text-lg font-bold text-white">{realm.name}</p>
                                <p className="text-sm text-gray-400">Type: {realm.type}</p>
                            </div>
                            <PopulationIndicator population={realm.population} />
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default RealmSelectionPage;