import React from 'react';
import { BackArrowIcon } from './Icons';

interface PatchNotesScreenProps {
    onBack: () => void;
}

const PatchNotesScreen: React.FC<PatchNotesScreenProps> = ({ onBack }) => {
    return (
        <div className="flex flex-col h-full flex-grow bg-brand-dark">
            <header className="flex-shrink-0 flex items-center p-3 border-b border-brand-gray-light bg-brand-gray-dark">
                 <button 
                    onClick={onBack} 
                    className="p-2 mr-3 rounded-full text-gray-300 hover:bg-brand-gray-light hover:text-white transition-colors"
                    aria-label="Go back"
                >
                    <BackArrowIcon />
                </button>
                <h2 className="font-cinzel text-xl font-bold text-brand-gold uppercase tracking-wider">Patch Notes</h2>
            </header>
            <div className="flex-grow p-4 overflow-y-auto space-y-6">
                <div>
                    <h3 className="text-lg font-bold text-white">Version 1.5.0 - "The Foundation"</h3>
                    <p className="text-xs text-gray-500 mb-2">Released: [Current Date]</p>
                    <ul className="list-disc list-inside text-sm text-gray-300 space-y-1">
                        <li>Architectural Overhaul: Migrated AI logic to a dedicated Node.js server.</li>
                        <li>UI Expansion: Added dozens of new menu sections for upcoming features.</li>
                        <li>Save/Load System: Implemented basic save and load functionality.</li>
                        <li>New Screens: Added Credits, Load Game, and Updates pages.</li>
                        <li>Vast placeholder framework for future content.</li>
                    </ul>
                </div>
                <div>
                    <h3 className="text-lg font-bold text-white">Version 1.0.0 - "Genesis"</h3>
                    <p className="text-xs text-gray-500 mb-2">Released: [A while ago]</p>
                    <ul className="list-disc list-inside text-sm text-gray-300 space-y-1">
                        <li>Initial prototype created.</li>
                        <li>Core gameplay loop established with client-side AI calls.</li>
                        <li>Character creation and basic narrative generation functional.</li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default PatchNotesScreen;
