
import React from 'react';

interface StatBarProps {
    value: number;
    maxValue: number;
    color: string;
}

const StatBar: React.FC<StatBarProps> = ({ value, maxValue, color }) => {
    const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;

    return (
        <div className="w-full bg-brand-gray-light rounded-full h-4 flex items-center relative overflow-hidden border border-black/20">
            <div 
                className={`h-full rounded-full transition-all duration-500 ease-out ${color}`}
                style={{ width: `${percentage}%` }}
            ></div>
             <div className="absolute inset-0 flex justify-end items-center px-2">
                <span className="text-xs font-semibold text-white" style={{ textShadow: '1px 1px 2px black' }}>
                    {value}/{maxValue}
                </span>
            </div>
        </div>
    );
};

export default StatBar;
