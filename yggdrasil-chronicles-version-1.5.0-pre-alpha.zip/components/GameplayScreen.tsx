
import React, { useState } from 'react';
import { GameState, GameChoice, EquipmentSlot } from '../types';

import Header from './Header';
import CharacterSheet from './CharacterSheet';
import GameView from './GameView';
import Accordion from './Accordion';
import Footer from './Footer';
import SubMenuItem from './SubMenuItem';
import SubMenuPage from './SubMenuPage';

// Import all page components
import AbilitiesPage from './pages/AbilitiesPage';
import AchievementsPage from './pages/AchievementsPage';
import AlchemyPage from './pages/AlchemyPage';
import AppearancePage from './pages/AppearancePage';
import ArmorPage from './pages/ArmorPage';
import BestiaryPage from './pages/BestiaryPage';
import BlueprintsPage from './pages/BlueprintsPage';
import BountiesPage from './pages/BountiesPage';
import ClassesPage from './pages/ClassesPage';
import ConsumablesPage from './pages/ConsumablesPage';
import ContinentsPage from './pages/ContinentsPage';
import CookingPage from './pages/CookingPage';
import CooperativePlayPage from './pages/CooperativePlayPage';
import CountriesPage from './pages/CountriesPage';
import CovenantsPage from './pages/CovenantsPage';
import DungeonLobbyPage from './pages/DungeonLobbyPage';
import DungeonsPage from './pages/DungeonsPage';
import EnchantingPage from './pages/EnchantingPage';
import EquipmentPage from './pages/EquipmentPage';
import EquipmentSlotsPage from './pages/EquipmentSlotsPage';
import FastTravelPage from './pages/FastTravelPage';
import GameOptionsPage from './pages/GameOptionsPage';
import GroupFinderPage from './pages/GroupFinderPage';
import GuildsPage from './pages/GuildsPage';
import KingdomsPage from './pages/KingdomsPage';
import KnownLocationsPage from './pages/KnownLocationsPage';
import LorePage from './pages/LorePage';
import MagicPage from './pages/MagicPage';
import MaterialsPage from './pages/MaterialsPage';
import PartyManagementPage from './pages/PartyManagementPage';
import PlayerMessagesPage from './pages/PlayerMessagesPage';
import ProgressionPage from './pages/ProgressionPage';
import PvpInvasionsPage from './pages/PvpInvasionsPage';
import PvpRankingsPage from './pages/PvpRankingsPage';
import QuestLogPage from './pages/QuestLogPage';
import RaidsPage from './pages/RaidsPage';
import RarityGuidePage from './pages/RarityGuidePage';
import RealmsPage from './pages/RealmsPage';
import SetBonusesPage from './pages/SetBonusesPage';
import SmithingPage from './pages/SmithingPage';
import StatsPage from './pages/StatsPage';
import StatusEffectsPage from './pages/StatusEffectsPage';
import StoryPage from './pages/StoryPage';
import SummonSignsPage from './pages/SummonSignsPage';
import TheTowerPage from './pages/TheTowerPage';
import TrialsPage from './pages/TrialsPage';
import WeaponsPage from './pages/WeaponsPage';
import WorldEventsPage from './pages/WorldEventsPage';
import WorldMapPage from './pages/WorldMapPage';
import WorldTierPage from './pages/WorldTierPage';
import TalentTreePage from './pages/TalentTreePage';
import SkillMasteryPage from './pages/SkillMasteryPage';
import StoreFeaturedPage from './pages/StoreFeaturedPage';
import InventoryPage from './pages/InventoryPage';

import {
    UserIcon, GlobeAltIcon, MultiplayerIcon, DungeonIcon, InventoryIcon, CraftingIcon, SettingsIcon,
    StatsIcon, EquipmentIcon, StatusEffectsIcon, ProgressionIcon, ClassesIcon, AppearanceIcon,
    MapIcon, LocationPinIcon, QuestsIcon, LoreIcon, FastTravelIcon, CovenantIcon, WorldEventsIcon,
    KingdomIcon, CountriesIcon, ContinentsIcon, RealmsIcon,
    CooperativeIcon, PvpIcon, MessageIcon, SummonIcon, GuildIcon, PartyIcon,
    DungeonSmallIcon, RaidIcon, TrialIcon, TowerIcon,
    WeaponIcon, ArmorIcon, ConsumableIcon, MaterialIcon, RarityIcon, SetBonusIcon,
    SmithingIcon, AlchemyIcon, EnchantingIcon, CookingIcon, BlueprintIcon,
    StoryIcon, QuestLogIcon, DifficultyIcon, EnemyIcon, SparklesIcon,
    AchievementIcon, ShieldCheckIcon, SaveIcon
} from './Icons';
import { useServerStatus } from '../hooks/useServerStatus';

interface GameplayScreenProps {
    gameState: GameState;
    isLoading: boolean;
    handlePlayerChoice: (choice: GameChoice) => void;
    updateGameState: (newState: Partial<GameState>) => void;
    equipItem: (index: number) => void;
    useConsumable: (index: number) => void;
    craftItem: (recipe: any) => void;
    modifyReputation: (factionId: string, amount: number) => void;
    masterworkItem: (location: { type: 'inventory', index: number } | { type: 'equipment', slot: EquipmentSlot }) => void;
    manualSaveGame: () => Promise<boolean>;
    onExit: () => void;
}

const worldTierNames: { [key: number]: string } = {
    1: 'Normal', 2: 'Hard', 3: 'Veteran', 4: 'Nightmare', 5: 'Torment',
    6: 'Inferno', 7: 'Apocalypse', 8: 'Harrowing', 9: 'Ultra Nightmare'
};

const GameplayScreen: React.FC<GameplayScreenProps> = ({ 
    gameState, isLoading, handlePlayerChoice, updateGameState, equipItem, useConsumable, craftItem, modifyReputation, masterworkItem, manualSaveGame, onExit 
}) => {
    const [openAccordion, setOpenAccordion] = useState<string | null>(null);
    const [activeSubView, setActiveSubView] = useState<string | null>(null);
    const isServerOnline = useServerStatus();

    const toggleAccordion = (id: string) => {
        setOpenAccordion(openAccordion === id ? null : id);
    };
    
    const handleSubMenuClick = (viewName: string) => {
        setActiveSubView(viewName);
    };

    const handleBackToGame = () => {
        setActiveSubView(null);
    };

    if (!gameState.character) {
        return <div>Loading Character...</div>;
    }

    const renderSubViewContent = () => {
        if (!activeSubView || !gameState.character) return null;

        const pages: { [key: string]: React.ReactNode } = {
            'Stats & Attributes': <StatsPage character={gameState.character} />,
            'Equipment & Inventory': <EquipmentPage character={gameState.character} onEquipItem={equipItem} onMasterwork={masterworkItem} />,
            'Inventory': <InventoryPage character={gameState.character} />,
            'Quest Log': <QuestLogPage gameState={gameState} />,
            'Talent Tree': <TalentTreePage gameState={gameState} setGameState={updateGameState} />,
            'Skill Mastery': <SkillMasteryPage />,
            'Status Effects': <StatusEffectsPage />,
            'Progression': <ProgressionPage />,
            'Classes': <ClassesPage />,
            'Appearance': <AppearancePage />,
            'Abilities & Magic': <MagicPage character={gameState.character} />,
            'Weapons': <WeaponsPage />,
            'Armor & Apparel': <ArmorPage />,
            'Consumables': <ConsumablesPage character={gameState.character} onUseConsumable={useConsumable} />,
            'Materials': <MaterialsPage />,
            'Item Rarity Guide': <RarityGuidePage />,
            'Equipment Slots': <EquipmentSlotsPage />,
            'Set Bonuses': <SetBonusesPage />,
            'World Map': <WorldMapPage />,
            'Known Locations': <KnownLocationsPage />,
            'Fast Travel': <FastTravelPage />,
            'Lore & Journals': <LorePage />,
            'Covenants': <CovenantsPage character={gameState.character} />,
            'World Events': <WorldEventsPage />,
            'Continents': <ContinentsPage />,
            'Kingdoms': <KingdomsPage />,
            'Countries': <CountriesPage />,
            'The 9 Realms': <RealmsPage />,
            'Cooperative Play': <CooperativePlayPage />,
            'PvP Invasions': <PvpInvasionsPage />,
            'Player Messages': <PlayerMessagesPage />,
            'Summon Signs': <SummonSignsPage />,
            'Guilds & Clans': <GuildsPage />,
            'Party Management': <PartyManagementPage />,
            'PvP Rankings': <PvpRankingsPage />,
            'Group Finder': <GroupFinderPage />,
            'Dungeons': <DungeonsPage onEnterDungeon={(name) => handlePlayerChoice({text: `Enter ${name}`, action: `The player enters the dungeon: ${name}`})} />,
            'Raids': <RaidsPage />,
            'Trials': <TrialsPage />,
            'The Tower': <TheTowerPage />,
            'Dungeon (2-4)': <DungeonLobbyPage type="Dungeon"/>,
            'Raid (12)': <DungeonLobbyPage type="Raid" />,
            'Trial (6-8)': <DungeonLobbyPage type="Trial" />,
            'The Tower (Solo)': <TheTowerPage />,
            'Smithing': <SmithingPage character={gameState.character} onCraft={craftItem} />,
            'Alchemy': <AlchemyPage character={gameState.character} onCraft={craftItem} />,
            'Enchanting': <EnchantingPage />,
            'Cooking': <CookingPage character={gameState.character} onCraft={craftItem} />,
            'Blueprints': <BlueprintsPage />,
            'Story': <StoryPage gameState={gameState} />,
            'World Tier': <WorldTierPage gameState={gameState} setGameState={updateGameState} />,
            'Bestiary': <BestiaryPage gameState={gameState} />,
            'Game Options': <GameOptionsPage onSave={manualSaveGame} onExit={onExit} />,
            'Achievements': <AchievementsPage gameState={gameState} />,
            'Store': <StoreFeaturedPage />,
        };

        return pages[activeSubView] || <div className="text-center text-gray-400 p-8"><p>Under development.</p></div>;
    };

    if (activeSubView) {
        return (
             <SubMenuPage title={activeSubView} onBack={handleBackToGame}>
                {renderSubViewContent()}
             </SubMenuPage>
        );
    }

    return (
        <>
            <Header onSave={manualSaveGame} />
            <main className="flex-grow p-3 space-y-3 overflow-y-auto">
                <CharacterSheet character={gameState.character} />
                <GameView
                    narrative={gameState.narrative}
                    imageUrl={gameState.imageUrl}
                    choices={gameState.choices}
                    isLoading={isLoading}
                    onChoiceSelect={handlePlayerChoice}
                />
                <div className="space-y-2">
                    <Accordion id="character" title="Character" icon={<UserIcon />} isOpen={openAccordion === 'character'} toggle={toggleAccordion}>
                        <div className="p-2 grid grid-cols-2 gap-1">
                            <SubMenuItem icon={<StatsIcon/>} label="Stats & Attributes" onClick={() => handleSubMenuClick('Stats & Attributes')} />
                            <SubMenuItem icon={<EquipmentIcon/>} label="Equipment & Inventory" onClick={() => handleSubMenuClick('Equipment & Inventory')} />
                             <SubMenuItem icon={<SparklesIcon/>} label="Abilities & Magic" onClick={() => handleSubMenuClick('Abilities & Magic')} />
                             <SubMenuItem icon={<ProgressionIcon/>} label="Talent Tree" onClick={() => handleSubMenuClick('Talent Tree')} />
                             <SubMenuItem icon={<ShieldCheckIcon/>} label="Skill Mastery" onClick={() => handleSubMenuClick('Skill Mastery')} />
                            <SubMenuItem icon={<StatusEffectsIcon/>} label="Status Effects" onClick={() => handleSubMenuClick('Status Effects')} />
                            <SubMenuItem icon={<ClassesIcon/>} label="Classes" onClick={() => handleSubMenuClick('Classes')} />
                            <SubMenuItem icon={<AppearanceIcon/>} label="Appearance" onClick={() => handleSubMenuClick('Appearance')} />
                        </div>
                    </Accordion>
                    
                     <Accordion id="inventory" title="Items Database" icon={<InventoryIcon />} isOpen={openAccordion === 'inventory'} toggle={toggleAccordion}>
                        <div className="p-2 grid grid-cols-2 gap-1">
                           <SubMenuItem icon={<InventoryIcon/>} label="Player Inventory" onClick={() => handleSubMenuClick('Inventory')}/>
                           <SubMenuItem icon={<WeaponIcon/>} label="Weapons" onClick={() => handleSubMenuClick('Weapons')}/>
                           <SubMenuItem icon={<ArmorIcon/>} label="Armor & Apparel" onClick={() => handleSubMenuClick('Armor & Apparel')}/>
                           <SubMenuItem icon={<ConsumableIcon/>} label="Consumables" onClick={() => handleSubMenuClick('Consumables')}/>
                           <SubMenuItem icon={<MaterialIcon/>} label="Materials" onClick={() => handleSubMenuClick('Materials')}/>
                           <SubMenuItem icon={<RarityIcon/>} label="Item Rarity Guide" onClick={() => handleSubMenuClick('Item Rarity Guide')}/>
                           <SubMenuItem icon={<SetBonusIcon/>} label="Set Bonuses" onClick={() => handleSubMenuClick('Set Bonuses')}/>
                        </div>
                    </Accordion>

                    <Accordion id="world" title="World & Quests" icon={<GlobeAltIcon />} isOpen={openAccordion === 'world'} toggle={toggleAccordion}>
                        <div className="p-2 grid grid-cols-2 gap-1">
                            <SubMenuItem icon={<MapIcon/>} label="World Map" onClick={() => handleSubMenuClick('World Map')}/>
                            <SubMenuItem icon={<LocationPinIcon/>} label="Known Locations" onClick={() => handleSubMenuClick('Known Locations')}/>
                            <SubMenuItem icon={<FastTravelIcon/>} label="Fast Travel" onClick={() => handleSubMenuClick('Fast Travel')}/>
                             <SubMenuItem icon={<QuestLogIcon/>} label="Bounties" onClick={() => handleSubMenuClick('Bounties')}/>
                            <SubMenuItem icon={<LoreIcon/>} label="Lore & Journals" onClick={() => handleSubMenuClick('Lore & Journals')}/>
                            <SubMenuItem icon={<CovenantIcon/>} label="Covenants" onClick={() => handleSubMenuClick('Covenants')}/>
                            <SubMenuItem icon={<WorldEventsIcon/>} label="World Events" onClick={() => handleSubMenuClick('World Events')}/>
                            <SubMenuItem icon={<ContinentsIcon/>} label="Continents" onClick={() => handleSubMenuClick('Continents')}/>
                            <SubMenuItem icon={<KingdomIcon/>} label="Kingdoms" onClick={() => handleSubMenuClick('Kingdoms')}/>
                            <SubMenuItem icon={<CountriesIcon/>} label="Countries" onClick={() => handleSubMenuClick('Countries')}/>
                            <SubMenuItem icon={<RealmsIcon/>} label="The 9 Realms" onClick={() => handleSubMenuClick('The 9 Realms')}/>
                        </div>
                    </Accordion>
                    
                    <Accordion id="multiplayer" title="Multiplayer" icon={<MultiplayerIcon />} isOpen={openAccordion === 'multiplayer'} toggle={toggleAccordion}>
                         <div className="p-2 grid grid-cols-2 gap-1">
                            <SubMenuItem icon={<CooperativeIcon/>} label="Cooperative Play" onClick={() => handleSubMenuClick('Cooperative Play')}/>
                            <SubMenuItem icon={<PvpIcon/>} label="PvP Invasions" onClick={() => handleSubMenuClick('PvP Invasions')}/>
                            <SubMenuItem icon={<MessageIcon/>} label="Player Messages" onClick={() => handleSubMenuClick('Player Messages')}/>
                            <SubMenuItem icon={<SummonIcon/>} label="Summon Signs" onClick={() => handleSubMenuClick('Summon Signs')}/>
                            <SubMenuItem icon={<GuildIcon/>} label="Guilds & Clans" onClick={() => handleSubMenuClick('Guilds & Clans')}/>
                            <SubMenuItem icon={<PartyIcon/>} label="Party Management" onClick={() => handleSubMenuClick('Party Management')}/>
                             <SubMenuItem icon={<StatsIcon/>} label="PvP Rankings" onClick={() => handleSubMenuClick('PvP Rankings')}/>
                             <SubMenuItem icon={<UserIcon/>} label="Group Finder" onClick={() => handleSubMenuClick('Group Finder')}/>
                        </div>
                    </Accordion>

                    <Accordion id="dungeons" title="Dungeons & Raids" icon={<DungeonIcon />} isOpen={openAccordion === 'dungeons'} toggle={toggleAccordion}>
                         <div className="p-2 grid grid-cols-2 gap-1">
                            <SubMenuItem icon={<DungeonIcon/>} label="Dungeons" onClick={() => handleSubMenuClick('Dungeons')}/>
                            <SubMenuItem icon={<RaidIcon/>} label="Raids" onClick={() => handleSubMenuClick('Raids')}/>
                            <SubMenuItem icon={<TrialIcon/>} label="Trials" onClick={() => handleSubMenuClick('Trials')}/>
                            <SubMenuItem icon={<TowerIcon/>} label="The Tower" onClick={() => handleSubMenuClick('The Tower')}/>
                        </div>
                    </Accordion>

                    <Accordion id="crafting" title="Crafting" icon={<CraftingIcon />} isOpen={openAccordion === 'crafting'} toggle={toggleAccordion}>
                         <div className="p-2 grid grid-cols-2 gap-1">
                            <SubMenuItem icon={<SmithingIcon/>} label="Smithing" onClick={() => handleSubMenuClick('Smithing')}/>
                            <SubMenuItem icon={<AlchemyIcon/>} label="Alchemy" onClick={() => handleSubMenuClick('Alchemy')}/>
                            <SubMenuItem icon={<EnchantingIcon/>} label="Enchanting" onClick={() => handleSubMenuClick('Enchanting')}/>
                            <SubMenuItem icon={<CookingIcon/>} label="Cooking" onClick={() => handleSubMenuClick('Cooking')}/>
                            <SubMenuItem icon={<BlueprintIcon/>} label="Blueprints" onClick={() => handleSubMenuClick('Blueprints')}/>
                        </div>
                    </Accordion>
                     <Accordion id="settings" title="System" icon={<SettingsIcon />} isOpen={openAccordion === 'settings'} toggle={toggleAccordion}>
                        <div className="p-2 grid grid-cols-2 gap-1">
                            <SubMenuItem icon={<StoryIcon/>} label={`Story: Act ${gameState.act} / Ch. ${gameState.chapter}`} onClick={() => handleSubMenuClick('Story')}/>
                            <SubMenuItem icon={<QuestLogIcon/>} label={`Quest Log: ${gameState.questCount}/25`} onClick={() => handleSubMenuClick('Quest Log')}/>
                            <SubMenuItem icon={<DifficultyIcon/>} label={`World Tier: ${gameState.worldTier}`} onClick={() => handleSubMenuClick('World Tier')}/>
                            <SubMenuItem icon={<EnemyIcon/>} label="Bestiary" onClick={() => handleSubMenuClick('Bestiary')}/>
                             <SubMenuItem icon={<AchievementIcon/>} label="Achievements" onClick={() => handleSubMenuClick('Achievements')}/>
                            <SubMenuItem icon={<DungeonIcon/>} label="Store" onClick={() => handleSubMenuClick('Store')}/>
                            <SubMenuItem icon={<SettingsIcon/>} label="Game Options" onClick={() => handleSubMenuClick('Game Options')}/>
                            <SubMenuItem icon={<SaveIcon/>} label="Save Game" onClick={manualSaveGame}/>
                        </div>
                    </Accordion>
                </div>
            </main>
            <Footer 
                worldTierName={worldTierNames[gameState.worldTier] || 'Normal'} 
                realmName={gameState.realmName}
                isOnline={isServerOnline}
            />
        </>
    );
};

export default GameplayScreen;
