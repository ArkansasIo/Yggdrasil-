
import React from 'react';
import { GameChoice } from '../types';

interface GameViewProps {
    narrative: string;
    imageUrl: string | null;
    choices: GameChoice[];
    isLoading: boolean;
    onChoiceSelect: (choice: GameChoice) => void;
}

const SkeletonLoader: React.FC = () => (
    <div className="animate-pulse space-y-4">
        <div className="bg-brand-gray h-48 w-full rounded-lg relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-[shimmer_2s_infinite]"></div>
        </div>
        <div className="space-y-3">
            <div className="bg-brand-gray h-4 w-full rounded"></div>
            <div className="bg-brand-gray h-4 w-5/6 rounded"></div>
            <div className="bg-brand-gray h-4 w-4/6 rounded"></div>
        </div>
        <div className="space-y-2 pt-6">
            <div className="bg-brand-gray-dark border border-brand-gray h-12 w-full rounded-lg"></div>
            <div className="bg-brand-gray-dark border border-brand-gray h-12 w-full rounded-lg"></div>
        </div>
        <style>{`
            @keyframes shimmer {
                100% { transform: translateX(100%); }
            }
        `}</style>
    </div>
);


const GameView: React.FC<GameViewProps> = ({ narrative, imageUrl, choices, isLoading, onChoiceSelect }) => {
    if (isLoading && !narrative) {
        return <SkeletonLoader />;
    }

    return (
        <div className="space-y-4">
            {imageUrl && (
                <img 
                    src={imageUrl} 
                    alt="Current Scene" 
                    className="w-full h-auto max-h-72 object-cover rounded-lg shadow-lg border-2 border-brand-gray-light"
                />
            )}
            
            <div className={`prose prose-invert prose-sm max-w-none text-gray-300 transition-opacity duration-500 ${isLoading ? 'opacity-40' : 'opacity-100'}`}>
                {narrative ? (
                    <div dangerouslySetInnerHTML={{ __html: narrative.replace(/\n/g, '<br />') }} />
                ) : (
                    <p className="italic text-gray-500">The echoes of the realm are quiet for now...</p>
                )}
            </div>

            {isLoading && narrative && (
                <div className="flex items-center space-x-2 text-brand-gold text-xs font-bold uppercase tracking-widest animate-pulse mt-4">
                    <div className="w-2 h-2 bg-brand-gold rounded-full"></div>
                    <span>The DM is thinking...</span>
                </div>
            )}

            {choices.length > 0 && (
                <div className="pt-4 space-y-3">
                    {choices.map((choice, index) => (
                        <button
                            key={index}
                            onClick={() => onChoiceSelect(choice)}
                            disabled={isLoading}
                            className="w-full text-left p-3 bg-brand-gray hover:bg-brand-gray-light border border-brand-gray-light rounded-lg transition-all duration-200 transform hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-brand-gold focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {choice.text}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default GameView;
