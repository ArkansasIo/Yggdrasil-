import React from 'react';
import { BackArrowIcon } from './Icons';

interface SubMenuPageProps {
    title: string;
    onBack: () => void;
    children: React.ReactNode;
}

const SubMenuPage: React.FC<SubMenuPageProps> = ({ title, onBack, children }) => {
    return (
        <div className="flex flex-col h-full flex-grow bg-brand-dark">
            <header className="flex-shrink-0 flex items-center p-3 border-b border-brand-gray-light bg-brand-gray-dark">
                <button 
                    onClick={onBack} 
                    className="p-2 mr-3 rounded-full text-gray-300 hover:bg-brand-gray-light hover:text-white transition-colors"
                    aria-label="Go back"
                >
                    <BackArrowIcon />
                </button>
                <h2 className="font-cinzel text-xl font-bold text-brand-gold uppercase tracking-wider">{title}</h2>
            </header>
            <div className="flex-grow p-4 overflow-y-auto">
                {children}
            </div>
        </div>
    );
};

export default SubMenuPage;
