

import React from 'react';

interface FooterProps {
    worldTierName: string;
    realmName: string;
    isOnline: boolean;
}

const Footer: React.FC<FooterProps> = ({ worldTierName, realmName, isOnline }) => {
    return (
        <footer className="bg-brand-gray-dark p-2 border-t border-brand-gray-light text-xs text-gray-400">
            <div className="flex justify-between items-center max-w-lg mx-auto px-2">
                <div className="flex items-center space-x-2">
                    <span className="relative flex h-2.5 w-2.5">
                        {isOnline ? (
                             <>
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
                            </>
                        ) : (
                            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600"></span>
                        )}
                    </span>
                    <span>{realmName} - <span className={isOnline ? 'text-green-400' : 'text-red-400'}>{isOnline ? 'Online' : 'Offline'}</span></span>
                </div>
                <div className="flex items-center space-x-4">
                     <span>Difficulty: {worldTierName}</span>
                     <label className="flex items-center space-x-1 cursor-pointer">
                        <input type="checkbox" className="form-checkbox h-3 w-3 bg-brand-gray-light border-brand-gray-light text-brand-gold focus:ring-brand-gold" defaultChecked />
                        <span>Auto-Save</span>
                    </label>
                </div>
            </div>
        </footer>
    );
};

export default Footer;