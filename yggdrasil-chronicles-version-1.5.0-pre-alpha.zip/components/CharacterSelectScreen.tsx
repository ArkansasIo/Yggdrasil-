import React, { useState, useEffect } from 'react';
import { BackArrowIcon, YggdrasilIcon } from './Icons';
import { gameApiService } from '../services/gameApiService';
import { SaveFile, User, Realm } from '../types';

interface CharacterSelectScreenProps {
    user: User;
    realm: Realm;
    onBack: () => void;
    onGameLoad: (saveFile: SaveFile) => void;
    onNewCharacter: (slot: number) => void;
}

const CharacterSlot: React.FC<{
    saveFile: SaveFile | null;
    slot: number;
    onLoad: (saveFile: SaveFile) => void;
    onCreate: (slot: number) => void;
}> = ({ saveFile, slot, onLoad, onCreate }) => {
    if (saveFile) {
        return (
            <button 
                onClick={() => onLoad(saveFile)}
                className="w-full h-full text-left p-4 bg-brand-gray-dark border-2 border-brand-gray hover:border-brand-gold rounded-lg transition-colors flex flex-col justify-between"
            >
                <div>
                    <div className="flex justify-between items-start">
                        <img src={saveFile.avatarUrl} alt={saveFile.characterName} className="w-16 h-16 rounded-md border-2 border-brand-gray-light object-cover" />
                        <span className="text-sm text-gray-400">Lvl {saveFile.level}</span>
                    </div>
                    <p className="text-xl font-bold text-white mt-3">{saveFile.characterName}</p>
                    <p className="text-sm text-gray-300">{saveFile.class}</p>
                </div>
                <p className="text-xs text-gray-500 mt-2">{saveFile.location}</p>
            </button>
        );
    }

    return (
        <button 
            onClick={() => onCreate(slot)}
            className="w-full h-full text-center p-4 bg-brand-gray-dark/50 border-2 border-dashed border-brand-gray hover:border-brand-gold rounded-lg transition-colors flex flex-col items-center justify-center text-gray-400 hover:text-brand-gold"
        >
            <div className="w-12 h-12">
                <YggdrasilIcon />
            </div>
            <span className="mt-2 font-bold uppercase tracking-wider">Create New Character</span>
        </button>
    );
};

const CharacterSelectScreen: React.FC<CharacterSelectScreenProps> = ({ user, realm, onBack, onGameLoad, onNewCharacter }) => {
    const [saves, setSaves] = useState<(SaveFile | null)[]>([null, null, null]);
    const [isLoading, setIsLoading] = useState(true);
    const maxSlots = 3;

    useEffect(() => {
        let isMounted = true;

        const fetchSaves = async () => {
            setIsLoading(true);
            try {
                const files = await gameApiService.getSaveFiles(user, realm);
                if (isMounted) {
                    const newSaves: (SaveFile | null)[] = Array(maxSlots).fill(null);
                    if (Array.isArray(files)) {
                        files.forEach(file => {
                            if (file.slot >= 0 && file.slot < maxSlots) {
                                newSaves[file.slot] = file;
                            }
                        });
                    }
                    setSaves(newSaves);
                }
            } catch (error) {
                console.error("Failed to fetch saves:", error);
            } finally {
                if (isMounted) {
                    setIsLoading(false);
                }
            }
        };

        fetchSaves();

        return () => {
            isMounted = false;
        };
    }, [user, realm]);

    return (
        <div className="flex flex-col h-full flex-grow bg-brand-dark">
            <header className="flex-shrink-0 flex items-center p-3 border-b border-brand-gray-light bg-brand-gray-dark">
                 <button 
                    onClick={onBack} 
                    className="p-2 mr-3 rounded-full text-gray-300 hover:bg-brand-gray-light hover:text-white transition-colors"
                    aria-label="Go back"
                >
                    <BackArrowIcon />
                </button>
                <h2 className="font-cinzel text-xl font-bold text-brand-gold uppercase tracking-wider">
                    {realm.name} - Characters
                </h2>
            </header>
            <main className="flex-grow p-4 overflow-y-auto flex items-center justify-center">
                {isLoading ? (
                    <div className="flex flex-col items-center justify-center space-y-4">
                        <div className="w-12 h-12 border-4 border-brand-gray border-t-brand-gold rounded-full animate-spin"></div>
                        <div className="text-gray-400 animate-pulse">Loading characters...</div>
                    </div>
                ) : (
                    <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4 h-[300px]">
                        {saves.map((save, index) => (
                           <CharacterSlot 
                                key={index}
                                slot={index}
                                saveFile={save}
                                onLoad={onGameLoad}
                                onCreate={onNewCharacter}
                           />
                        ))}
                    </div>
                )}
            </main>
        </div>
    );
};

export default CharacterSelectScreen;