import React from 'react';

interface CreditsScreenProps {
    onBack: () => void;
}

const CreditsScreen: React.FC<CreditsScreenProps> = ({ onBack }) => {
    return (
        <div className="flex flex-col items-center justify-center h-full flex-grow p-8 bg-brand-dark text-center">
            <h1 className="font-cinzel text-3xl font-bold tracking-widest text-brand-gold uppercase mb-8">
                Credits
            </h1>
            <p className="mb-8 text-gray-400">By: Stephen Deline Jr</p>
            <div className="font-inter text-gray-300 space-y-4">
                <div>
                    <h2 className="text-lg font-bold text-brand-gold">Development</h2>
                    <p>A Vercel & Google Collaboration</p>
                </div>
                <div>
                    <h2 className="text-lg font-bold text-brand-gold">AI Engine</h2>
                    <p>Powered by Google Gemini</p>
                </div>
                 <div>
                    <h2 className="text-lg font-bold text-brand-gold">Image Generation</h2>
                    <p>Powered by Google Imagen 3</p>
                </div>
            </div>
            <button
                onClick={onBack}
                className="mt-12 bg-brand-gray text-gray-300 font-bold py-3 px-6 rounded-lg uppercase tracking-wider hover:bg-brand-gray-light transition-colors"
            >
                Back to Title
            </button>
        </div>
    );
};

export default CreditsScreen;