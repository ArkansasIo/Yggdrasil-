import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { CharacterCreationData } from '../types';
import { BackArrowIcon } from './Icons';
import { dndClasses, dndRaces, getAbilityModifier, dndSkills } from '../data/dnd5e';
import { Ability, AbilityScores, Dnd5eClass, Dnd5eRace, SkillName } from '../dnd5e-types';

interface CharacterCreationScreenProps {
    onComplete: (characterData: CharacterCreationData) => void;
    onBack: () => void;
}

const PointBuyAllocator: React.FC<{
    scores: AbilityScores,
    setScores: (scores: AbilityScores) => void,
    points: number,
    setPoints: (points: number) => void
}> = ({ scores, setScores, points, setPoints }) => {
    const pointCosts: Record<number, number> = { 8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 13: 5, 14: 7, 15: 9 };

    const handleScoreChange = (ability: Ability, direction: 1 | -1) => {
        const currentScore = scores[ability];
        const newScore = currentScore + direction;
        
        if (newScore < 8 || newScore > 15) return;

        const oldCost = pointCosts[currentScore] ?? 0;
        const newCost = pointCosts[newScore] ?? 0;
        const costDifference = newCost - oldCost;

        if (points - costDifference >= 0) {
            setPoints(points - costDifference);
            setScores({ ...scores, [ability]: newScore });
        }
    };

    return (
        <div className="space-y-2">
            <p className="text-center text-lg">Points Remaining: <span className="font-bold text-brand-gold">{points}</span></p>
            {(Object.keys(scores) as Ability[]).map((ability) => {
                const currentScore = scores[ability];
                const nextCost = pointCosts[currentScore + 1];
                const currentCost = pointCosts[currentScore];
                const costToIncrement = (nextCost !== undefined) ? nextCost - currentCost : 999;
                
                return (
                <div key={ability} className="flex items-center justify-between bg-brand-gray-dark p-2 rounded-md">
                    <span className="font-bold uppercase text-gray-300 w-12">{ability}</span>
                    <div className="flex items-center space-x-4">
                         <button onClick={() => handleScoreChange(ability, -1)} disabled={currentScore <= 8} className="w-8 h-8 bg-brand-gray-light rounded-md text-xl disabled:opacity-50">-</button>
                        <span className="font-bold text-2xl w-8 text-center text-white">{currentScore}</span>
                        <button 
                            onClick={() => handleScoreChange(ability, 1)} 
                            disabled={currentScore >= 15 || points < costToIncrement} 
                            className="w-8 h-8 bg-brand-gray-light rounded-md text-xl disabled:opacity-50"
                        >
                            +
                        </button>
                    </div>
                </div>
            )})}
        </div>
    );
};

const SkillSelector: React.FC<{
    class: Dnd5eClass;
    selectedSkills: SkillName[];
    onSkillToggle: (skill: SkillName) => void;
}> = ({ class: dndClass, selectedSkills, onSkillToggle }) => {
    const { choose, from } = dndClass.skillProficiencyOptions;
    const remaining = choose - selectedSkills.length;
    
    return (
        <div className="space-y-3">
             <p className="text-center text-lg">Choose <span className="font-bold text-brand-gold">{choose}</span> skills ({remaining} remaining)</p>
             <div className="grid grid-cols-2 gap-2">
                {from.map(skillName => {
                    const isSelected = selectedSkills.includes(skillName);
                    const disabled = !isSelected && remaining <= 0;
                    return (
                        <button 
                            key={skillName}
                            onClick={() => onSkillToggle(skillName)}
                            disabled={disabled}
                            className={`p-3 rounded-md text-left transition-colors border-2 ${isSelected ? 'bg-brand-gold/10 border-brand-gold' : 'bg-brand-gray-dark border-brand-gray'} disabled:opacity-50 disabled:cursor-not-allowed`}
                        >
                            <span className="capitalize font-semibold">{skillName.replace(/_/g, ' ')}</span>
                        </button>
                    );
                })}
             </div>
        </div>
    )
}

const CharacterCreationScreen: React.FC<CharacterCreationScreenProps> = ({ onComplete, onBack }) => {
    const [step, setStep] = useState(1);
    const [name, setName] = useState('');
    const [selectedRace, setSelectedRace] = useState<Dnd5eRace | null>(null);
    const [selectedClass, setSelectedClass] = useState<Dnd5eClass | null>(null);
    const [scores, setScores] = useState<AbilityScores>({ str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 });
    const [points, setPoints] = useState(27);
    const [selectedSkills, setSelectedSkills] = useState<SkillName[]>([]);

    const finalScores = useMemo(() => {
        if (!selectedRace) return scores;
        const final = { ...scores };
        for (const [ability, increase] of Object.entries(selectedRace.abilityScoreIncreases)) {
            final[ability as Ability] = (final[ability as Ability] || 8) + (increase || 0);
        }
        return final;
    }, [scores, selectedRace]);
    
    const handleNextStep = () => setStep(s => s + 1);
    const handlePrevStep = () => setStep(s => s - 1);

    const handleRaceSelect = (race: Dnd5eRace) => {
        setSelectedRace(race);
        handleNextStep();
    }
    
    const handleClassSelect = (dndClass: Dnd5eClass) => {
        setSelectedClass(dndClass);
        setSelectedSkills([]); 
        handleNextStep();
    }
    
    const handleSkillToggle = (skill: SkillName) => {
        if(!selectedClass) return;
        
        setSelectedSkills(prev => {
            if (prev.includes(skill)) {
                return prev.filter(s => s !== skill);
            }
            if (prev.length < selectedClass.skillProficiencyOptions.choose) {
                return [...prev, skill];
            }
            return prev;
        });
    }
    
    const handleSubmit = () => {
        if(name && selectedRace && selectedClass && points === 0 && selectedSkills.length === selectedClass.skillProficiencyOptions.choose) {
            onComplete({
                name,
                dndRace: selectedRace,
                dndClass: selectedClass,
                abilityScores: scores,
                skillProficiencies: selectedSkills
            });
        } else {
            alert("Please complete all character creation steps correctly.");
        }
    }
    
    const renderStep = () => {
        switch(step) {
            case 1:
                return (
                    <div className="text-center">
                        <h3 className="font-cinzel text-xl text-brand-gold mb-4">What is your name?</h3>
                        <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Enter your name" className="w-full max-w-xs bg-brand-gray border border-brand-gray-light rounded-md p-3 text-center text-lg focus:ring-brand-gold focus:border-brand-gold text-white" />
                    </div>
                );
            case 2:
                return (
                    <div className="space-y-4">
                        <h3 className="font-cinzel text-xl text-brand-gold text-center mb-4">Choose your lineage</h3>
                        {dndRaces.map(race => (
                            <button key={race.id} onClick={() => handleRaceSelect(race)} className="w-full text-left p-4 bg-brand-gray-dark border-2 border-brand-gray rounded-lg transition-colors hover:border-brand-gold">
                                <h4 className="font-bold text-lg text-white">{race.name}</h4>
                                <p className="text-sm text-gray-400">{race.description}</p>
                            </button>
                        ))}
                    </div>
                );
            case 3:
                return (
                     <div className="space-y-4">
                        <h3 className="font-cinzel text-xl text-brand-gold text-center mb-4">Choose your path</h3>
                        {dndClasses.map(dndClass => (
                            <button key={dndClass.id} onClick={() => handleClassSelect(dndClass)} className="w-full text-left p-4 bg-brand-gray-dark border-2 border-brand-gray rounded-lg transition-colors hover:border-brand-gold flex items-center space-x-4">
                                <div className="w-10 h-10 text-brand-gold flex-shrink-0"><dndClass.icon/></div>
                                <div>
                                    <h4 className="font-bold text-lg text-white">{dndClass.name}</h4>
                                    <p className="text-sm text-gray-400">{dndClass.description}</p>
                                </div>
                            </button>
                        ))}
                    </div>
                );
            case 4:
                return <PointBuyAllocator scores={scores} setScores={setScores} points={points} setPoints={setPoints} />;
            case 5:
                if (!selectedClass) return <p>Error: No class selected.</p>;
                return <SkillSelector class={selectedClass} selectedSkills={selectedSkills} onSkillToggle={handleSkillToggle} />;
            case 6:
                if(!selectedRace || !selectedClass) return null;
                return (
                    <div className="space-y-4 text-center">
                        <h3 className="font-cinzel text-xl text-brand-gold mb-4">Review Your Character</h3>
                        <div className="bg-brand-gray-dark p-4 rounded-lg text-left space-y-2">
                            <p><strong className="text-gray-400">Name:</strong> {name}</p>
                            <p><strong className="text-gray-400">Race:</strong> {selectedRace.name}</p>
                            <p><strong className="text-gray-400">Class:</strong> {selectedClass.name}</p>
                            <h5 className="font-bold pt-2 text-brand-gold">Ability Scores:</h5>
                            <div className="grid grid-cols-3 gap-1 text-sm">
                                {(Object.entries(finalScores) as [Ability, number][]).map(([ab, value]) => (
                                    <p key={ab}><strong className="uppercase">{ab}:</strong> {value} ({getAbilityModifier(value) >= 0 ? '+' : ''}{getAbilityModifier(value)})</p>
                                ))}
                            </div>
                            <h5 className="font-bold pt-2 text-brand-gold">Skill Proficiencies:</h5>
                             <p className="text-sm capitalize text-gray-300">{selectedSkills.join(', ').replace(/_/g, ' ')}</p>
                        </div>
                    </div>
                );
            default: return null;
        }
    }

    const maxSteps = 6;
    const canGoNext = () => {
        switch(step) {
            case 1: return name.trim().length > 2;
            case 2: return !!selectedRace;
            case 3: return !!selectedClass;
            case 4: return points === 0;
            case 5: return selectedClass ? selectedSkills.length === selectedClass.skillProficiencyOptions.choose : false;
            case 6: return true;
            default: return false;
        }
    }

    return (
        <div className="flex flex-col h-full flex-grow bg-brand-dark">
            <header className="flex-shrink-0 flex items-center p-3 border-b border-brand-gray-light bg-brand-gray-dark">
                 <button 
                    onClick={onBack} 
                    className="p-2 mr-3 rounded-full text-gray-300 hover:bg-brand-gray-light hover:text-white transition-colors"
                    aria-label="Go back"
                >
                    <BackArrowIcon />
                </button>
                <h2 className="font-cinzel text-xl font-bold text-brand-gold uppercase tracking-wider">Create Character</h2>
            </header>
             <div className="flex-grow p-4 overflow-y-auto">
                 {renderStep()}
             </div>
             <footer className="p-4 border-t border-brand-gray-light bg-brand-gray-dark flex justify-between items-center">
                <button onClick={handlePrevStep} disabled={step === 1} className="bg-brand-gray text-gray-300 font-bold py-2 px-4 rounded-lg uppercase tracking-wider hover:bg-brand-gray-light transition-colors disabled:opacity-50">Back</button>
                <div className="flex items-center space-x-2">
                    {Array.from({length: maxSteps}).map((_, i) => (
                        <div key={i} className={`w-3 h-3 rounded-full ${i+1 <= step ? 'bg-brand-gold' : 'bg-brand-gray-light'}`}></div>
                    ))}
                </div>
                {step < maxSteps 
                    ? <button onClick={handleNextStep} disabled={!canGoNext()} className="bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-colors disabled:opacity-50">Next</button>
                    : <button onClick={handleSubmit} className="bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-colors">Complete</button>
                }
             </footer>
        </div>
    );
};

export default CharacterCreationScreen;