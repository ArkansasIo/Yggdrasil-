
import React from 'react';
import { User } from '../types';
import { YggdrasilIcon, UserIcon } from './Icons';

interface TitleScreenProps {
    onPlay: () => void;
    onShowCredits: () => void;
    onShowUpdates: () => void;
    onLogin: () => void;
    onLogout: () => void;
    user: User | null;
}

const TitleScreen: React.FC<TitleScreenProps> = ({ onPlay, onShowCredits, onShowUpdates, onLogin, onLogout, user }) => {
    return (
        <div className="relative flex flex-col items-center justify-center h-full flex-grow bg-cover bg-center bg-title-bg">
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm"></div>

            {/* Auth Button */}
            <div className="absolute top-4 right-4 z-20">
                {user ? (
                    <div className="flex items-center space-x-3 bg-brand-gray/50 p-2 rounded-lg">
                        <UserIcon />
                        <span className="text-sm font-medium">{user.email}</span>
                        <button 
                            onClick={onLogout}
                            className="text-sm text-gray-300 hover:text-brand-gold"
                        >
                           (Logout)
                        </button>
                    </div>
                ) : (
                    <button
                        onClick={onLogin}
                        className="bg-brand-gray text-gray-300 font-bold py-2 px-4 rounded-lg uppercase tracking-wider hover:bg-brand-gray-light transition-colors"
                    >
                        Login
                    </button>
                )}
            </div>

            <div className="relative z-10 w-full text-center p-8 flex flex-col items-center">
                <div className="w-24 h-24 text-brand-gold mx-auto mb-4">
                     <YggdrasilIcon />
                </div>
                <h1 className="font-cinzel text-4xl font-bold tracking-widest text-brand-gold uppercase">
                    Yggdrasil Chronicles
                </h1>
                <p className="font-inter text-md text-gray-300 uppercase tracking-wider mt-1">
                    The Shattered Realms
                </p>
                <div className="mt-16 space-y-4 w-full max-w-xs">
                    <button
                        onClick={onPlay}
                        className="w-full bg-brand-gold text-brand-dark font-bold py-3 px-4 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-colors transform hover:enabled:scale-105 disabled:bg-brand-gray-light disabled:text-gray-500 disabled:cursor-not-allowed"
                    >
                        {user ? 'Play' : 'Login to Play'}
                    </button>
                    <div className="grid grid-cols-2 gap-4">
                        <button
                            onClick={onShowUpdates}
                            className="w-full bg-brand-gray text-gray-300 font-bold py-3 px-4 rounded-lg uppercase tracking-wider hover:bg-brand-gray-light transition-colors"
                        >
                            Updates
                        </button>
                        <button
                            onClick={onShowCredits}
                            className="w-full bg-brand-gray text-gray-300 font-bold py-3 px-4 rounded-lg uppercase tracking-wider hover:bg-brand-gray-light transition-colors"
                        >
                            Credits
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TitleScreen;
