import React, { useState } from 'react';
import { BackArrowIcon } from './Icons';
import PatchNotesScreen from './PatchNotesScreen';

interface UpdatesScreenProps {
    onBack: () => void;
}

const UpdatesScreen: React.FC<UpdatesScreenProps> = ({ onBack }) => {
    const [view, setView] = useState<'main' | 'patch-notes'>('main');

    if (view === 'patch-notes') {
        return <PatchNotesScreen onBack={() => setView('main')} />;
    }

    return (
        <div className="flex flex-col h-full flex-grow bg-brand-dark">
            <header className="flex-shrink-0 flex items-center p-3 border-b border-brand-gray-light bg-brand-gray-dark">
                 <button 
                    onClick={onBack} 
                    className="p-2 mr-3 rounded-full text-gray-300 hover:bg-brand-gray-light hover:text-white transition-colors"
                    aria-label="Go back"
                >
                    <BackArrowIcon />
                </button>
                <h2 className="font-cinzel text-xl font-bold text-brand-gold uppercase tracking-wider">Updates & Community</h2>
            </header>
            <div className="flex-grow p-4 overflow-y-auto space-y-4">
                <div className="bg-brand-gray-dark p-4 rounded-lg">
                    <h3 className="font-cinzel text-lg text-brand-gold">Latest News</h3>
                    <p className="text-sm text-gray-300 mt-2">Welcome to the Alpha of Yggdrasil Chronicles! We are hard at work building new systems and expanding the world. Thank you for playing!</p>
                </div>

                <button 
                    onClick={() => setView('patch-notes')}
                    className="w-full text-left p-4 bg-brand-gray hover:bg-brand-gray-light rounded-lg transition-colors"
                >
                    <h3 className="font-bold text-white">Patch Notes</h3>
                    <p className="text-sm text-gray-400">See what's new in the latest version.</p>
                </button>

                <div className="bg-brand-gray-dark p-4 rounded-lg">
                    <h3 className="font-cinzel text-lg text-brand-gold">Community Links</h3>
                    <div className="mt-2 space-y-2 text-sm text-brand-gold">
                       <p className="text-gray-400">(Community links coming soon)</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UpdatesScreen;
