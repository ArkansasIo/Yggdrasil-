import React from 'react';
import { Character } from '../types';
import StatBar from './StatBar';

interface CharacterSheetProps {
    character: Character;
}

const CharacterSheet: React.FC<CharacterSheetProps> = ({ character }) => {
    const xpThreshold = character.level * 200;
    const progress = (xpThreshold > 0) ? (character.experience / xpThreshold) * 100 : 0;
    
    return (
        <div className="bg-brand-gray-dark rounded-lg p-3 flex items-center space-x-4 border border-brand-gray-light shadow-lg">
            <div className="relative flex-shrink-0">
                <img 
                    src={character.avatarUrl || 'https://via.placeholder.com/64?text=Avatar'} 
                    alt={`${character.name}'s Avatar`} 
                    className="w-16 h-16 rounded-md border-2 border-brand-gray-light object-cover"
                />
                <div className="absolute -top-2 -left-2 flex items-center space-x-1">
                    <span className="bg-brand-gold text-brand-dark text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full border-2 border-brand-dark">
                        {character.level}
                    </span>
                    {character.expansionLevel > 0 && (
                         <span className="bg-purple-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full border-2 border-brand-dark" title={`Expansion Level ${character.expansionLevel}`}>
                            E+{character.expansionLevel}
                        </span>
                    )}
                </div>
            </div>
            <div className="flex-grow space-y-1.5">
                <div className="flex justify-between items-start">
                    <div>
                        <h2 className="font-bold text-lg leading-tight text-white">{character.name}</h2>
                        <p className="text-[10px] text-gray-400 uppercase tracking-wider">{character.class} • {character.location}</p>
                    </div>
                    <div className="text-right">
                        <p className="text-[9px] text-gray-500 uppercase font-bold">Exp Progress</p>
                        <div className="w-20 bg-gray-800 h-1 rounded-full mt-1 overflow-hidden border border-black/20">
                            <div 
                                className="bg-brand-gold h-full transition-all duration-500"
                                style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
                            ></div>
                        </div>
                    </div>
                </div>
                <div className="space-y-1">
                    <StatBar value={character.hp} maxValue={character.maxHp} color="bg-red-500" />
                    <StatBar value={character.mp} maxValue={character.maxMp} color="bg-blue-500" />
                    <StatBar value={character.sp} maxValue={character.maxSp} color="bg-green-500" />
                </div>
            </div>
        </div>
    );
};

export default CharacterSheet;