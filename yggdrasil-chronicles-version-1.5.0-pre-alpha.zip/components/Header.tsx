
import React, { useState, useEffect, useCallback } from 'react';
import { SaveIcon } from './Icons';

interface HeaderProps {
    onSave?: () => Promise<boolean>;
}

interface Toast {
    id: number;
    message: string;
    type: 'success' | 'error';
    isAuto: boolean;
}

const Header: React.FC<HeaderProps> = ({ onSave }) => {
    const [isSaving, setIsSaving] = useState(false);
    const [toasts, setToasts] = useState<Toast[]>([]);

    const removeToast = useCallback((id: number) => {
        setToasts(prev => prev.filter(t => t.id !== id));
    }, []);

    const addToast = useCallback((message: string, type: 'success' | 'error', isAuto: boolean) => {
        const id = Date.now();
        setToasts(prev => [...prev, { id, message, type, isAuto }]);
        setTimeout(() => removeToast(id), 5000);
    }, [removeToast]);

    useEffect(() => {
        const handleSaveEvent = (e: Event) => {
            const detail = (e as CustomEvent).detail;
            addToast(detail.message, detail.success ? 'success' : 'error', detail.isAuto);
        };

        window.addEventListener('yc-save-status', handleSaveEvent);
        return () => window.removeEventListener('yc-save-status', handleSaveEvent);
    }, [addToast]);

    const handleManualSave = async () => {
        if (!onSave || isSaving) return;
        setIsSaving(true);
        try {
            await onSave();
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <header className="relative text-center py-6 bg-header-bg bg-cover bg-center">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
            
            {/* Save Button */}
            {onSave && (
                <div className="absolute top-4 right-4 z-20">
                    <button 
                        onClick={handleManualSave}
                        disabled={isSaving}
                        title="Manual Save"
                        className={`flex items-center space-x-2 px-3 py-2 rounded-md border text-xs font-bold uppercase tracking-wider transition-all
                            ${isSaving 
                                ? 'bg-brand-gold/20 border-brand-gold text-brand-gold cursor-wait' 
                                : 'bg-black/40 border-gray-500 text-gray-300 hover:border-brand-gold hover:text-brand-gold active:scale-95'
                            }`}
                    >
                        <div className={`w-4 h-4 ${isSaving ? 'animate-spin' : ''}`}>
                            <SaveIcon />
                        </div>
                        <span className="hidden sm:inline">{isSaving ? 'Saving...' : 'Save'}</span>
                    </button>
                </div>
            )}

            {/* Toast Container */}
            <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] w-full max-w-xs space-y-2 pointer-events-none px-4">
                {toasts.map(toast => (
                    <div 
                        key={toast.id}
                        className={`p-3 rounded-lg border shadow-2xl backdrop-blur-md flex items-center space-x-3 animate-[slideIn_0.3s_ease-out] pointer-events-auto
                            ${toast.type === 'success' 
                                ? 'bg-brand-gray-dark/90 border-brand-gold/50 text-gray-200' 
                                : 'bg-red-950/90 border-red-500/50 text-red-100'
                            }`}
                    >
                        <div className={`flex-shrink-0 w-2 h-2 rounded-full ${toast.type === 'success' ? 'bg-brand-gold animate-pulse' : 'bg-red-500'}`}></div>
                        <div className="flex-grow text-left">
                            <p className="font-cinzel text-[10px] uppercase tracking-widest font-bold opacity-60">
                                {toast.isAuto ? 'Auto-Save' : 'Manual Save'}
                            </p>
                            <p className="text-sm font-medium leading-tight">{toast.message}</p>
                        </div>
                        <button 
                            onClick={() => removeToast(toast.id)}
                            className="text-gray-500 hover:text-white transition-colors"
                        >
                            &times;
                        </button>
                    </div>
                ))}
            </div>

            <div className="relative z-10">
                <h1 className="font-cinzel text-3xl font-bold tracking-widest text-brand-gold uppercase">
                    Yggdrasil Chronicles
                </h1>
                <p className="font-inter text-sm text-gray-300 uppercase tracking-wider">
                    The Shattered Realms
                </p>
            </div>

            <style>{`
                @keyframes slideIn {
                    from { opacity: 0; transform: translateY(-20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </header>
    );
};

export default Header;
