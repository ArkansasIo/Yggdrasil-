import React, { useState, useCallback, useEffect } from 'react';
import { CharacterCreationData, GameState, User, Realm, SaveFile, GameChoice } from '../types';
import { useGameEngine } from '../hooks/useGameEngine';
import TitleScreen from './TitleScreen';
import CharacterCreationScreen from './CharacterCreationScreen';
import CreditsScreen from './CreditsScreen';
import GameplayScreen from './GameplayScreen';
import LoadingScreen from './LoadingScreen';
import AuthModal from './AuthModal';
import { authService } from '../services/authService';
import RealmSelectionPage from './RealmSelectionPage';
import CharacterSelectScreen from './CharacterSelectScreen';
import UpdatesScreen from './UpdatesScreen';


type GameView = 'TITLE' | 'CREDITS' | 'REALM_SELECTION' | 'CHARACTER_SELECT' | 'CHARACTER_CREATION' | 'GAMEPLAY' | 'LOADING' | 'UPDATES';

const App: React.FC = () => {
    const { gameState, isLoading, handlePlayerChoice, startGame, loadGame, updateGameState, equipItem, masterworkItem, manualSaveGame } = useGameEngine();
    const [gameView, setGameView] = useState<GameView>('TITLE');
    
    // Auth and User State
    const [isAuthModalOpen, setAuthModalOpen] = useState(false);
    const [currentUser, setCurrentUser] = useState<User | null>(null);

    // Game Selection State
    const [selectedRealm, setSelectedRealm] = useState<Realm | null>(null);
    const [characterSlot, setCharacterSlot] = useState<number | null>(null);

    useEffect(() => {
        // Check for existing session on initial load
        const user = authService.getCurrentUser();
        if (user) {
            setCurrentUser(user);
        }
    }, []);

    const handleLogin = () => setAuthModalOpen(true);
    
    const handleLoginSuccess = (user: User) => {
        setCurrentUser(user);
        setAuthModalOpen(false);
        // Automatically proceed to realm selection if user just logged in from title
        if (gameView === 'TITLE') {
            setGameView('REALM_SELECTION');
        }
    };

    const handleLogout = () => {
        authService.logout();
        setCurrentUser(null);
        setSelectedRealm(null);
        setGameView('TITLE');
    };
    
    const handlePlay = () => {
        if(currentUser) {
            setGameView('REALM_SELECTION');
        } else {
            handleLogin();
        }
    };

    const handleShowUpdates = () => {
        setGameView('UPDATES');
    };

    const handleRealmSelect = (realm: Realm) => {
        setSelectedRealm(realm);
        setGameView('CHARACTER_SELECT');
    };

    const handleBackToTitle = () => {
        setSelectedRealm(null);
        setGameView('TITLE');
    };

    const handleBackToRealmSelection = () => {
        setGameView('REALM_SELECTION');
    };

    const handleNewCharacter = (slot: number) => {
        setCharacterSlot(slot);
        setGameView('CHARACTER_CREATION');
    };

    const handleCharacterCreationComplete = useCallback(async (characterData: CharacterCreationData) => {
        if (!currentUser || !selectedRealm || characterSlot === null) {
            alert("Error: User, realm, or character slot not defined.");
            setGameView('TITLE');
            return;
        }
        setGameView('LOADING');
        const success = await startGame(characterData, currentUser, selectedRealm, characterSlot);
        if (success) {
            setGameView('GAMEPLAY');
        } else {
            alert("Failed to start the game. The ancient scrolls are unreadable.");
            setGameView('CHARACTER_SELECT');
        }
    }, [startGame, currentUser, selectedRealm, characterSlot]);
    
    const handleGameLoadSelected = useCallback(async (saveFile: SaveFile) => {
        if (!selectedRealm) {
            alert("Error: No realm is selected to load a character from.");
            setGameView('REALM_SELECTION');
            return;
        }
        setGameView('LOADING');
        const success = await loadGame(saveFile.gameState, selectedRealm);
        if(success) {
            setGameView('GAMEPLAY');
        } else {
            alert("Failed to load save file. The threads of fate are tangled.");
            setGameView('CHARACTER_SELECT');
        }
    }, [loadGame, selectedRealm]);

    const handleExitGameplay = useCallback(async () => {
        // Prompt the user to save before quitting
        if (window.confirm("Do you want to save your progress before returning to the title screen?")) {
            setGameView('LOADING'); // Show loading state while saving
            await manualSaveGame();
        }
        
        // Return to title whether they saved or not
        setGameView('TITLE');
        setSelectedRealm(null);
    }, [manualSaveGame]);


    const renderView = () => {
        switch (gameView) {
            case 'TITLE':
                return <TitleScreen onPlay={handlePlay} onShowCredits={() => setGameView('CREDITS')} onShowUpdates={handleShowUpdates} onLogin={handleLogin} onLogout={handleLogout} user={currentUser} />;
            case 'CREDITS':
                return <CreditsScreen onBack={handleBackToTitle} />;
            case 'UPDATES':
                return <UpdatesScreen onBack={handleBackToTitle} />;
            case 'REALM_SELECTION':
                return <RealmSelectionPage onRealmSelect={handleRealmSelect} onBack={handleBackToTitle} />;
            case 'CHARACTER_SELECT':
                 if (!currentUser || !selectedRealm) {
                    handleBackToTitle();
                    return null;
                }
                return <CharacterSelectScreen user={currentUser} realm={selectedRealm} onNewCharacter={handleNewCharacter} onGameLoad={handleGameLoadSelected} onBack={handleBackToRealmSelection} />;
            case 'CHARACTER_CREATION':
                if (!selectedRealm) { // Ensure realm is still selected
                    handleBackToRealmSelection();
                    return null;
                }
                return <CharacterCreationScreen onComplete={handleCharacterCreationComplete} onBack={() => setGameView('CHARACTER_SELECT')} />;
            case 'LOADING':
                 return <LoadingScreen />;
            case 'GAMEPLAY':
                if (gameState.character) {
                     return (
                        <GameplayScreen 
                            gameState={gameState} 
                            isLoading={isLoading} 
                            handlePlayerChoice={handlePlayerChoice}
                            updateGameState={updateGameState}
                            equipItem={equipItem}
                            masterworkItem={masterworkItem}
                            manualSaveGame={manualSaveGame}
                            onExit={handleExitGameplay}
                        />
                    );
                }
                // Fallback if game state isn't ready
                handleBackToTitle();
                return null;
            default:
                return <TitleScreen onPlay={handlePlay} onShowCredits={() => setGameView('CREDITS')} onShowUpdates={handleShowUpdates} onLogin={handleLogin} onLogout={handleLogout} user={currentUser} />;
        }
    };

    return (
        <div className="min-h-screen bg-brand-dark text-white max-w-lg mx-auto flex flex-col shadow-2xl shadow-brand-gold/10">
            {isAuthModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} onLoginSuccess={handleLoginSuccess}/>}
            {renderView()}
        </div>
    );
};

export default App;