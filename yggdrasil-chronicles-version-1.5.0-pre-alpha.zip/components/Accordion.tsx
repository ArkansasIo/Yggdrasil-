
import React from 'react';

interface AccordionProps {
    id: string;
    title: string;
    icon: React.ReactNode;
    children: React.ReactNode;
    isOpen: boolean;
    toggle: (id: string) => void;
}

const Accordion: React.FC<AccordionProps> = ({ id, title, icon, children, isOpen, toggle }) => {
    return (
        <div className="rounded-md overflow-hidden border border-brand-gray-light">
            <button
                onClick={() => toggle(id)}
                className={`w-full flex items-center justify-between p-3 text-left font-bold transition-colors duration-200 ${
                    isOpen ? 'bg-brand-gold/20 text-brand-gold' : 'bg-brand-gray text-gray-300 hover:bg-brand-gray-light'
                }`}
            >
                <div className="flex items-center space-x-3">
                    <span className="w-5 h-5">{icon}</span>
                    <span>{title}</span>
                </div>
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className={`h-5 w-5 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                    viewBox="0 0 20 20"
                    fill="currentColor"
                >
                    <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                    />
                </svg>
            </button>
            <div
                className={`grid transition-all duration-500 ease-in-out ${
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                }`}
            >
                <div className="overflow-hidden">
                    {children}
                </div>
            </div>
        </div>
    );
};

export default Accordion;
