
import React from 'react';

interface SubMenuItemProps {
    icon: React.ReactNode;
    label: string;
    onClick?: () => void;
}

const SubMenuItem: React.FC<SubMenuItemProps> = ({ icon, label, onClick }) => (
    <div 
        onClick={onClick} 
        className="flex items-center space-x-3 p-2.5 text-sm text-gray-300 hover:bg-brand-gold/10 rounded-md cursor-pointer transition-colors"
    >
        <span className="w-5 h-5 text-gray-400">{icon}</span>
        <span className="font-medium">{label}</span>
    </div>
);

export default SubMenuItem;
