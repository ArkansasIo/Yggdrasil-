// Using the same values as in tailwind.config for consistency
export const theme = {
    colors: {
        'brand-gold': '#FACC15',
        'brand-dark': '#111014',
        'brand-gray': {
            'light': '#3A3841',
            'DEFAULT': '#25232A',
            'dark': '#1C1A20',
        },
    },
    fontFamily: {
        'cinzel': ['Cinzel', 'serif'],
        'inter': ['Inter', 'sans-serif'],
    },
};
